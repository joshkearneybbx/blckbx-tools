import { useState, useEffect } from 'react';

interface ImageCache {
  [url: string]: string;
}

// Helper to safely extract image URLs from various formats
function extractImageUrls(images: any): string[] {
  if (!images) return [];

  // Already an array of strings
  if (Array.isArray(images)) {
    return images.filter(url => typeof url === 'string' && url.startsWith('http'));
  }

  // JSON string - parse it
  if (typeof images === 'string') {
    // Check if it's a URL directly
    if (images.startsWith('http')) {
      return [images];
    }
    // Try to parse as JSON
    try {
      const parsed = JSON.parse(images);
      if (Array.isArray(parsed)) {
        return parsed.filter(url => typeof url === 'string' && url.startsWith('http'));
      }
      if (typeof parsed === 'string' && parsed.startsWith('http')) {
        return [parsed];
      }
    } catch {
      // Not valid JSON, ignore
    }
  }

  return [];
}

export function useImagePreprocessor(itinerary: any) {
  const [processedItinerary, setProcessedItinerary] = useState(itinerary || null);
  const [isLoading, setIsLoading] = useState(!!itinerary);
  const [cache] = useState<ImageCache>({});

  useEffect(() => {
    async function preprocessImages() {
      if (!itinerary) {
        setIsLoading(false);
        return;
      }

      try {
        setIsLoading(true);

        const imageUrls: string[] = [];

        // Extract from accommodations
        itinerary.accommodations?.forEach((acc: any) => {
          imageUrls.push(...extractImageUrls(acc.images));
        });

        // Extract from activities
        itinerary.activities?.forEach((activity: any) => {
          imageUrls.push(...extractImageUrls(activity.images));
        });

        // Extract from dining
        itinerary.dining?.forEach((restaurant: any) => {
          imageUrls.push(...extractImageUrls(restaurant.images));
        });

        // Extract from bars
        itinerary.bars?.forEach((bar: any) => {
          imageUrls.push(...extractImageUrls(bar.images));
        });

        const uniqueUrls = Array.from(new Set(imageUrls));

        console.log(`📸 Pre-processing ${uniqueUrls.length} images...`);
        console.log('📸 URLs found:', uniqueUrls);

        if (uniqueUrls.length === 0) {
          console.log('⚠️ No image URLs found to process');
          setProcessedItinerary(itinerary);
          setIsLoading(false);
          return;
        }

        const dataUris = await Promise.all(
          uniqueUrls.map(async (url) => {
            if (cache[url]) {
              console.log(`✅ Using cached image: ${url.substring(0, 50)}...`);
              return { url, dataUri: cache[url] };
            }

            try {
              const proxyUrl = `${window.location.origin}/api/proxy-image/${btoa(url)}.jpg`;
              console.log(`🔄 Fetching via proxy: ${url.substring(0, 50)}...`);
              const response = await fetch(proxyUrl);

              if (!response.ok) {
                console.error(`❌ Failed to fetch ${url}: HTTP ${response.status}`);
                return { url, dataUri: null };
              }

              const blob = await response.blob();
              console.log(`📦 Got blob: ${blob.type}, ${blob.size} bytes`);

              // Check if it's WebP or AVIF - convert to JPG
              let finalBlob = blob;
              if (blob.type === 'image/webp' || blob.type === 'image/avif') {
                console.log(`🔄 Converting ${blob.type} to JPG: ${url.substring(0, 50)}...`);
                finalBlob = await convertToJPG(blob);
              }

              const dataUri = await blobToDataUri(finalBlob);

              cache[url] = dataUri;

              console.log(`✅ Converted to data URI: ${url.substring(0, 50)}...`);
              return { url, dataUri };
            } catch (error) {
              console.error(`❌ Error processing ${url}:`, error);
              return { url, dataUri: null };
            }
          })
        );

        const urlMap: { [key: string]: string } = {};
        dataUris.forEach(({ url, dataUri }) => {
          if (dataUri) {
            urlMap[url] = dataUri;
          }
        });

        console.log(`✅ Successfully processed ${Object.keys(urlMap).length} of ${uniqueUrls.length} images`);

        // Helper to replace URLs in images field
        const replaceUrls = (images: any): string[] => {
          const urls = extractImageUrls(images);
          return urls.map(url => urlMap[url] || url);
        };

        const processed = {
          ...itinerary,
          accommodations: itinerary.accommodations?.map((acc: any) => ({
            ...acc,
            images: replaceUrls(acc.images)
          })),
          activities: itinerary.activities?.map((activity: any) => ({
            ...activity,
            images: replaceUrls(activity.images)
          })),
          dining: itinerary.dining?.map((restaurant: any) => ({
            ...restaurant,
            images: replaceUrls(restaurant.images)
          })),
          bars: itinerary.bars?.map((bar: any) => ({
            ...bar,
            images: replaceUrls(bar.images)
          }))
        };

        console.log(`✅ All images pre-processed successfully!`);
        setProcessedItinerary(processed);
      } catch (error) {
        console.error('❌ Error pre-processing images:', error);
        setProcessedItinerary(itinerary);
      } finally {
        setIsLoading(false);
      }
    }

    preprocessImages();
  }, [itinerary, cache]);

  return { processedItinerary, isLoading };
}

// Convert WebP/AVIF to JPG using Canvas
async function convertToJPG(imageBlob: Blob): Promise<Blob> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    const objectUrl = URL.createObjectURL(imageBlob);

    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;

      const ctx = canvas.getContext('2d');
      if (!ctx) {
        URL.revokeObjectURL(objectUrl);
        reject(new Error('Could not get canvas context'));
        return;
      }
      ctx.drawImage(img, 0, 0);

      canvas.toBlob(
        (blob) => {
          URL.revokeObjectURL(objectUrl);
          if (blob) {
            resolve(blob);
          } else {
            reject(new Error('Failed to convert to JPG'));
          }
        },
        'image/jpeg',
        0.92
      );
    };

    img.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error('Failed to load image for conversion'));
    };

    img.src = objectUrl;
  });
}

function blobToDataUri(blob: Blob): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onloadend = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(blob);
  });
}