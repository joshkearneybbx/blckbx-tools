import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import logoUrl from "@assets/blckbx-logo.png";
import { useAuth } from "@/hooks/useAuth";
import { Redirect } from "wouter";

export default function Login() {
  const { isAuthenticated, isLoading } = useAuth();

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-pulse">
          <img src={logoUrl} alt="BlckBx" className="h-16 w-auto" />
        </div>
      </div>
    );
  }

  if (isAuthenticated) {
    return <Redirect to="/" />;
  }

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center space-y-4">
          <div className="flex justify-center">
            <img src={logoUrl} alt="BlckBx" className="h-16 w-auto" data-testid="img-logo" />
          </div>
          <CardTitle className="text-2xl font-serif">Welcome to BlckBx</CardTitle>
          <CardDescription>
            Sign in to access the itinerary dashboard and create travel experiences for your clients.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Button
            className="w-full"
            size="lg"
            onClick={() => {
              window.location.href = "/api/login";
            }}
            data-testid="button-login"
          >
            Sign in to continue
          </Button>
          <p className="text-xs text-center text-muted-foreground">
            For BlckBx team members only. Clients can view itineraries via shared links without signing in.
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
