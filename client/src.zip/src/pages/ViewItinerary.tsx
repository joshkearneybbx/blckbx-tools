import { useQuery } from "@tanstack/react-query";
import { useRoute, Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Loader2, ArrowLeft, MapPin, ExternalLink, Pencil, Copy, Check } from "lucide-react";
import { SiWhatsapp } from "react-icons/si";
import { useToast } from "@/hooks/use-toast";
import { useState, useMemo, useEffect } from "react";
import type { FullItinerary, AdditionalTravel } from "@shared/schema";
import { PDFDownloadLink } from "@react-pdf/renderer";
import { ItineraryPDFTemplate } from "@/components/pdf/ItineraryPDFTemplate";
import logoUrl from "@assets/blckbx-logo.png";
import MapVisualization from "@/components/MapVisualization";
import { collectLocationsFromItinerary } from "@/lib/collectLocations";
import { useImagePreprocessor } from "@/hooks/useImagePreprocessor";
import { Helmet } from "react-helmet";
import { FlightCard } from "@/components/FlightCard";
import { useAuth } from "@/hooks/useAuth";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

// Sortable Travel Item component for drag-and-drop
function SortableTravelItem({ travel }: { travel: AdditionalTravel }) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: travel.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 50 : undefined,
    touchAction: 'none' as const,
  };

  return (
    <div
      ref={setNodeRef}
      style={style}
      className={`rounded-lg border bg-card overflow-hidden transition-shadow ${
        isDragging ? 'shadow-xl ring-2 ring-[#6B1488]' : ''
      }`}
    >
      {/* Header with drag handle and travel type */}
      <div className="px-4 py-3 flex items-center gap-3 border-b bg-muted/30">
        {/* Functional drag handle button */}
        <button
          type="button"
          {...listeners}
          {...attributes}
          className="flex flex-col gap-1 cursor-grab active:cursor-grabbing hover:opacity-70 transition-opacity touch-none p-1 -m-1"
          style={{ touchAction: 'none' }}
          aria-label="Drag to reorder"
        >
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-gray-500"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-gray-500"></div>
          </div>
          <div className="flex gap-1">
            <div className="w-1.5 h-1.5 rounded-full bg-gray-500"></div>
            <div className="w-1.5 h-1.5 rounded-full bg-gray-500"></div>
          </div>
        </button>
        <h3 className="font-semibold text-lg">
          {travel.travelType.charAt(0).toUpperCase() + travel.travelType.slice(1)}
        </h3>
      </div>
      
      {/* Content */}
      <div className="p-4">
        {travel.travelType === 'flight' && travel.flightNumber ? (
          <FlightCard
            flightNumber={travel.flightNumber}
            date={travel.flightDate || ''}
            departureAirport={travel.flightDepartureAirport || ''}
            departureTime={travel.flightDepartureTime || ''}
            arrivalAirport={travel.flightArrivalAirport || ''}
            arrivalTime={travel.flightArrivalTime || ''}
            passengers={travel.flightPassengersSeats || undefined}
            notes={travel.flightThingsToRemember || undefined}
          />
        ) : (
          <div className="space-y-2 text-sm">
            {travel.travelType === 'car' && (
              <>
                {travel.vehicleDetails && <p><span className="font-medium">Vehicle:</span> {travel.vehicleDetails}</p>}
                {travel.vehicleRegistration && <p><span className="font-medium">Registration:</span> {travel.vehicleRegistration}</p>}
                {travel.carContactDetails && <p><span className="font-medium">Contact:</span> {travel.carContactDetails}</p>}
                {travel.carBookingDetails && <p className="whitespace-pre-wrap">{travel.carBookingDetails}</p>}
              </>
            )}
            {travel.travelType === 'ferry' && (
              <>
                {travel.ferryDepartingFrom && <p><span className="font-medium">From:</span> {travel.ferryDepartingFrom}</p>}
                {travel.ferryDestination && <p><span className="font-medium">To:</span> {travel.ferryDestination}</p>}
                {travel.ferryDate && <p><span className="font-medium">Date:</span> {travel.ferryDate}</p>}
                {travel.ferryPrice && <p><span className="font-medium">Price:</span> {travel.ferryPrice}</p>}
                {travel.ferryContactDetails && <p><span className="font-medium">Contact:</span> {travel.ferryContactDetails}</p>}
                {travel.ferryBookingReference && <p><span className="font-medium">Booking Ref:</span> {travel.ferryBookingReference}</p>}
                {travel.ferryAdditionalNotes && <p className="whitespace-pre-wrap">{travel.ferryAdditionalNotes}</p>}
              </>
            )}
            {travel.travelType === 'train' && (
              <>
                {travel.trainDepartingFrom && <p><span className="font-medium">From:</span> {travel.trainDepartingFrom}</p>}
                {travel.trainDestination && <p><span className="font-medium">To:</span> {travel.trainDestination}</p>}
                {travel.trainDate && <p><span className="font-medium">Date:</span> {travel.trainDate}</p>}
                {travel.trainPrice && <p><span className="font-medium">Price:</span> {travel.trainPrice}</p>}
                {travel.trainContactDetails && <p><span className="font-medium">Contact:</span> {travel.trainContactDetails}</p>}
                {travel.trainBookingReference && <p><span className="font-medium">Booking Ref:</span> {travel.trainBookingReference}</p>}
                {travel.trainAdditionalNotes && <p className="whitespace-pre-wrap">{travel.trainAdditionalNotes}</p>}
              </>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

// Weather emoji mapping - dynamic based on weather text
const getWeatherEmoji = (weather: string | null | undefined): string => {
  if (!weather) return '🌡️';
  
  const text = weather.toLowerCase();
  
  if (text.includes('hot') || text.includes('sunny') || text.includes('clear')) {
    return '☀️';
  }
  if (text.includes('warm') || text.includes('mild') || text.includes('pleasant')) {
    return '🌤️';
  }
  if (text.includes('partly') || text.includes('partial')) {
    return '⛅';
  }
  if (text.includes('cloud') || text.includes('overcast')) {
    return '☁️';
  }
  if (text.includes('rain') || text.includes('shower')) {
    return '🌧️';
  }
  if (text.includes('storm') || text.includes('thunder')) {
    return '⛈️';
  }
  if (text.includes('snow') || text.includes('cold') || text.includes('freezing')) {
    return '❄️';
  }
  if (text.includes('wind')) {
    return '💨';
  }
  if (text.includes('fog') || text.includes('mist')) {
    return '🌫️';
  }
  
  // Default thermometer
  return '🌡️';
};

export default function ViewItinerary() {
  const [, params] = useRoute("/itinerary/:slug");
  const slug = params?.slug || "";
  const { toast } = useToast();
  const [linkCopied, setLinkCopied] = useState(false);
  const { user, isAuthResolved } = useAuth();

  const { data, isLoading, error } = useQuery<FullItinerary>({
    queryKey: ["/api/itinerary", slug],
  });

  // Check if current user is the owner of this itinerary
  // Only determine ownership once auth has resolved to avoid flicker
  const isOwner = isAuthResolved && user?.id === data?.itinerary?.userId;
  const isOwnershipDetermined = isAuthResolved && !isLoading;

  // Pre-process images for PDF (convert to data URIs)
  const { processedItinerary, isLoading: isProcessingImages } = useImagePreprocessor(data);

  // Collect all map locations
  const mapLocations = useMemo(() => {
    if (!data) return [];
    return collectLocationsFromItinerary(data);
  }, [data]);

  // State for additional travel items (for drag-and-drop reordering)
  const [additionalTravelItems, setAdditionalTravelItems] = useState<AdditionalTravel[]>([]);
  
  // Sync additional travel items from query data
  useEffect(() => {
    if (data?.additionalTravel) {
      setAdditionalTravelItems([...data.additionalTravel]);
    }
  }, [data?.additionalTravel]);

  // Set up sensors for drag detection with activation constraint
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8, // Require 8px movement before activating drag
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Handle drag end for additional travel reordering
  const handleAdditionalTravelDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setAdditionalTravelItems((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id);
        const newIndex = items.findIndex((item) => item.id === over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    setLinkCopied(true);
    toast({
      title: "Link copied!",
      description: "The itinerary link has been copied to your clipboard.",
    });
    setTimeout(() => setLinkCopied(false), 2000);
  };

  const handleWhatsAppShare = () => {
    if (!data) return;
    
    const text = encodeURIComponent(
      `Check out this travel itinerary!\n\n` +
      `${data.itinerary.title}\n\n` +
      `View full details: ${window.location.href}`
    );
    window.open(`https://wa.me/?text=${text}`, '_blank');
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin mx-auto text-primary" data-testid="loader-itinerary" />
          <p className="text-lg text-muted-foreground">Loading itinerary...</p>
        </div>
      </div>
    );
  }

  if (error || !data) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4 max-w-md px-4">
          <img 
            src={logoUrl} 
            alt="BlckBx" 
            className="h-12 w-auto mx-auto mb-4"
          />
          <h1 className="text-2xl font-serif font-semibold text-foreground">Itinerary Not Found</h1>
          <p className="text-muted-foreground">
            We couldn't load this itinerary. Please check the link or contact support.
          </p>
          {isAuthResolved && user && (
            <Link href="/">
              <Button data-testid="button-back-home">
                Return to Dashboard
              </Button>
            </Link>
          )}
        </div>
      </div>
    );
  }

  const { itinerary, travelDetails, travellers, outboundTravel, accommodations: allAccommodations, activities: allActivities, dining: allDining, bars: allBars, additionalTravel: allAdditionalTravel, returnTravel, helpfulInformation } = data;

  // Filter out hidden items (visible === 0)
  const accommodations = allAccommodations?.filter(item => item.visible !== 0);
  const activities = allActivities?.filter(item => item.visible !== 0);
  const dining = allDining?.filter(item => item.visible !== 0);
  const bars = allBars?.filter(item => item.visible !== 0);
  const additionalTravel = allAdditionalTravel?.filter(item => item.visible !== 0);

  return (
    <>
      <Helmet>
        <title>{itinerary?.title || 'Travel Itinerary'} - BlckBx</title>
        <meta 
          name="description" 
          content={`View your personalized ${itinerary?.title || 'travel'} itinerary with accommodations, activities, dining, and travel arrangements.`} 
        />
        <meta property="og:title" content={`${itinerary?.title || 'Travel Itinerary'} - BlckBx`} />
        <meta 
          property="og:description" 
          content={`View your personalized ${itinerary?.title || 'travel'} itinerary with detailed travel planning.`} 
        />
        <meta property="og:type" content="website" />
      </Helmet>
      <div className="min-h-screen bg-background">
      <header className="sticky top-0 z-50 bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/80 border-b border-border">
        <div className="max-w-5xl mx-auto px-4 md:px-6 py-4">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              {isOwnershipDetermined && isOwner ? (
                <Link href="/">
                  <img 
                    src={logoUrl} 
                    alt="BlckBx" 
                    className="h-12 w-auto cursor-pointer hover-elevate active-elevate-2 rounded p-1"
                    data-testid="img-logo"
                  />
                </Link>
              ) : (
                <img 
                  src={logoUrl} 
                  alt="BlckBx" 
                  className="h-12 w-auto"
                  data-testid="img-logo"
                />
              )}
            </div>
            
            <div className="flex flex-wrap gap-2">
              {isOwnershipDetermined && isOwner && (
                <Link href={`/edit/${itinerary.id}`}>
                  <Button 
                    variant="outline"
                    size="sm"
                    className="gap-2"
                    data-testid="button-edit"
                  >
                    <Pencil className="w-4 h-4" />
                    Edit
                  </Button>
                </Link>
              )}
              
              <Button 
                variant="outline"
                size="sm"
                className="gap-2"
                onClick={handleWhatsAppShare}
                data-testid="button-share-whatsapp"
              >
                <SiWhatsapp className="w-4 h-4" />
                Share
              </Button>
              
              <PDFDownloadLink
                document={processedItinerary ? <ItineraryPDFTemplate data={processedItinerary} /> : <></>}
                fileName={`${data.itinerary.customUrlSlug}_BlckBx.pdf`}
              >
                {({ loading }) => (
                  <Button 
                    variant="outline"
                    size="sm"
                    className="gap-2"
                    disabled={loading || isProcessingImages}
                    data-testid="button-download-pdf"
                  >
                    {(loading || isProcessingImages) ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        {isProcessingImages ? 'Processing images...' : 'Generating...'}
                      </>
                    ) : (
                      <>
                        <Download className="w-4 h-4" />
                        PDF
                      </>
                    )}
                  </Button>
                )}
              </PDFDownloadLink>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-5xl mx-auto px-4 md:px-6 py-12">
        <div id="itinerary-content" className="space-y-12">
          {/* Header */}
          <div className="text-center space-y-4 pb-8 border-b">
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground" data-testid="text-title">
              {itinerary.title}
            </h1>
            
            {/* Share URL */}
            <div className="flex items-center justify-center gap-2 p-3 bg-muted rounded-lg max-w-2xl mx-auto">
              <p className="text-sm text-muted-foreground truncate flex-1">
                🔗 {window.location.href}
              </p>
              <Button
                size="sm"
                variant="outline"
                onClick={handleCopyLink}
                data-testid="button-copy-link"
              >
                {linkCopied ? (
                  <><Check className="w-4 h-4 mr-2" /> Copied!</>
                ) : (
                  <><Copy className="w-4 h-4 mr-2" /> Copy Link</>
                )}
              </Button>
            </div>
            
            {/* Travel Details */}
            {travelDetails && (
              <div className="space-y-2 text-lg text-muted-foreground">
                {travelDetails.dates && <p data-testid="text-dates">📅 {travelDetails.dates}</p>}
                {travelDetails.location && <p data-testid="text-location">📍 {travelDetails.location}</p>}
                {travelDetails.weather && (
                  <p data-testid="text-weather">
                    {getWeatherEmoji(travelDetails.weather)} {travelDetails.weather}
                  </p>
                )}
                {travelDetails.weatherUrl && (
                  <p>
                    <a 
                      href={travelDetails.weatherUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-2 text-[#6B1488] underline hover:text-[#5a1173]"
                      data-testid="link-weather"
                    >
                      {getWeatherEmoji(travelDetails.weather)} Click here to see live weather
                    </a>
                  </p>
                )}
              </div>
            )}
          </div>

          {/* Travellers */}
          {travellers && travellers.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Travellers</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {travellers.map((traveller, index) => (
                    <div key={traveller.id} className="flex items-center justify-between p-4 rounded-lg bg-muted/50">
                      <div>
                        <p className="font-medium" data-testid={`text-traveller-name-${index}`}>{traveller.name}</p>
                        <p className="text-sm text-muted-foreground" data-testid={`text-traveller-type-${index}`}>
                          {traveller.type === 'adult' ? 'Adult' : 'Child'}
                          {traveller.ageAtTravel && ` (Age: ${traveller.ageAtTravel})`}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Outbound Travel */}
          {outboundTravel && itinerary?.outboundTravelVisible !== 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Outbound Travel</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Transfer to Airport - Taxi */}
                {(outboundTravel.transferToAirportType === "taxi" || (!outboundTravel.transferToAirportType && outboundTravel.transferToAirportTaxiBooked === 1)) && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Transfer to Airport (Taxi)</h3>
                    {outboundTravel.transferToAirportTaxis && (outboundTravel.transferToAirportTaxis as any[]).length > 0 ? (
                      <div className="space-y-4">
                        {(outboundTravel.transferToAirportTaxis as any[]).map((taxi: any, index: number) => (
                          <div key={taxi.id || index} className="p-4 rounded-lg bg-muted/50">
                            <p className="font-medium mb-2">Taxi {index + 1}</p>
                            <div className="space-y-1 text-sm">
                              {taxi.company && <p><span className="font-medium">Company:</span> {taxi.company}</p>}
                              {taxi.contact && <p><span className="font-medium">Contact:</span> {taxi.contact}</p>}
                              {taxi.collectionTime && <p><span className="font-medium">Collection Time:</span> {taxi.collectionTime}</p>}
                              {taxi.pickupLocation && <p><span className="font-medium">Pickup:</span> {taxi.pickupLocation}</p>}
                              {taxi.paymentStatus && <p><span className="font-medium">Payment:</span> {taxi.paymentStatus}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2 text-sm">
                        {outboundTravel.transferToAirportCompany && <p><span className="font-medium">Company:</span> {outboundTravel.transferToAirportCompany}</p>}
                        {outboundTravel.transferToAirportContact && <p><span className="font-medium">Contact:</span> {outboundTravel.transferToAirportContact}</p>}
                        {outboundTravel.transferToAirportCollectionTime && <p><span className="font-medium">Collection Time:</span> {outboundTravel.transferToAirportCollectionTime}</p>}
                        {outboundTravel.transferToAirportPickupLocation && <p><span className="font-medium">Pickup:</span> {outboundTravel.transferToAirportPickupLocation}</p>}
                        {outboundTravel.transferToAirportPaymentStatus && <p><span className="font-medium">Payment:</span> {outboundTravel.transferToAirportPaymentStatus}</p>}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Transfer to Airport - Train */}
                {outboundTravel.transferToAirportType === "train" && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Transfer to Airport (Train)</h3>
                    {outboundTravel.transferToAirportTrains && (outboundTravel.transferToAirportTrains as any[]).length > 0 ? (
                      <div className="space-y-4">
                        {(outboundTravel.transferToAirportTrains as any[]).map((train: any, index: number) => (
                          <div key={train.id || index} className="p-4 rounded-lg bg-muted/50">
                            <p className="font-medium mb-2">Train {index + 1}</p>
                            <div className="space-y-1 text-sm">
                              {train.departingStation && <p><span className="font-medium">Departing Station:</span> {train.departingStation}</p>}
                              {train.arrivalStation && <p><span className="font-medium">Arrival Station:</span> {train.arrivalStation}</p>}
                              {train.departureTime && <p><span className="font-medium">Departure Time:</span> {train.departureTime}</p>}
                              {train.provider && <p><span className="font-medium">Provider:</span> {train.provider}</p>}
                              {train.bookingRef && <p><span className="font-medium">Booking Reference:</span> {train.bookingRef}</p>}
                              {train.paymentStatus && <p><span className="font-medium">Payment:</span> {train.paymentStatus}</p>}
                              {train.notes && <p><span className="font-medium">Notes:</span> {train.notes}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2 text-sm">
                        {outboundTravel.transferToAirportTrainDepartingStation && <p><span className="font-medium">Departing Station:</span> {outboundTravel.transferToAirportTrainDepartingStation}</p>}
                        {outboundTravel.transferToAirportTrainArrivalStation && <p><span className="font-medium">Arrival Station:</span> {outboundTravel.transferToAirportTrainArrivalStation}</p>}
                        {outboundTravel.transferToAirportTrainDepartureTime && <p><span className="font-medium">Departure Time:</span> {outboundTravel.transferToAirportTrainDepartureTime}</p>}
                        {outboundTravel.transferToAirportTrainProvider && <p><span className="font-medium">Provider:</span> {outboundTravel.transferToAirportTrainProvider}</p>}
                        {outboundTravel.transferToAirportTrainBookingRef && <p><span className="font-medium">Booking Reference:</span> {outboundTravel.transferToAirportTrainBookingRef}</p>}
                        {outboundTravel.transferToAirportTrainPaymentStatus && <p><span className="font-medium">Payment:</span> {outboundTravel.transferToAirportTrainPaymentStatus}</p>}
                        {outboundTravel.transferToAirportTrainNotes && <p><span className="font-medium">Notes:</span> {outboundTravel.transferToAirportTrainNotes}</p>}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Flight */}
                {outboundTravel.flightNumber && (
                  <FlightCard
                    flightNumber={outboundTravel.flightNumber}
                    date={outboundTravel.flightDate || ''}
                    departureAirport={outboundTravel.departureAirport || ''}
                    departureTime={outboundTravel.departureTime || ''}
                    arrivalAirport={outboundTravel.arrivalAirport || ''}
                    arrivalTime={outboundTravel.arrivalTime || ''}
                    passengers={outboundTravel.passengersSeats || undefined}
                    notes={outboundTravel.thingsToRemember || undefined}
                  />
                )}
                
                {/* Transfer to Accommodation - Taxi */}
                {(outboundTravel.transferToAccomType === "taxi" || (!outboundTravel.transferToAccomType && outboundTravel.transferToAccomTaxiBooked === 1)) && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Transfer to Accommodation (Taxi)</h3>
                    {outboundTravel.transferToAccomTaxis && (outboundTravel.transferToAccomTaxis as any[]).length > 0 ? (
                      <div className="space-y-4">
                        {(outboundTravel.transferToAccomTaxis as any[]).map((taxi: any, index: number) => (
                          <div key={taxi.id || index} className="p-4 rounded-lg bg-muted/50">
                            <p className="font-medium mb-2">Taxi {index + 1}</p>
                            <div className="space-y-1 text-sm">
                              {taxi.company && <p><span className="font-medium">Company:</span> {taxi.company}</p>}
                              {taxi.contact && <p><span className="font-medium">Contact:</span> {taxi.contact}</p>}
                              {taxi.collectionTime && <p><span className="font-medium">Collection Time:</span> {taxi.collectionTime}</p>}
                              {taxi.pickupLocation && <p><span className="font-medium">Pickup:</span> {taxi.pickupLocation}</p>}
                              {taxi.paymentStatus && <p><span className="font-medium">Payment:</span> {taxi.paymentStatus}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2 text-sm">
                        {outboundTravel.transferToAccomCompany && <p><span className="font-medium">Company:</span> {outboundTravel.transferToAccomCompany}</p>}
                        {outboundTravel.transferToAccomPickupLocation && <p><span className="font-medium">Pickup Location:</span> {outboundTravel.transferToAccomPickupLocation}</p>}
                        {outboundTravel.transferToAccomCollectionTime && <p><span className="font-medium">Collection Time:</span> {outboundTravel.transferToAccomCollectionTime}</p>}
                        {outboundTravel.transferToAccomContact && <p><span className="font-medium">Contact:</span> {outboundTravel.transferToAccomContact}</p>}
                        {outboundTravel.transferToAccomPaymentStatus && <p><span className="font-medium">Payment:</span> {outboundTravel.transferToAccomPaymentStatus}</p>}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Transfer to Accommodation - Train */}
                {outboundTravel.transferToAccomType === "train" && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Transfer to Accommodation (Train)</h3>
                    {outboundTravel.transferToAccomTrains && (outboundTravel.transferToAccomTrains as any[]).length > 0 ? (
                      <div className="space-y-4">
                        {(outboundTravel.transferToAccomTrains as any[]).map((train: any, index: number) => (
                          <div key={train.id || index} className="p-4 rounded-lg bg-muted/50">
                            <p className="font-medium mb-2">Train {index + 1}</p>
                            <div className="space-y-1 text-sm">
                              {train.departingStation && <p><span className="font-medium">Departing Station:</span> {train.departingStation}</p>}
                              {train.arrivalStation && <p><span className="font-medium">Arrival Station:</span> {train.arrivalStation}</p>}
                              {train.departureTime && <p><span className="font-medium">Departure Time:</span> {train.departureTime}</p>}
                              {train.provider && <p><span className="font-medium">Provider:</span> {train.provider}</p>}
                              {train.bookingRef && <p><span className="font-medium">Booking Reference:</span> {train.bookingRef}</p>}
                              {train.paymentStatus && <p><span className="font-medium">Payment:</span> {train.paymentStatus}</p>}
                              {train.notes && <p><span className="font-medium">Notes:</span> {train.notes}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2 text-sm">
                        {outboundTravel.transferToAccomTrainDepartingStation && <p><span className="font-medium">Departing Station:</span> {outboundTravel.transferToAccomTrainDepartingStation}</p>}
                        {outboundTravel.transferToAccomTrainArrivalStation && <p><span className="font-medium">Arrival Station:</span> {outboundTravel.transferToAccomTrainArrivalStation}</p>}
                        {outboundTravel.transferToAccomTrainDepartureTime && <p><span className="font-medium">Departure Time:</span> {outboundTravel.transferToAccomTrainDepartureTime}</p>}
                        {outboundTravel.transferToAccomTrainProvider && <p><span className="font-medium">Provider:</span> {outboundTravel.transferToAccomTrainProvider}</p>}
                        {outboundTravel.transferToAccomTrainBookingRef && <p><span className="font-medium">Booking Reference:</span> {outboundTravel.transferToAccomTrainBookingRef}</p>}
                        {outboundTravel.transferToAccomTrainPaymentStatus && <p><span className="font-medium">Payment:</span> {outboundTravel.transferToAccomTrainPaymentStatus}</p>}
                        {outboundTravel.transferToAccomTrainNotes && <p><span className="font-medium">Notes:</span> {outboundTravel.transferToAccomTrainNotes}</p>}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Accommodations */}
          {accommodations && accommodations.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Accommodation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {accommodations.map((accom) => (
                    <div key={accom.id} className="p-6 rounded-lg border bg-card">
                      <h3 className="font-semibold text-xl mb-4">{accom.name}</h3>
                      <div className="space-y-3">
                        {accom.address && (
                          <div className="flex items-start gap-2">
                            <MapPin className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                            <p className="text-sm">{accom.address}</p>
                          </div>
                        )}
                        {/* Links stacked vertically */}
                        <div className="flex flex-col gap-1">
                          {accom.googleMapsLink && (
                            <a 
                              href={accom.googleMapsLink} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 text-sm text-[#6B1488] underline hover:text-[#5a1173]"
                              data-testid="link-accommodation-google-maps"
                            >
                              <ExternalLink className="w-4 h-4" />
                              View on Google Maps
                            </a>
                          )}
                          {accom.websiteUrl && (
                            <a 
                              href={accom.websiteUrl} 
                              target="_blank" 
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-2 text-sm text-[#6B1488] underline hover:text-[#5a1173]"
                              data-testid="link-accommodation-website"
                            >
                              View Website
                            </a>
                          )}
                        </div>
                        {accom.checkInDetails && (
                          <div className="mt-4 p-4 bg-muted rounded-lg">
                            <p className="font-medium mb-2">Check-in Details:</p>
                            <p className="text-sm whitespace-pre-wrap">{accom.checkInDetails}</p>
                          </div>
                        )}
                        {accom.notes && (
                          <div className="mt-4 p-4 bg-muted rounded-lg">
                            <p className="font-medium mb-2">Notes:</p>
                            <p className="text-sm whitespace-pre-wrap">{accom.notes}</p>
                          </div>
                        )}
                        {accom.images && accom.images.length > 0 && (
                          <div className="mt-4 space-y-4">
                            {accom.images.map((img, idx) => (
                              <img 
                                key={idx}
                                src={img} 
                                alt={`${accom.name} - ${idx + 1}`}
                                className="w-full h-auto object-cover rounded-lg"
                              />
                            ))}
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Activities */}
          {activities && activities.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Activities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {activities.map((activity) => (
                    <div key={activity.id} className="p-6 rounded-lg border bg-card">
                      <div className="flex items-start justify-between mb-4">
                        <h3 className="font-semibold text-xl">{activity.name}</h3>
                        {activity.price && (
                          <span className="font-semibold text-primary text-[20px]">{activity.price}</span>
                        )}
                      </div>
                      {activity.description && (
                        <p className="text-sm text-muted-foreground whitespace-pre-wrap mb-4">{activity.description}</p>
                      )}
                      <div className="space-y-2">
                        {activity.address && (
                          <div className="flex items-start gap-2">
                            <MapPin className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                            <p className="text-sm">{activity.address}</p>
                          </div>
                        )}
                        {activity.googleMapsLink && (
                          <a 
                            href={activity.googleMapsLink} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-2 text-sm text-[#6B1488] underline hover:text-[#5a1173]"
                            data-testid="link-activity-google-maps"
                          >
                            <ExternalLink className="w-4 h-4" />
                            View on Google Maps
                          </a>
                        )}
                      </div>
                      {activity.websiteUrl && (
                        <a 
                          href={activity.websiteUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 text-sm text-[#6B1488] underline hover:text-[#5a1173] mb-4"
                          data-testid="link-activity-website"
                        >
                          View Website
                        </a>
                      )}
                      {activity.notes && (
                        <div className="mt-4 p-4 bg-muted rounded-lg">
                          <p className="font-medium mb-2">Notes:</p>
                          <p className="text-sm whitespace-pre-wrap">{activity.notes}</p>
                        </div>
                      )}
                      {activity.images && activity.images.length > 0 && (
                        <div className="mt-4 space-y-4">
                          {activity.images.map((img, idx) => (
                            <img 
                              key={idx}
                              src={img} 
                              alt={`${activity.name} - ${idx + 1}`}
                              className="w-full h-auto object-cover rounded-lg"
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Dining */}
          {dining && dining.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Dining</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {dining.map((restaurant) => (
                    <div key={restaurant.id} className="p-6 rounded-lg border bg-card">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="font-semibold text-xl">{restaurant.name}</h3>
                          {restaurant.cuisineType && (
                            <p className="text-sm text-muted-foreground mt-1">{restaurant.cuisineType}</p>
                          )}
                        </div>
                        {restaurant.priceRange && (
                          <span className="font-semibold text-primary text-[20px]">{restaurant.priceRange}</span>
                        )}
                      </div>
                      <div className="space-y-2">
                        {restaurant.address && (
                          <div className="flex items-start gap-2">
                            <MapPin className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                            <p className="text-sm">{restaurant.address}</p>
                          </div>
                        )}
                        {restaurant.googleMapsLink && (
                          <a 
                            href={restaurant.googleMapsLink} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-2 text-sm text-[#6B1488] underline hover:text-[#5a1173]"
                            data-testid="link-dining-google-maps"
                          >
                            <ExternalLink className="w-4 h-4" />
                            View on Google Maps
                          </a>
                        )}
                      </div>
                      {restaurant.websiteUrl && (
                        <a 
                          href={restaurant.websiteUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 text-sm text-[#6B1488] underline hover:text-[#5a1173] mb-4"
                          data-testid="link-dining-website"
                        >
                          View Website
                        </a>
                      )}
                      {restaurant.notes && (
                        <div className="mt-4 p-4 bg-muted rounded-lg">
                          <p className="font-medium mb-2">Notes:</p>
                          <p className="text-sm whitespace-pre-wrap">{restaurant.notes}</p>
                        </div>
                      )}
                      {restaurant.images && restaurant.images.length > 0 && (
                        <div className="mt-4 space-y-4">
                          {restaurant.images.map((img, idx) => (
                            <img 
                              key={idx}
                              src={img} 
                              alt={`${restaurant.name} - ${idx + 1}`}
                              className="w-full h-auto object-cover rounded-lg"
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Bars and Pubs */}
          {bars && bars.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Bars and Pubs</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {bars.map((bar) => (
                    <div key={bar.id} className="p-6 rounded-lg border bg-card">
                      <div className="flex items-start justify-between mb-4">
                        <div>
                          <h3 className="font-semibold text-xl">{bar.name}</h3>
                          {bar.barType && (
                            <p className="text-sm text-muted-foreground mt-1">{bar.barType}</p>
                          )}
                        </div>
                        {bar.priceRange && (
                          <span className="font-semibold text-primary text-[20px]">{bar.priceRange}</span>
                        )}
                      </div>
                      <div className="space-y-2">
                        {bar.address && (
                          <div className="flex items-start gap-2">
                            <MapPin className="w-5 h-5 text-muted-foreground mt-0.5 flex-shrink-0" />
                            <p className="text-sm">{bar.address}</p>
                          </div>
                        )}
                        {bar.googleMapsLink && (
                          <a 
                            href={bar.googleMapsLink} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="inline-flex items-center gap-2 text-sm text-[#6B1488] underline hover:text-[#5a1173]"
                            data-testid="link-bar-google-maps"
                          >
                            <ExternalLink className="w-4 h-4" />
                            View on Google Maps
                          </a>
                        )}
                      </div>
                      {bar.websiteUrl && (
                        <a 
                          href={bar.websiteUrl} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-2 text-sm text-[#6B1488] underline hover:text-[#5a1173] mb-4"
                          data-testid="link-bar-website"
                        >
                          View Website
                        </a>
                      )}
                      {bar.notes && (
                        <div className="mt-4 p-4 bg-muted rounded-lg">
                          <p className="font-medium mb-2">Notes:</p>
                          <p className="text-sm whitespace-pre-wrap">{bar.notes}</p>
                        </div>
                      )}
                      {bar.images && bar.images.length > 0 && (
                        <div className="mt-4 space-y-4">
                          {bar.images.map((img, idx) => (
                            <img 
                              key={idx}
                              src={img} 
                              alt={`${bar.name} - ${idx + 1}`}
                              className="w-full h-auto object-cover rounded-lg"
                            />
                          ))}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Additional Travel */}
          {additionalTravelItems && additionalTravelItems.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Additional Travel</CardTitle>
              </CardHeader>
              <CardContent>
                <DndContext
                  sensors={sensors}
                  collisionDetection={closestCenter}
                  onDragEnd={handleAdditionalTravelDragEnd}
                >
                  <SortableContext
                    items={additionalTravelItems.map((item) => item.id)}
                    strategy={verticalListSortingStrategy}
                  >
                    <div className="space-y-4">
                      {additionalTravelItems.map((travel) => (
                        <SortableTravelItem
                          key={travel.id}
                          travel={travel}
                        />
                      ))}
                    </div>
                  </SortableContext>
                </DndContext>
              </CardContent>
            </Card>
          )}

          {/* Return Travel */}
          {returnTravel && itinerary?.returnTravelVisible !== 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Return Travel</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6 pl-[16px] pr-[16px]">
                {/* Transfer to Airport - Taxi */}
                {(returnTravel.transferToAirportType === "taxi" || (!returnTravel.transferToAirportType && returnTravel.transferToAirportTaxiBooked === 1)) && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Transfer to Airport (Taxi)</h3>
                    {returnTravel.transferToAirportTaxis && (returnTravel.transferToAirportTaxis as any[]).length > 0 ? (
                      <div className="space-y-4">
                        {(returnTravel.transferToAirportTaxis as any[]).map((taxi: any, index: number) => (
                          <div key={taxi.id || index} className="p-4 rounded-lg bg-muted/50">
                            <p className="font-medium mb-2">Taxi {index + 1}</p>
                            <div className="space-y-1 text-sm">
                              {taxi.company && <p><span className="font-medium">Company:</span> {taxi.company}</p>}
                              {taxi.contact && <p><span className="font-medium">Contact:</span> {taxi.contact}</p>}
                              {taxi.collectionTime && <p><span className="font-medium">Collection Time:</span> {taxi.collectionTime}</p>}
                              {taxi.pickupLocation && <p><span className="font-medium">Pickup:</span> {taxi.pickupLocation}</p>}
                              {taxi.paymentStatus && <p><span className="font-medium">Payment:</span> {taxi.paymentStatus}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2 text-sm">
                        {returnTravel.transferToAirportCompany && <p><span className="font-medium">Company:</span> {returnTravel.transferToAirportCompany}</p>}
                        {returnTravel.transferToAirportContact && <p><span className="font-medium">Contact:</span> {returnTravel.transferToAirportContact}</p>}
                        {returnTravel.transferToAirportCollectionTime && <p><span className="font-medium">Collection Time:</span> {returnTravel.transferToAirportCollectionTime}</p>}
                        {returnTravel.transferToAirportPickupLocation && <p><span className="font-medium">Pickup:</span> {returnTravel.transferToAirportPickupLocation}</p>}
                        {returnTravel.transferToAirportPaymentStatus && <p><span className="font-medium">Payment:</span> {returnTravel.transferToAirportPaymentStatus}</p>}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Transfer to Airport - Train */}
                {returnTravel.transferToAirportType === "train" && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Transfer to Airport (Train)</h3>
                    {returnTravel.transferToAirportTrains && (returnTravel.transferToAirportTrains as any[]).length > 0 ? (
                      <div className="space-y-4">
                        {(returnTravel.transferToAirportTrains as any[]).map((train: any, index: number) => (
                          <div key={train.id || index} className="p-4 rounded-lg bg-muted/50">
                            <p className="font-medium mb-2">Train {index + 1}</p>
                            <div className="space-y-1 text-sm">
                              {train.departingStation && <p><span className="font-medium">Departing Station:</span> {train.departingStation}</p>}
                              {train.arrivalStation && <p><span className="font-medium">Arrival Station:</span> {train.arrivalStation}</p>}
                              {train.departureTime && <p><span className="font-medium">Departure Time:</span> {train.departureTime}</p>}
                              {train.provider && <p><span className="font-medium">Provider:</span> {train.provider}</p>}
                              {train.bookingRef && <p><span className="font-medium">Booking Reference:</span> {train.bookingRef}</p>}
                              {train.paymentStatus && <p><span className="font-medium">Payment:</span> {train.paymentStatus}</p>}
                              {train.notes && <p><span className="font-medium">Notes:</span> {train.notes}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2 text-sm">
                        {returnTravel.transferToAirportTrainDepartingStation && <p><span className="font-medium">Departing Station:</span> {returnTravel.transferToAirportTrainDepartingStation}</p>}
                        {returnTravel.transferToAirportTrainArrivalStation && <p><span className="font-medium">Arrival Station:</span> {returnTravel.transferToAirportTrainArrivalStation}</p>}
                        {returnTravel.transferToAirportTrainDepartureTime && <p><span className="font-medium">Departure Time:</span> {returnTravel.transferToAirportTrainDepartureTime}</p>}
                        {returnTravel.transferToAirportTrainProvider && <p><span className="font-medium">Provider:</span> {returnTravel.transferToAirportTrainProvider}</p>}
                        {returnTravel.transferToAirportTrainBookingRef && <p><span className="font-medium">Booking Reference:</span> {returnTravel.transferToAirportTrainBookingRef}</p>}
                        {returnTravel.transferToAirportTrainPaymentStatus && <p><span className="font-medium">Payment:</span> {returnTravel.transferToAirportTrainPaymentStatus}</p>}
                        {returnTravel.transferToAirportTrainNotes && <p><span className="font-medium">Notes:</span> {returnTravel.transferToAirportTrainNotes}</p>}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Return Flight */}
                {returnTravel.flightNumber && (
                  <FlightCard
                    flightNumber={returnTravel.flightNumber}
                    date={returnTravel.flightDate || ''}
                    departureAirport={returnTravel.departureAirport || ''}
                    departureTime={returnTravel.departureTime || ''}
                    arrivalAirport={returnTravel.arrivalAirport || ''}
                    arrivalTime={returnTravel.arrivalTime || ''}
                    passengers={returnTravel.passengersSeats || undefined}
                    notes={returnTravel.thingsToRemember || undefined}
                  />
                )}
                
                {/* Transfer Home - Taxi */}
                {(returnTravel.transferHomeType === "taxi" || (!returnTravel.transferHomeType && returnTravel.transferHomeTaxiBooked === 1)) && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Transfer Home (Taxi)</h3>
                    {returnTravel.transferHomeTaxis && (returnTravel.transferHomeTaxis as any[]).length > 0 ? (
                      <div className="space-y-4">
                        {(returnTravel.transferHomeTaxis as any[]).map((taxi: any, index: number) => (
                          <div key={taxi.id || index} className="p-4 rounded-lg bg-muted/50">
                            <p className="font-medium mb-2">Taxi {index + 1}</p>
                            <div className="space-y-1 text-sm">
                              {taxi.company && <p><span className="font-medium">Company:</span> {taxi.company}</p>}
                              {taxi.contact && <p><span className="font-medium">Contact:</span> {taxi.contact}</p>}
                              {taxi.collectionTime && <p><span className="font-medium">Collection Time:</span> {taxi.collectionTime}</p>}
                              {taxi.pickupLocation && <p><span className="font-medium">Pickup:</span> {taxi.pickupLocation}</p>}
                              {taxi.paymentStatus && <p><span className="font-medium">Payment:</span> {taxi.paymentStatus}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2 text-sm">
                        {returnTravel.transferHomeCompany && <p><span className="font-medium">Company:</span> {returnTravel.transferHomeCompany}</p>}
                        {returnTravel.transferHomePickupLocation && <p><span className="font-medium">Pickup Location:</span> {returnTravel.transferHomePickupLocation}</p>}
                        {returnTravel.transferHomeCollectionTime && <p><span className="font-medium">Collection Time:</span> {returnTravel.transferHomeCollectionTime}</p>}
                        {returnTravel.transferHomeContact && <p><span className="font-medium">Contact:</span> {returnTravel.transferHomeContact}</p>}
                        {returnTravel.transferHomePaymentStatus && <p><span className="font-medium">Payment:</span> {returnTravel.transferHomePaymentStatus}</p>}
                      </div>
                    )}
                  </div>
                )}
                
                {/* Transfer Home - Train */}
                {returnTravel.transferHomeType === "train" && (
                  <div>
                    <h3 className="font-semibold text-lg mb-3">Transfer Home (Train)</h3>
                    {returnTravel.transferHomeTrains && (returnTravel.transferHomeTrains as any[]).length > 0 ? (
                      <div className="space-y-4">
                        {(returnTravel.transferHomeTrains as any[]).map((train: any, index: number) => (
                          <div key={train.id || index} className="p-4 rounded-lg bg-muted/50">
                            <p className="font-medium mb-2">Train {index + 1}</p>
                            <div className="space-y-1 text-sm">
                              {train.departingStation && <p><span className="font-medium">Departing Station:</span> {train.departingStation}</p>}
                              {train.arrivalStation && <p><span className="font-medium">Arrival Station:</span> {train.arrivalStation}</p>}
                              {train.departureTime && <p><span className="font-medium">Departure Time:</span> {train.departureTime}</p>}
                              {train.provider && <p><span className="font-medium">Provider:</span> {train.provider}</p>}
                              {train.bookingRef && <p><span className="font-medium">Booking Reference:</span> {train.bookingRef}</p>}
                              {train.paymentStatus && <p><span className="font-medium">Payment:</span> {train.paymentStatus}</p>}
                              {train.notes && <p><span className="font-medium">Notes:</span> {train.notes}</p>}
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <div className="space-y-2 text-sm">
                        {returnTravel.transferHomeTrainDepartingStation && <p><span className="font-medium">Departing Station:</span> {returnTravel.transferHomeTrainDepartingStation}</p>}
                        {returnTravel.transferHomeTrainArrivalStation && <p><span className="font-medium">Arrival Station:</span> {returnTravel.transferHomeTrainArrivalStation}</p>}
                        {returnTravel.transferHomeTrainDepartureTime && <p><span className="font-medium">Departure Time:</span> {returnTravel.transferHomeTrainDepartureTime}</p>}
                        {returnTravel.transferHomeTrainProvider && <p><span className="font-medium">Provider:</span> {returnTravel.transferHomeTrainProvider}</p>}
                        {returnTravel.transferHomeTrainBookingRef && <p><span className="font-medium">Booking Reference:</span> {returnTravel.transferHomeTrainBookingRef}</p>}
                        {returnTravel.transferHomeTrainPaymentStatus && <p><span className="font-medium">Payment:</span> {returnTravel.transferHomeTrainPaymentStatus}</p>}
                        {returnTravel.transferHomeTrainNotes && <p><span className="font-medium">Notes:</span> {returnTravel.transferHomeTrainNotes}</p>}
                      </div>
                    )}
                  </div>
                )}
              </CardContent>
            </Card>
          )}

          {/* Helpful Information */}
          {helpfulInformation && itinerary?.helpfulInfoVisible !== 0 && (
            <Card>
              <CardHeader>
                <CardTitle className="text-2xl">Helpful Information</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid md:grid-cols-2 gap-4">
                  {helpfulInformation.localEmergency && (
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Local Emergency</p>
                      <p className="text-sm">{helpfulInformation.localEmergency}</p>
                    </div>
                  )}
                  {helpfulInformation.nearestEmbassy && (
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Nearest Embassy</p>
                      <p className="text-sm">{helpfulInformation.nearestEmbassy}</p>
                    </div>
                  )}
                  {helpfulInformation.travelInsurance && (
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Travel Insurance</p>
                      <p className="text-sm">{helpfulInformation.travelInsurance}</p>
                    </div>
                  )}
                  {helpfulInformation.airlineCustomerService && (
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Airline Customer Service</p>
                      <p className="text-sm">{helpfulInformation.airlineCustomerService}</p>
                    </div>
                  )}
                  {helpfulInformation.localMedicalClinic && (
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Local Medical Clinic</p>
                      <p className="text-sm">{helpfulInformation.localMedicalClinic}</p>
                    </div>
                  )}
                  {helpfulInformation.transportContacts && (
                    <div className="p-4 rounded-lg bg-muted">
                      <p className="font-medium text-sm mb-1">Transport Contacts</p>
                      <p className="text-sm">{helpfulInformation.transportContacts}</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Map Visualization */}
          {mapLocations.length > 0 && (
            <MapVisualization locations={mapLocations} />
          )}

          {/* Footer - Assistant Info */}
          <div className="pt-8 border-t text-center space-y-2">
            <p className="text-sm text-muted-foreground">
              Prepared by <span className="font-semibold text-foreground">{itinerary.assistantName}</span>
            </p>
            <a 
              href={`mailto:${itinerary.assistantEmail}`}
              className="block text-sm text-[#6B1488] underline hover:text-[#5a1173]"
              data-testid="link-assistant-email"
            >
              {itinerary.assistantEmail}
            </a>
          </div>
        </div>
      </main>
    </div>
    </>
  );
}
