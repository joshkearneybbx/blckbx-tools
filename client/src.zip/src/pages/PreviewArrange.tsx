import { useEffect, useState, useMemo } from "react";
import { useParams, useLocation, Link } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Switch } from "@/components/ui/switch";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Separator } from "@/components/ui/separator";
import { ArrowLeft, Send } from "lucide-react";
import type { FullItinerary, AdditionalTravel } from "@shared/schema";
import { collectLocationsFromItinerary } from "@/lib/collectLocations";
import logoUrl from "@assets/blckbx-logo.png";
import {
  DndContext,
  closestCenter,
  KeyboardSensor,
  PointerSensor,
  useSensor,
  useSensors,
  DragEndEvent,
} from "@dnd-kit/core";
import {
  arrayMove,
  SortableContext,
  sortableKeyboardCoordinates,
  useSortable,
  verticalListSortingStrategy,
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";

// Sortable Additional Travel Item component
function SortableAdditionalTravelCard({ 
  travel, 
  visible, 
  onToggleVisibility 
}: { 
  travel: AdditionalTravel; 
  visible: boolean;
  onToggleVisibility: () => void;
}) {
  const {
    attributes,
    listeners,
    setNodeRef,
    transform,
    transition,
    isDragging,
  } = useSortable({ id: travel.id });

  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
    zIndex: isDragging ? 50 : undefined,
    touchAction: 'none' as const,
  };

  return (
    <Card
      ref={setNodeRef}
      style={style}
      className={`${!visible ? 'bg-muted/50' : ''} ${isDragging ? 'shadow-xl ring-2 ring-[#6B1488]' : ''}`}
    >
      <CardHeader className="pb-3">
        <div className="flex items-center gap-3">
          {/* Functional drag handle button */}
          <button
            type="button"
            {...listeners}
            {...attributes}
            className="flex flex-col gap-1 cursor-grab active:cursor-grabbing hover:opacity-70 transition-opacity touch-none p-1 -m-1"
            style={{ touchAction: 'none' }}
            aria-label="Drag to reorder"
          >
            <div className="flex gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-gray-500"></div>
              <div className="w-1.5 h-1.5 rounded-full bg-gray-500"></div>
            </div>
            <div className="flex gap-1">
              <div className="w-1.5 h-1.5 rounded-full bg-gray-500"></div>
              <div className="w-1.5 h-1.5 rounded-full bg-gray-500"></div>
            </div>
          </button>
          <CardTitle className="flex-1">
            {travel.travelType.charAt(0).toUpperCase() + travel.travelType.slice(1)}
          </CardTitle>
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">
              {visible ? 'Visible' : 'Hidden'}
            </span>
            <Switch
              checked={visible}
              onCheckedChange={onToggleVisibility}
            />
          </div>
        </div>
      </CardHeader>
      {visible && (
        <>
          <Separator />
          <CardContent className="pt-4">
            <div className="space-y-2">
              {travel.travelType === 'car' && (
                <>
                  {travel.vehicleDetails && <p><strong>Vehicle:</strong> {travel.vehicleDetails}</p>}
                  {travel.vehicleRegistration && <p><strong>Registration:</strong> {travel.vehicleRegistration}</p>}
                  {travel.carContactDetails && <p><strong>Contact:</strong> {travel.carContactDetails}</p>}
                </>
              )}
              {travel.travelType === 'flight' && (
                <>
                  {travel.flightNumber && <p><strong>Flight Number:</strong> {travel.flightNumber}</p>}
                  {travel.flightDate && <p><strong>Date:</strong> {travel.flightDate}</p>}
                  {(travel.flightDepartureAirport || travel.flightDepartureTime) && (
                    <p><strong>Departure:</strong> {travel.flightDepartureAirport} {travel.flightDepartureTime && `at ${travel.flightDepartureTime}`}</p>
                  )}
                  {(travel.flightArrivalAirport || travel.flightArrivalTime) && (
                    <p><strong>Arrival:</strong> {travel.flightArrivalAirport} {travel.flightArrivalTime && `at ${travel.flightArrivalTime}`}</p>
                  )}
                </>
              )}
              {travel.travelType === 'ferry' && (
                <>
                  {travel.ferryDepartingFrom && <p><strong>From:</strong> {travel.ferryDepartingFrom}</p>}
                  {travel.ferryDestination && <p><strong>To:</strong> {travel.ferryDestination}</p>}
                  {travel.ferryDate && <p><strong>Date:</strong> {travel.ferryDate}</p>}
                  {travel.ferryPrice && <p><strong>Price:</strong> {travel.ferryPrice}</p>}
                </>
              )}
              {travel.travelType === 'train' && (
                <>
                  {travel.trainDepartingFrom && <p><strong>From:</strong> {travel.trainDepartingFrom}</p>}
                  {travel.trainDestination && <p><strong>To:</strong> {travel.trainDestination}</p>}
                  {travel.trainDate && <p><strong>Date:</strong> {travel.trainDate}</p>}
                  {travel.trainPrice && <p><strong>Price:</strong> {travel.trainPrice}</p>}
                </>
              )}
            </div>
          </CardContent>
        </>
      )}
    </Card>
  );
}

type SectionConfig = {
  id: string;
  type: string;
  title: string;
  order: number;
  visible: boolean;
  content: React.ReactNode;
};

const FIXED_SECTION_ORDER: Record<string, number> = {
  'travellers': 10,
  'outboundTravel': 20,
  'accommodation': 30,
  'activity': 40,
  'dining': 50,
  'additionalTravel': 60,
  'returnTravel': 70,
  'helpfulInformation': 80,
  'locationOverview': 90,
};

export default function PreviewArrange() {
  const { id } = useParams();
  const [, setLocation] = useLocation();
  const [sections, setSections] = useState<SectionConfig[]>([]);
  const [additionalTravelItems, setAdditionalTravelItems] = useState<AdditionalTravel[]>([]);
  const [additionalTravelVisibility, setAdditionalTravelVisibility] = useState<Record<string, boolean>>({});

  // Set up sensors for drag detection with activation constraint
  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    }),
    useSensor(KeyboardSensor, {
      coordinateGetter: sortableKeyboardCoordinates,
    })
  );

  // Handle drag end for additional travel reordering
  const handleAdditionalTravelDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;

    if (over && active.id !== over.id) {
      setAdditionalTravelItems((items) => {
        const oldIndex = items.findIndex((item) => item.id === active.id);
        const newIndex = items.findIndex((item) => item.id === over.id);
        return arrayMove(items, oldIndex, newIndex);
      });
    }
  };

  // Toggle visibility for additional travel items
  const toggleAdditionalTravelVisibility = (travelId: string) => {
    setAdditionalTravelVisibility((prev) => ({
      ...prev,
      [travelId]: !prev[travelId],
    }));
  };

  const { data: itinerary, isLoading } = useQuery<FullItinerary>({
    queryKey: ['/api/itineraries', id],
    enabled: !!id,
  });

  useEffect(() => {
    if (itinerary) {
      const initialSections: SectionConfig[] = [];

      if (itinerary?.travellers?.length > 0) {
        initialSections.push({
          id: 'travellers',
          type: 'travellers',
          title: 'Travellers',
          order: FIXED_SECTION_ORDER.travellers,
          visible: true,
          content: (
            <div className="space-y-2">
              {itinerary.travellers.map((traveller, idx) => (
                <p key={idx}>{traveller.name} ({traveller.type === 'adult' ? 'Adult' : 'Child'}{traveller.ageAtTravel ? `, Age: ${traveller.ageAtTravel}` : ''})</p>
              ))}
            </div>
          ),
        });
      }

      if (itinerary.outboundTravel) {
        const ob = itinerary.outboundTravel;
        initialSections.push({
          id: 'outbound-travel',
          type: 'outboundTravel',
          title: 'Outbound Travel',
          order: FIXED_SECTION_ORDER.outboundTravel,
          visible: itinerary.itinerary.outboundTravelVisible !== 0,
          content: (
            <div className="space-y-3">
              {ob.transferToAirportCompany && (
                <div>
                  <p className="font-semibold">Transfer to Airport</p>
                  <p>{ob.transferToAirportCompany} - {ob.transferToAirportContact}</p>
                  <p>Collection: {ob.transferToAirportCollectionTime}</p>
                </div>
              )}
              {ob.flightNumber && (
                <div>
                  <p className="font-semibold">Flight</p>
                  <p>{ob.flightNumber}: {ob.departureAirport} {ob.departureTime && `at ${ob.departureTime}`} → {ob.arrivalAirport} {ob.arrivalTime && `at ${ob.arrivalTime}`}</p>
                </div>
              )}
              {ob.transferToAccomCompany && (
                <div>
                  <p className="font-semibold">Transfer to Accommodation</p>
                  <p>{ob.transferToAccomCompany}</p>
                </div>
              )}
            </div>
          ),
        });
      }

      itinerary.accommodations?.forEach((acc, idx) => {
        const baseOrder = FIXED_SECTION_ORDER.accommodation;
        const itemOrder = acc.displayOrder ?? idx;
        initialSections.push({
          id: `accommodation-${acc.id}`,
          type: 'accommodation',
          title: acc.name || `Accommodation`,
          order: baseOrder + (itemOrder * 0.01),
          visible: acc.visible !== 0,
          content: (
            <div className="space-y-2">
              {acc.address && <p><strong>Address:</strong> {acc.address}</p>}
              {acc.checkInDetails && <p><strong>Check-in Details:</strong> {acc.checkInDetails}</p>}
              {acc.googleMapsLink && <p><a href={acc.googleMapsLink} target="_blank" rel="noopener noreferrer" className="text-primary hover:underline">View on Google Maps</a></p>}
            </div>
          ),
        });
      });

      itinerary.activities?.forEach((activity, idx) => {
        const baseOrder = FIXED_SECTION_ORDER.activity;
        const itemOrder = activity.displayOrder ?? idx;
        initialSections.push({
          id: `activity-${activity.id}`,
          type: 'activity',
          title: activity.name || `Activity`,
          order: baseOrder + (itemOrder * 0.01),
          visible: activity.visible !== 0,
          content: (
            <div className="space-y-2">
              {activity.description && <p>{activity.description}</p>}
              {activity.price && <p><strong>Price:</strong> {activity.price}</p>}
            </div>
          ),
        });
      });

      itinerary.dining?.forEach((restaurant, idx) => {
        const baseOrder = FIXED_SECTION_ORDER.dining;
        const itemOrder = restaurant.displayOrder ?? idx;
        initialSections.push({
          id: `dining-${restaurant.id}`,
          type: 'dining',
          title: restaurant.name || `Restaurant`,
          order: baseOrder + (itemOrder * 0.01),
          visible: restaurant.visible !== 0,
          content: (
            <div className="space-y-2">
              {restaurant.cuisineType && <p><strong>Cuisine:</strong> {restaurant.cuisineType}</p>}
              {restaurant.priceRange && <p><strong>Price:</strong> {restaurant.priceRange}</p>}
            </div>
          ),
        });
      });

      // Initialize additional travel items with their own state (for drag-and-drop)
      if (itinerary.additionalTravel && itinerary.additionalTravel.length > 0) {
        setAdditionalTravelItems([...itinerary.additionalTravel]);
        // Initialize visibility from database (visible !== 0 means visible)
        const visibility: Record<string, boolean> = {};
        itinerary.additionalTravel.forEach((travel) => {
          visibility[travel.id] = travel.visible !== 0;
        });
        setAdditionalTravelVisibility(visibility);
      }

      if (itinerary.returnTravel) {
        const rt = itinerary.returnTravel;
        initialSections.push({
          id: 'return-travel',
          type: 'returnTravel',
          title: 'Return Travel',
          order: FIXED_SECTION_ORDER.returnTravel,
          visible: itinerary.itinerary.returnTravelVisible !== 0,
          content: (
            <div className="space-y-3">
              {rt.transferToAirportCompany && (
                <div>
                  <p className="font-semibold">Transfer to Airport</p>
                  <p>{rt.transferToAirportCompany} - {rt.transferToAirportContact}</p>
                  <p>Collection: {rt.transferToAirportCollectionTime}</p>
                </div>
              )}
              {rt.flightNumber && (
                <div>
                  <p className="font-semibold">Return Flight</p>
                  <p>{rt.flightNumber}: {rt.departureAirport} {rt.departureTime && `at ${rt.departureTime}`} → {rt.arrivalAirport} {rt.arrivalTime && `at ${rt.arrivalTime}`}</p>
                </div>
              )}
              {rt.transferHomeCompany && (
                <div>
                  <p className="font-semibold">Transfer Home</p>
                  <p>{rt.transferHomeCompany}</p>
                </div>
              )}
            </div>
          ),
        });
      }

      if (itinerary.helpfulInformation) {
        const info = itinerary.helpfulInformation;
        initialSections.push({
          id: 'helpful-information',
          type: 'helpfulInformation',
          title: 'Helpful Information',
          order: FIXED_SECTION_ORDER.helpfulInformation,
          visible: itinerary.itinerary.helpfulInfoVisible !== 0,
          content: (
            <div className="space-y-2">
              {info.localEmergency && <p><strong>Local Emergency:</strong> {info.localEmergency}</p>}
              {info.nearestEmbassy && <p><strong>Nearest Embassy:</strong> {info.nearestEmbassy}</p>}
              {info.travelInsurance && <p><strong>Travel Insurance:</strong> {info.travelInsurance}</p>}
              {info.airlineCustomerService && <p><strong>Airline Customer Service:</strong> {info.airlineCustomerService}</p>}
            </div>
          ),
        });
      }

      const mapLocations = collectLocationsFromItinerary(itinerary);
      if (mapLocations.length > 0) {
        initialSections.push({
          id: 'location-overview',
          type: 'locationOverview',
          title: 'Location Overview',
          order: FIXED_SECTION_ORDER.locationOverview,
          visible: true,
          content: (
            <div className="space-y-2">
              <p>Interactive map showing {mapLocations.length} location{mapLocations.length !== 1 ? 's' : ''} from your itinerary:</p>
              <ul className="list-disc list-inside space-y-1">
                {itinerary.accommodations && itinerary.accommodations.length > 0 && (
                  <li>{itinerary.accommodations.length} Accommodation{itinerary.accommodations.length !== 1 ? 's' : ''}</li>
                )}
                {itinerary.activities && itinerary.activities.length > 0 && (
                  <li>{itinerary.activities.length} Activit{itinerary.activities.length !== 1 ? 'ies' : 'y'}</li>
                )}
                {itinerary.dining && itinerary.dining.length > 0 && (
                  <li>{itinerary.dining.length} Dining Location{itinerary.dining.length !== 1 ? 's' : ''}</li>
                )}
              </ul>
            </div>
          ),
        });
      }

      initialSections.sort((a, b) => a.order - b.order);
      setSections(initialSections);
    }
  }, [itinerary]);

  const toggleVisibility = (index: number) => {
    const newSections = [...sections];
    newSections[index].visible = !newSections[index].visible;
    setSections(newSections);
  };

  const handlePublish = async () => {
    try {
      // Build section order from regular sections
      const sectionOrder = sections.map((section, index) => ({
        id: section.id,
        type: section.type,
        order: index,
        visible: section.visible,
      }));

      // Add additional travel items with their visibility
      additionalTravelItems.forEach((travel, index) => {
        sectionOrder.push({
          id: `additionalTravel-${travel.id}`,
          type: 'additionalTravel',
          order: index,
          visible: additionalTravelVisibility[travel.id] ?? true,
        });
      });

      const arrangeResponse = await fetch(`/api/itineraries/${id}/arrange`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sections: sectionOrder }),
      });

      if (!arrangeResponse.ok) {
        throw new Error("Failed to save section arrangement");
      }

      const publishResponse = await fetch(`/api/itineraries/${id}/publish`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
      });

      if (!publishResponse.ok) {
        throw new Error("Failed to publish itinerary");
      }

      const updatedItinerary = await publishResponse.json();
      
      setLocation(`/itinerary/${updatedItinerary.customUrlSlug}`);
    } catch (error) {
      console.error("Error publishing itinerary:", error);
      alert("Failed to publish itinerary. Please try again.");
    }
  };

  const handleBackToEdit = () => {
    setLocation(`/edit/${id}`);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Loading itinerary...</p>
      </div>
    );
  }

  if (!itinerary) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p>Itinerary not found</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card">
        <div className="max-w-4xl mx-auto px-4 md:px-6 py-4">
          <Link href="/">
            <img 
              src={logoUrl} 
              alt="BlckBx" 
              className="h-12 w-auto cursor-pointer hover-elevate active-elevate-2 rounded p-1"
              data-testid="img-logo"
            />
          </Link>
        </div>
      </header>
      <div className="container mx-auto px-4 py-8 max-w-4xl">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">{itinerary.itinerary.title}</h1>
          <p className="text-muted-foreground">Preview your itinerary sections before publishing</p>
        </div>

        <div className="space-y-4 mb-8">
          {/* Sections before Return Travel (order < 70) */}
          {sections.filter(s => s.type !== 'additionalTravel' && s.order < 70).map((section, index) => (
            <Card
              key={section.id}
              className={!section.visible ? 'bg-muted/50' : ''}
              data-testid={`section-${section.type}-${index}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <CardTitle className="flex-1">{section.title}</CardTitle>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">
                      {section.visible ? 'Visible' : 'Hidden'}
                    </span>
                    <Switch
                      checked={section.visible}
                      onCheckedChange={() => toggleVisibility(sections.indexOf(section))}
                      data-testid={`toggle-visibility-${index}`}
                    />
                  </div>
                </div>
              </CardHeader>
              {section.visible && (
                <>
                  <Separator />
                  <CardContent className="pt-4">
                    {section.content}
                  </CardContent>
                </>
              )}
            </Card>
          ))}

          {/* Additional Travel - Separate section with drag-and-drop (comes BEFORE Return Travel) */}
          {additionalTravelItems.length > 0 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-muted-foreground">Additional Travel</h3>
              <DndContext
                sensors={sensors}
                collisionDetection={closestCenter}
                onDragEnd={handleAdditionalTravelDragEnd}
              >
                <SortableContext
                  items={additionalTravelItems.map((item) => item.id)}
                  strategy={verticalListSortingStrategy}
                >
                  <div className="space-y-4">
                    {additionalTravelItems.map((travel) => (
                      <SortableAdditionalTravelCard
                        key={travel.id}
                        travel={travel}
                        visible={additionalTravelVisibility[travel.id] ?? true}
                        onToggleVisibility={() => toggleAdditionalTravelVisibility(travel.id)}
                      />
                    ))}
                  </div>
                </SortableContext>
              </DndContext>
            </div>
          )}

          {/* Sections after Additional Travel (Return Travel, Helpful Info, etc.) */}
          {sections.filter(s => s.type !== 'additionalTravel' && s.order >= 70).map((section, index) => (
            <Card
              key={section.id}
              className={!section.visible ? 'bg-muted/50' : ''}
              data-testid={`section-${section.type}-${index}`}
            >
              <CardHeader className="pb-3">
                <div className="flex items-center gap-3">
                  <CardTitle className="flex-1">{section.title}</CardTitle>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">
                      {section.visible ? 'Visible' : 'Hidden'}
                    </span>
                    <Switch
                      checked={section.visible}
                      onCheckedChange={() => toggleVisibility(sections.indexOf(section))}
                      data-testid={`toggle-visibility-${index}`}
                    />
                  </div>
                </div>
              </CardHeader>
              {section.visible && (
                <>
                  <Separator />
                  <CardContent className="pt-4">
                    {section.content}
                  </CardContent>
                </>
              )}
            </Card>
          ))}
        </div>

        <div className="flex gap-4 justify-between sticky bottom-4 bg-background p-4 border rounded-lg shadow-lg">
          <Button
            variant="outline"
            onClick={handleBackToEdit}
            data-testid="button-back-to-edit"
          >
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Edit
          </Button>
          <Button
            onClick={handlePublish}
            data-testid="button-publish"
          >
            <Send className="mr-2 h-4 w-4" />
            Publish Itinerary
          </Button>
        </div>
      </div>
    </div>
  );
}
