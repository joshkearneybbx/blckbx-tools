import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Link } from "wouter";
import type { Itinerary } from "@shared/schema";

export default function Home() {
  const { user } = useAuth();
  const { data: itineraries, isLoading } = useQuery<Itinerary[]>({
    queryKey: ["/api/itineraries"],
  });

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center space-y-4">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto" />
          <p className="text-muted-foreground">Loading your itineraries...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen p-6">
      <div className="max-w-6xl mx-auto">
        <div className="flex justify-between items-center mb-8">
          <div>
            <h1 className="font-serif text-4xl font-bold">Your Itineraries</h1>
            <p className="text-muted-foreground mt-2">
              Welcome back, {user?.firstName || user?.email}
            </p>
          </div>
          <Button 
            variant="outline" 
            onClick={() => window.location.href = "/api/logout"}
            data-testid="button-logout"
          >
            Log Out
          </Button>
        </div>

        {!itineraries || itineraries.length === 0 ? (
          <Card>
            <CardContent className="p-12 text-center">
              <h3 className="font-serif text-2xl mb-2">No Itineraries Yet</h3>
              <p className="text-muted-foreground">
                Your travel consultant will share itineraries with you soon.
              </p>
            </CardContent>
          </Card>
        ) : (
          <div className="grid gap-6">
            {itineraries.map((itinerary) => (
              <Link key={itinerary.id} href={`/itinerary/${itinerary.id}`}>
                <Card className="hover-elevate cursor-pointer" data-testid={`card-itinerary-${itinerary.id}`}>
                  <CardHeader>
                    <CardTitle className="font-serif text-2xl">
                      {itinerary.title}
                    </CardTitle>
                    <CardDescription>
                      {itinerary.destination} • {itinerary.dates}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">
                      {itinerary.groupComposition}
                    </p>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
