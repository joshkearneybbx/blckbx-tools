import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Plus, Eye, Pencil, Trash2, Loader2, Search, Copy, BookTemplate } from "lucide-react";
import { Input } from "@/components/ui/input";
import { useToast } from "@/hooks/use-toast";
import { queryClient, apiRequest } from "@/lib/queryClient";
import type { Itinerary } from "@shared/schema";
import { Header } from "@/components/layout/Header";

type TabValue = "published" | "drafts" | "templates";

export default function Dashboard() {
  const [deleteId, setDeleteId] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeTab, setActiveTab] = useState<TabValue>("published");
  const [templateDialogOpen, setTemplateDialogOpen] = useState(false);
  const [selectedForTemplate, setSelectedForTemplate] = useState<Itinerary | null>(null);
  const [templateName, setTemplateName] = useState("");
  const [templateDescription, setTemplateDescription] = useState("");
  const { toast } = useToast();

  const { data: itineraries, isLoading } = useQuery<Itinerary[]>({
    queryKey: ["/api/itineraries"],
  });

  // Filter itineraries based on active tab
  const getTabItineraries = (tab: TabValue) => {
    if (!itineraries) return [];
    
    switch (tab) {
      case "published":
        return itineraries.filter(i => i.status === "published" && i.isTemplate === 0);
      case "drafts":
        return itineraries.filter(i => i.status === "draft");
      case "templates":
        return itineraries.filter(i => i.isTemplate === 1);
      default:
        return itineraries;
    }
  };

  // Filter itineraries based on search query and active tab
  const filteredItineraries = getTabItineraries(activeTab).filter(itinerary => {
    if (!searchQuery) return true;
    const query = searchQuery.toLowerCase();
    return (
      itinerary.title.toLowerCase().includes(query) ||
      itinerary.assistantName.toLowerCase().includes(query) ||
      itinerary.customUrlSlug.toLowerCase().includes(query) ||
      (itinerary.templateName && itinerary.templateName.toLowerCase().includes(query))
    );
  });

  // Count for each tab
  const publishedCount = itineraries?.filter(i => i.status === "published" && i.isTemplate === 0).length || 0;
  const draftsCount = itineraries?.filter(i => i.status === "draft").length || 0;
  const templatesCount = itineraries?.filter(i => i.isTemplate === 1).length || 0;

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("DELETE", `/api/itineraries/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/itineraries"] });
      toast({
        title: "Itinerary deleted",
        description: "The itinerary has been successfully removed.",
      });
      setDeleteId(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete itinerary. Please try again.",
        variant: "destructive",
      });
    },
  });

  const duplicateMutation = useMutation({
    mutationFn: async (id: string) => {
      return await apiRequest("POST", `/api/itineraries/${id}/duplicate`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/itineraries"] });
      toast({
        title: "Itinerary duplicated",
        description: "A copy of the itinerary has been created as a draft.",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to duplicate itinerary. Please try again.",
        variant: "destructive",
      });
    },
  });

  const saveAsTemplateMutation = useMutation({
    mutationFn: async ({ id, name, description }: { id: string; name: string; description: string }) => {
      return await apiRequest("POST", `/api/itineraries/${id}/save-as-template`, {
        templateName: name,
        templateDescription: description,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/itineraries"] });
      toast({
        title: "Template saved",
        description: "The itinerary has been saved as a template.",
      });
      setTemplateDialogOpen(false);
      setTemplateName("");
      setTemplateDescription("");
      setSelectedForTemplate(null);
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to save as template. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleSaveAsTemplate = (itinerary: Itinerary) => {
    setSelectedForTemplate(itinerary);
    setTemplateName(itinerary.title);
    setTemplateDescription("");
    setTemplateDialogOpen(true);
  };

  const handleTemplateSubmit = () => {
    if (!selectedForTemplate || !templateName.trim()) {
      toast({
        title: "Error",
        description: "Template name is required.",
        variant: "destructive",
      });
      return;
    }
    saveAsTemplateMutation.mutate({
      id: selectedForTemplate.id,
      name: templateName.trim(),
      description: templateDescription.trim(),
    });
  };

  const formatDate = (dateString: string) => {
    try {
      const date = new Date(dateString);
      return date.toLocaleDateString('en-US', { 
        year: 'numeric', 
        month: 'short', 
        day: 'numeric' 
      });
    } catch {
      return dateString;
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin mx-auto text-primary" data-testid="loader-dashboard" />
          <p className="text-lg text-muted-foreground">Loading your itineraries...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="max-w-7xl mx-auto px-4 md:px-6 py-12">
        <div className="mb-8 flex items-center gap-3">
          <Link href="/create">
            <Button size="lg" className="gap-2" data-testid="button-create-itinerary">
              <Plus className="w-5 h-5" />
              Create New Itinerary
            </Button>
          </Link>
        </div>

        <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as TabValue)} className="space-y-6">
          <div className="flex items-center justify-between gap-4">
            <TabsList>
              <TabsTrigger value="published" data-testid="tab-published">
                Published
                {publishedCount > 0 && (
                  <Badge variant="secondary" className="ml-2">{publishedCount}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="drafts" data-testid="tab-drafts">
                Drafts
                {draftsCount > 0 && (
                  <Badge variant="secondary" className="ml-2">{draftsCount}</Badge>
                )}
              </TabsTrigger>
              <TabsTrigger value="templates" data-testid="tab-templates">
                Templates
                {templatesCount > 0 && (
                  <Badge variant="secondary" className="ml-2">{templatesCount}</Badge>
                )}
              </TabsTrigger>
            </TabsList>

            {itineraries && itineraries.length > 0 && (
              <div className="relative w-full max-w-sm">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  placeholder="Search itineraries..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10"
                  data-testid="input-search"
                />
              </div>
            )}
          </div>

          <TabsContent value={activeTab} className="space-y-4">
            {!filteredItineraries || filteredItineraries.length === 0 ? (
              <Card>
                <CardContent className="py-12 text-center">
                  <p className="text-muted-foreground mb-4">
                    {searchQuery ? "No itineraries match your search" : `No ${activeTab} found`}
                  </p>
                  <Link href="/create">
                    <Button variant="outline" data-testid="button-create-first">
                      Create your first itinerary
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ) : (
              <div className="grid gap-4">
                {filteredItineraries.map((itinerary) => (
                  <Card key={itinerary.id} data-testid={`card-itinerary-${itinerary.id}`}>
                    <CardHeader>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-2">
                            <CardTitle className="text-xl" data-testid={`text-title-${itinerary.id}`}>
                              {itinerary.templateName || itinerary.title}
                            </CardTitle>
                            {itinerary.status === "draft" && (
                              <Badge variant="outline">Draft</Badge>
                            )}
                            {itinerary.isTemplate === 1 && (
                              <Badge variant="default">Template</Badge>
                            )}
                          </div>
                          <CardDescription className="space-y-1">
                            {itinerary.templateDescription && (
                              <p className="text-sm mb-2">{itinerary.templateDescription}</p>
                            )}
                            <div className="flex items-center gap-2 text-sm">
                              <span className="font-medium">Assistant:</span>
                              <span data-testid={`text-assistant-${itinerary.id}`}>{itinerary.assistantName}</span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <span className="font-medium">URL:</span>
                              <span className="text-xs font-mono" data-testid={`text-slug-${itinerary.id}`}>
                                /itinerary/{itinerary.customUrlSlug}
                              </span>
                            </div>
                            <div className="flex items-center gap-2 text-sm">
                              <span className="font-medium">Created:</span>
                              <span data-testid={`text-created-${itinerary.id}`}>
                                {formatDate(itinerary.createdAt.toString())}
                              </span>
                            </div>
                          </CardDescription>
                        </div>
                        
                        <div className="flex items-center gap-2">
                          <Link href={`/itinerary/${itinerary.customUrlSlug}`}>
                            <Button variant="outline" size="sm" className="gap-2" data-testid={`button-view-${itinerary.id}`}>
                              <Eye className="w-4 h-4" />
                              <span className="hidden sm:inline">View</span>
                            </Button>
                          </Link>
                          
                          <Link href={`/edit/${itinerary.id}`}>
                            <Button variant="outline" size="sm" className="gap-2" data-testid={`button-edit-${itinerary.id}`}>
                              <Pencil className="w-4 h-4" />
                              <span className="hidden sm:inline">Edit</span>
                            </Button>
                          </Link>

                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2"
                            onClick={() => duplicateMutation.mutate(itinerary.id)}
                            disabled={duplicateMutation.isPending}
                            data-testid={`button-duplicate-${itinerary.id}`}
                          >
                            <Copy className="w-4 h-4" />
                            <span className="hidden sm:inline">Duplicate</span>
                          </Button>

                          {itinerary.status === "published" && itinerary.isTemplate === 0 && (
                            <Button
                              variant="outline"
                              size="sm"
                              className="gap-2"
                              onClick={() => handleSaveAsTemplate(itinerary)}
                              data-testid={`button-save-template-${itinerary.id}`}
                            >
                              <BookTemplate className="w-4 h-4" />
                              <span className="hidden sm:inline">Save as Template</span>
                            </Button>
                          )}
                          
                          <Button
                            variant="outline"
                            size="sm"
                            className="gap-2 text-destructive hover:text-destructive"
                            onClick={() => setDeleteId(itinerary.id)}
                            data-testid={`button-delete-${itinerary.id}`}
                          >
                            <Trash2 className="w-4 h-4" />
                            <span className="hidden sm:inline">Delete</span>
                          </Button>
                        </div>
                      </div>
                    </CardHeader>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </main>

      <AlertDialog open={deleteId !== null} onOpenChange={() => setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
            <AlertDialogDescription>
              This will permanently delete this itinerary and all associated data. 
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={() => deleteId && deleteMutation.mutate(deleteId)}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              data-testid="button-confirm-delete"
            >
              {deleteMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  Deleting...
                </>
              ) : (
                "Delete"
              )}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Dialog open={templateDialogOpen} onOpenChange={setTemplateDialogOpen}>
        <DialogContent data-testid="dialog-save-template">
          <DialogHeader>
            <DialogTitle>Save as Template</DialogTitle>
            <DialogDescription>
              Create a reusable template from this itinerary. Templates can be duplicated to quickly create new itineraries.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="template-name">Template Name</Label>
              <Input
                id="template-name"
                value={templateName}
                onChange={(e) => setTemplateName(e.target.value)}
                placeholder="e.g., Algarve Villa Package"
                data-testid="input-template-name"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="template-description">Description (Optional)</Label>
              <Textarea
                id="template-description"
                value={templateDescription}
                onChange={(e) => setTemplateDescription(e.target.value)}
                placeholder="Describe what this template is for..."
                rows={3}
                data-testid="textarea-template-description"
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setTemplateDialogOpen(false)}
              data-testid="button-cancel-template"
            >
              Cancel
            </Button>
            <Button
              onClick={handleTemplateSubmit}
              disabled={saveAsTemplateMutation.isPending || !templateName.trim()}
              data-testid="button-confirm-template"
            >
              {saveAsTemplateMutation.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin mr-2" />
                  Saving...
                </>
              ) : (
                "Save Template"
              )}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
