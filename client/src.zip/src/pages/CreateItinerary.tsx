import { useState, useEffect, useMemo } from "react";
import { useLocation, useRoute } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { ArrowLeft, ArrowRight, Save, Loader2, FileText } from "lucide-react";
import { Link } from "wouter";
import logoUrl from "@assets/blckbx-logo.png";
import { useToast } from "@/hooks/use-toast";
import { queryClient } from "@/lib/queryClient";
import type { FullItinerary } from "@shared/schema";
import { PDFDownloadLink } from "@react-pdf/renderer";
import { ItineraryPDFTemplate } from "@/components/pdf/ItineraryPDFTemplate";
import { useImagePreprocessor } from "@/hooks/useImagePreprocessor";

// Wizard pages
import Page1BasicInfo from "@/components/wizard/Page1BasicInfo";
import Page2OutboundTravel from "@/components/wizard/Page2OutboundTravel";
import Page3Accommodation from "@/components/wizard/Page3Accommodation";
import Page4Activities from "@/components/wizard/Page4Activities";
import Page5Dining from "@/components/wizard/Page5Dining";
import Page6AdditionalTravel from "@/components/wizard/Page6AdditionalTravel";
import Page7ReturnTravel from "@/components/wizard/Page7ReturnTravel";
import Page8HelpfulInfo from "@/components/wizard/Page8HelpfulInfo";
import WizardNavigation, { type PageStatus } from "@/components/wizard/WizardNavigation";

// Flight leg type for multi-leg/connecting flights
export type FlightLeg = {
  departureAirport: string;
  departureTime: string;
  arrivalAirport: string;
  arrivalTime: string;
  flightNumber?: string;
  layoverDuration?: string;
};

export type TaxiTransfer = {
  id: string;
  company?: string;
  contact?: string;
  collectionTime?: string;
  pickupLocation?: string;
  paymentStatus?: string;
};

export type TrainTransfer = {
  id: string;
  departingStation?: string;
  arrivalStation?: string;
  departureTime?: string;
  provider?: string;
  bookingRef?: string;
  paymentStatus?: string;
  notes?: string;
};

export type WizardData = {
  // Itinerary
  itineraryId?: string;
  title: string;
  assistantName: string;
  assistantEmail: string;
  customUrlSlug?: string;
  
  // Travel Details
  dates: string;
  location: string;
  weather: string;
  weatherUrl: string;
  
  // Travellers
  travellers: Array<{ name: string; type: "adult" | "child"; ageAtTravel: number | null; displayOrder: number }>;
  
  // Outbound Travel
  outboundTravel: {
    // Transfer to Airport
    transferToAirportType: string; // "none" | "taxi" | "train"
    transferToAirportTaxiBooked: number; // legacy
    transferToAirportCompany: string;
    transferToAirportContact: string;
    transferToAirportCollectionTime: string;
    transferToAirportPickupLocation: string;
    transferToAirportPaymentStatus: string;
    transferToAirportTrainDepartingStation: string;
    transferToAirportTrainArrivalStation: string;
    transferToAirportTrainDepartureTime: string;
    transferToAirportTrainProvider: string;
    transferToAirportTrainBookingRef: string;
    transferToAirportTrainPaymentStatus: string;
    transferToAirportTrainNotes: string;
    // Multiple taxi/train support for Transfer to Airport
    transferToAirportTaxis: TaxiTransfer[];
    transferToAirportTrains: TrainTransfer[];
    // Flight
    flightNumber: string;
    flightDate: string;
    departureAirport: string;
    arrivalAirport: string;
    departureTime: string;
    arrivalTime: string;
    passengersSeats: string;
    thingsToRemember: string;
    isMultiLeg: number;
    legs: FlightLeg[];
    // Transfer to Accommodation
    transferToAccomType: string; // "none" | "taxi" | "train"
    transferToAccomTaxiBooked: number; // legacy
    transferToAccomCompany: string;
    transferToAccomContact: string;
    transferToAccomCollectionTime: string;
    transferToAccomPickupLocation: string;
    transferToAccomPaymentStatus: string;
    transferToAccomTrainDepartingStation: string;
    transferToAccomTrainArrivalStation: string;
    transferToAccomTrainDepartureTime: string;
    transferToAccomTrainProvider: string;
    transferToAccomTrainBookingRef: string;
    transferToAccomTrainPaymentStatus: string;
    transferToAccomTrainNotes: string;
    // Multiple taxi/train support for Transfer to Accommodation
    transferToAccomTaxis: TaxiTransfer[];
    transferToAccomTrains: TrainTransfer[];
  };
  
  // Accommodations
  accommodations: Array<{
    name: string;
    address: string;
    googleMapsLink: string;
    checkInDetails: string;
    bookingReference: string;
    websiteUrl: string;
    contactInfo: string;
    images: string[];
    notes?: string;
    displayOrder: number;
  }>;
  
  // Activities
  activities: Array<{
    name: string;
    description: string;
    price: string;
    contactDetails: string;
    address: string;
    googleMapsLink: string;
    websiteUrl: string;
    images: string[];
    notes?: string;
    displayOrder: number;
  }>;
  
  // Dining
  dining: Array<{
    name: string;
    cuisineType: string;
    priceRange: string;
    contactDetails: string;
    address: string;
    googleMapsLink: string;
    websiteUrl: string;
    images: string[];
    notes?: string;
    displayOrder: number;
  }>;
  
  // Bars and Pubs
  bars: Array<{
    name: string;
    barType: string;
    priceRange: string;
    contactDetails: string;
    address: string;
    googleMapsLink: string;
    websiteUrl: string;
    images: string[];
    notes?: string;
    displayOrder: number;
  }>;
  
  // Additional Travel
  additionalTravel: Array<{
    travelType: string;
    vehicleDetails: string;
    vehicleRegistration: string;
    carContactDetails: string;
    carBookingDetails: string;
    flightNumber: string;
    flightDate: string;
    flightDepartureAirport: string;
    flightArrivalAirport: string;
    flightDepartureTime: string;
    flightArrivalTime: string;
    flightPassengersSeats: string;
    flightThingsToRemember: string;
    flightIsMultiLeg: number;
    flightLegs: FlightLeg[];
    ferryDepartingFrom: string;
    ferryDestination: string;
    ferryDate: string;
    ferryPrice: string;
    ferryContactDetails: string;
    ferryAdditionalNotes: string;
    ferryBookingReference: string;
    trainDepartingFrom: string;
    trainDestination: string;
    trainDate: string;
    trainPrice: string;
    trainContactDetails: string;
    trainAdditionalNotes: string;
    trainBookingReference: string;
    displayOrder: number;
  }>;
  
  // Return Travel
  returnTravel: {
    // Transfer to Airport
    transferToAirportType: string; // "none" | "taxi" | "train"
    transferToAirportTaxiBooked: number; // legacy
    transferToAirportCompany: string;
    transferToAirportContact: string;
    transferToAirportCollectionTime: string;
    transferToAirportPickupLocation: string;
    transferToAirportPaymentStatus: string;
    transferToAirportTrainDepartingStation: string;
    transferToAirportTrainArrivalStation: string;
    transferToAirportTrainDepartureTime: string;
    transferToAirportTrainProvider: string;
    transferToAirportTrainBookingRef: string;
    transferToAirportTrainPaymentStatus: string;
    transferToAirportTrainNotes: string;
    // Multiple taxi/train support for Transfer to Airport
    transferToAirportTaxis: TaxiTransfer[];
    transferToAirportTrains: TrainTransfer[];
    // Flight
    flightNumber: string;
    flightDate: string;
    departureAirport: string;
    arrivalAirport: string;
    departureTime: string;
    arrivalTime: string;
    passengersSeats: string;
    thingsToRemember: string;
    isMultiLeg: number;
    legs: FlightLeg[];
    // Transfer Home
    transferHomeType: string; // "none" | "taxi" | "train"
    transferHomeTaxiBooked: number; // legacy
    transferHomeCompany: string;
    transferHomeContact: string;
    transferHomeCollectionTime: string;
    transferHomePickupLocation: string;
    transferHomePaymentStatus: string;
    transferHomeTrainDepartingStation: string;
    transferHomeTrainArrivalStation: string;
    transferHomeTrainDepartureTime: string;
    transferHomeTrainProvider: string;
    transferHomeTrainBookingRef: string;
    transferHomeTrainPaymentStatus: string;
    transferHomeTrainNotes: string;
    // Multiple taxi/train support for Transfer Home
    transferHomeTaxis: TaxiTransfer[];
    transferHomeTrains: TrainTransfer[];
  };
  
  // Helpful Information
  helpfulInformation: {
    localEmergency: string;
    nearestEmbassy: string;
    travelInsurance: string;
    airlineCustomerService: string;
    localMedicalClinic: string;
    transportContacts: string;
  };
  
  // Custom Sections
  customSections: Array<{
    customSectionId: string;
    sectionTitle: string;
    fieldValues: Record<string, string>;
  }>;
  
  // Skip flags for optional sections
  activitiesSkipped?: boolean;
  diningSkipped?: boolean;
  additionalTravelSkipped?: boolean;
  helpfulInfoSkipped?: boolean;
};

const initialData: WizardData = {
  title: "",
  assistantName: "Charlie McElroy",
  assistantEmail: "charlie.mcelroy@blckbx.co.uk",
  dates: "",
  location: "",
  weather: "",
  weatherUrl: "",
  travellers: [],
  outboundTravel: {
    transferToAirportType: "none",
    transferToAirportTaxiBooked: 0,
    transferToAirportCompany: "",
    transferToAirportContact: "",
    transferToAirportCollectionTime: "",
    transferToAirportPickupLocation: "",
    transferToAirportPaymentStatus: "",
    transferToAirportTrainDepartingStation: "",
    transferToAirportTrainArrivalStation: "",
    transferToAirportTrainDepartureTime: "",
    transferToAirportTrainProvider: "",
    transferToAirportTrainBookingRef: "",
    transferToAirportTrainPaymentStatus: "",
    transferToAirportTrainNotes: "",
    transferToAirportTaxis: [],
    transferToAirportTrains: [],
    flightNumber: "",
    flightDate: "",
    departureAirport: "",
    arrivalAirport: "",
    departureTime: "",
    arrivalTime: "",
    passengersSeats: "",
    thingsToRemember: "",
    isMultiLeg: 0,
    legs: [],
    transferToAccomType: "none",
    transferToAccomTaxiBooked: 0,
    transferToAccomCompany: "",
    transferToAccomContact: "",
    transferToAccomCollectionTime: "",
    transferToAccomPickupLocation: "",
    transferToAccomPaymentStatus: "",
    transferToAccomTrainDepartingStation: "",
    transferToAccomTrainArrivalStation: "",
    transferToAccomTrainDepartureTime: "",
    transferToAccomTrainProvider: "",
    transferToAccomTrainBookingRef: "",
    transferToAccomTrainPaymentStatus: "",
    transferToAccomTrainNotes: "",
    transferToAccomTaxis: [],
    transferToAccomTrains: [],
  },
  accommodations: [],
  activities: [],
  dining: [],
  bars: [],
  additionalTravel: [],
  returnTravel: {
    transferToAirportType: "none",
    transferToAirportTaxiBooked: 0,
    transferToAirportCompany: "",
    transferToAirportContact: "",
    transferToAirportCollectionTime: "",
    transferToAirportPickupLocation: "",
    transferToAirportPaymentStatus: "",
    transferToAirportTrainDepartingStation: "",
    transferToAirportTrainArrivalStation: "",
    transferToAirportTrainDepartureTime: "",
    transferToAirportTrainProvider: "",
    transferToAirportTrainBookingRef: "",
    transferToAirportTrainPaymentStatus: "",
    transferToAirportTrainNotes: "",
    transferToAirportTaxis: [],
    transferToAirportTrains: [],
    flightNumber: "",
    flightDate: "",
    departureAirport: "",
    arrivalAirport: "",
    departureTime: "",
    arrivalTime: "",
    passengersSeats: "",
    thingsToRemember: "",
    isMultiLeg: 0,
    legs: [],
    transferHomeType: "none",
    transferHomeTaxiBooked: 0,
    transferHomeCompany: "",
    transferHomeContact: "",
    transferHomeCollectionTime: "",
    transferHomePickupLocation: "",
    transferHomePaymentStatus: "",
    transferHomeTrainDepartingStation: "",
    transferHomeTrainArrivalStation: "",
    transferHomeTrainDepartureTime: "",
    transferHomeTrainProvider: "",
    transferHomeTrainBookingRef: "",
    transferHomeTrainPaymentStatus: "",
    transferHomeTrainNotes: "",
    transferHomeTaxis: [],
    transferHomeTrains: [],
  },
  helpfulInformation: {
    localEmergency: "",
    nearestEmbassy: "",
    travelInsurance: "",
    airlineCustomerService: "",
    localMedicalClinic: "",
    transportContacts: "",
  },
  customSections: [],
};

const PAGE_TITLES = [
  "Travel & Traveller Details",
  "Outbound Travel",
  "Accommodation",
  "Activities",
  "Dining",
  "Additional Travel",
  "Return Travel",
  "Helpful Information",
];

const DRAFT_KEY = 'itinerary-draft';
const AUTO_SAVE_DELAY = 3000; // 3 seconds

function mapOutboundFromDb(data: any): WizardData['outboundTravel'] {
  if (!data) return initialData.outboundTravel;
  
  // Migrate legacy taxiBooked flag to new type field
  let transferToAirportType = data.transferToAirportType || "none";
  if (!data.transferToAirportType && data.transferToAirportTaxiBooked === 1) {
    transferToAirportType = "taxi";
  }
  let transferToAccomType = data.transferToAccomType || "none";
  if (!data.transferToAccomType && data.transferToAccomTaxiBooked === 1) {
    transferToAccomType = "taxi";
  }
  
  return {
    transferToAirportType,
    transferToAirportTaxiBooked: data.transferToAirportTaxiBooked ?? 0,
    transferToAirportCompany: data.transferToAirportCompany || "",
    transferToAirportContact: data.transferToAirportContact || "",
    transferToAirportCollectionTime: data.transferToAirportCollectionTime || "",
    transferToAirportPickupLocation: data.transferToAirportPickupLocation || "",
    transferToAirportPaymentStatus: data.transferToAirportPaymentStatus || "",
    transferToAirportTrainDepartingStation: data.transferToAirportTrainDepartingStation || "",
    transferToAirportTrainArrivalStation: data.transferToAirportTrainArrivalStation || "",
    transferToAirportTrainDepartureTime: data.transferToAirportTrainDepartureTime || "",
    transferToAirportTrainProvider: data.transferToAirportTrainProvider || "",
    transferToAirportTrainBookingRef: data.transferToAirportTrainBookingRef || "",
    transferToAirportTrainPaymentStatus: data.transferToAirportTrainPaymentStatus || "",
    transferToAirportTrainNotes: data.transferToAirportTrainNotes || "",
    transferToAirportTaxis: Array.isArray(data.transferToAirportTaxis) ? data.transferToAirportTaxis : [],
    transferToAirportTrains: Array.isArray(data.transferToAirportTrains) ? data.transferToAirportTrains : [],
    flightNumber: data.flightNumber || "",
    flightDate: data.flightDate || "",
    departureAirport: data.departureAirport || "",
    arrivalAirport: data.arrivalAirport || "",
    departureTime: data.departureTime || "",
    arrivalTime: data.arrivalTime || "",
    passengersSeats: data.passengersSeats || "",
    thingsToRemember: data.thingsToRemember || "",
    isMultiLeg: data.isMultiLeg ?? 0,
    legs: Array.isArray(data.legs) ? data.legs : [],
    transferToAccomType,
    transferToAccomTaxiBooked: data.transferToAccomTaxiBooked ?? 0,
    transferToAccomCompany: data.transferToAccomCompany || "",
    transferToAccomContact: data.transferToAccomContact || "",
    transferToAccomCollectionTime: data.transferToAccomCollectionTime || "",
    transferToAccomPickupLocation: data.transferToAccomPickupLocation || "",
    transferToAccomPaymentStatus: data.transferToAccomPaymentStatus || "",
    transferToAccomTrainDepartingStation: data.transferToAccomTrainDepartingStation || "",
    transferToAccomTrainArrivalStation: data.transferToAccomTrainArrivalStation || "",
    transferToAccomTrainDepartureTime: data.transferToAccomTrainDepartureTime || "",
    transferToAccomTrainProvider: data.transferToAccomTrainProvider || "",
    transferToAccomTrainBookingRef: data.transferToAccomTrainBookingRef || "",
    transferToAccomTrainPaymentStatus: data.transferToAccomTrainPaymentStatus || "",
    transferToAccomTrainNotes: data.transferToAccomTrainNotes || "",
    transferToAccomTaxis: Array.isArray(data.transferToAccomTaxis) ? data.transferToAccomTaxis : [],
    transferToAccomTrains: Array.isArray(data.transferToAccomTrains) ? data.transferToAccomTrains : [],
  };
}

function mapReturnFromDb(data: any): WizardData['returnTravel'] {
  if (!data) return initialData.returnTravel;
  
  // Migrate legacy taxiBooked flag to new type field
  let transferToAirportType = data.transferToAirportType || "none";
  if (!data.transferToAirportType && data.transferToAirportTaxiBooked === 1) {
    transferToAirportType = "taxi";
  }
  let transferHomeType = data.transferHomeType || "none";
  if (!data.transferHomeType && data.transferHomeTaxiBooked === 1) {
    transferHomeType = "taxi";
  }
  
  return {
    transferToAirportType,
    transferToAirportTaxiBooked: data.transferToAirportTaxiBooked ?? 0,
    transferToAirportCompany: data.transferToAirportCompany || "",
    transferToAirportContact: data.transferToAirportContact || "",
    transferToAirportCollectionTime: data.transferToAirportCollectionTime || "",
    transferToAirportPickupLocation: data.transferToAirportPickupLocation || "",
    transferToAirportPaymentStatus: data.transferToAirportPaymentStatus || "",
    transferToAirportTrainDepartingStation: data.transferToAirportTrainDepartingStation || "",
    transferToAirportTrainArrivalStation: data.transferToAirportTrainArrivalStation || "",
    transferToAirportTrainDepartureTime: data.transferToAirportTrainDepartureTime || "",
    transferToAirportTrainProvider: data.transferToAirportTrainProvider || "",
    transferToAirportTrainBookingRef: data.transferToAirportTrainBookingRef || "",
    transferToAirportTrainPaymentStatus: data.transferToAirportTrainPaymentStatus || "",
    transferToAirportTrainNotes: data.transferToAirportTrainNotes || "",
    transferToAirportTaxis: Array.isArray(data.transferToAirportTaxis) ? data.transferToAirportTaxis : [],
    transferToAirportTrains: Array.isArray(data.transferToAirportTrains) ? data.transferToAirportTrains : [],
    flightNumber: data.flightNumber || "",
    flightDate: data.flightDate || "",
    departureAirport: data.departureAirport || "",
    arrivalAirport: data.arrivalAirport || "",
    departureTime: data.departureTime || "",
    arrivalTime: data.arrivalTime || "",
    passengersSeats: data.passengersSeats || "",
    thingsToRemember: data.thingsToRemember || "",
    isMultiLeg: data.isMultiLeg ?? 0,
    legs: Array.isArray(data.legs) ? data.legs : [],
    transferHomeType,
    transferHomeTaxiBooked: data.transferHomeTaxiBooked ?? 0,
    transferHomeCompany: data.transferHomeCompany || "",
    transferHomeContact: data.transferHomeContact || "",
    transferHomeCollectionTime: data.transferHomeCollectionTime || "",
    transferHomePickupLocation: data.transferHomePickupLocation || "",
    transferHomePaymentStatus: data.transferHomePaymentStatus || "",
    transferHomeTrainDepartingStation: data.transferHomeTrainDepartingStation || "",
    transferHomeTrainArrivalStation: data.transferHomeTrainArrivalStation || "",
    transferHomeTrainDepartureTime: data.transferHomeTrainDepartureTime || "",
    transferHomeTrainProvider: data.transferHomeTrainProvider || "",
    transferHomeTrainBookingRef: data.transferHomeTrainBookingRef || "",
    transferHomeTrainPaymentStatus: data.transferHomeTrainPaymentStatus || "",
    transferHomeTrainNotes: data.transferHomeTrainNotes || "",
    transferHomeTaxis: Array.isArray(data.transferHomeTaxis) ? data.transferHomeTaxis : [],
    transferHomeTrains: Array.isArray(data.transferHomeTrains) ? data.transferHomeTrains : [],
  };
}

function mapAccommodationFromDb(acc: any): WizardData['accommodations'][0] {
  return {
    name: acc.name,
    address: acc.address || "",
    googleMapsLink: acc.googleMapsLink || "",
    checkInDetails: acc.checkInDetails || "",
    bookingReference: acc.bookingReference || "",
    websiteUrl: acc.websiteUrl || "",
    contactInfo: acc.contactInfo || "",
    images: acc.images || [],
    displayOrder: acc.displayOrder,
  };
}

function mapActivityFromDb(act: any): WizardData['activities'][0] {
  return {
    name: act.name,
    description: act.description || "",
    price: act.price || "",
    contactDetails: act.contactDetails || "",
    address: act.address || "",
    googleMapsLink: act.googleMapsLink || "",
    websiteUrl: act.websiteUrl || "",
    images: act.images || [],
    displayOrder: act.displayOrder,
  };
}

function mapDiningFromDb(rest: any): WizardData['dining'][0] {
  return {
    name: rest.name,
    cuisineType: rest.cuisineType || "",
    priceRange: rest.priceRange || "",
    contactDetails: rest.contactDetails || "",
    address: rest.address || "",
    googleMapsLink: rest.googleMapsLink || "",
    websiteUrl: rest.websiteUrl || "",
    images: rest.images || [],
    displayOrder: rest.displayOrder,
  };
}

function mapBarFromDb(bar: any): WizardData['bars'][0] {
  return {
    name: bar.name,
    barType: bar.barType || "",
    priceRange: bar.priceRange || "",
    contactDetails: bar.contactDetails || "",
    address: bar.address || "",
    googleMapsLink: bar.googleMapsLink || "",
    websiteUrl: bar.websiteUrl || "",
    images: bar.images || [],
    displayOrder: bar.displayOrder,
  };
}

function mapAdditionalTravelFromDb(travel: any): WizardData['additionalTravel'][0] {
  return {
    travelType: travel.travelType,
    vehicleDetails: travel.vehicleDetails || "",
    vehicleRegistration: travel.vehicleRegistration || "",
    carContactDetails: travel.carContactDetails || "",
    carBookingDetails: travel.carBookingDetails || "",
    flightNumber: travel.flightNumber || "",
    flightDate: travel.flightDate || "",
    flightDepartureAirport: travel.flightDepartureAirport || "",
    flightArrivalAirport: travel.flightArrivalAirport || "",
    flightDepartureTime: travel.flightDepartureTime || "",
    flightArrivalTime: travel.flightArrivalTime || "",
    flightPassengersSeats: travel.flightPassengersSeats || "",
    flightThingsToRemember: travel.flightThingsToRemember || "",
    flightIsMultiLeg: travel.flightIsMultiLeg ?? 0,
    flightLegs: Array.isArray(travel.flightLegs) ? travel.flightLegs : [],
    ferryDepartingFrom: travel.ferryDepartingFrom || "",
    ferryDestination: travel.ferryDestination || "",
    ferryDate: travel.ferryDate || "",
    ferryPrice: travel.ferryPrice || "",
    ferryContactDetails: travel.ferryContactDetails || "",
    ferryAdditionalNotes: travel.ferryAdditionalNotes || "",
    ferryBookingReference: travel.ferryBookingReference || "",
    trainDepartingFrom: travel.trainDepartingFrom || "",
    trainDestination: travel.trainDestination || "",
    trainDate: travel.trainDate || "",
    trainPrice: travel.trainPrice || "",
    trainContactDetails: travel.trainContactDetails || "",
    trainAdditionalNotes: travel.trainAdditionalNotes || "",
    trainBookingReference: travel.trainBookingReference || "",
    displayOrder: travel.displayOrder,
  };
}

export default function CreateItinerary() {
  // Check if we're in edit mode
  const [matchCreate] = useRoute("/create");
  const [matchEdit, editParams] = useRoute("/edit/:id");
  const isEditMode = matchEdit && editParams?.id;
  const editId = editParams?.id || null;

  const [currentPage, setCurrentPage] = useState(0);
  const [wizardData, setWizardData] = useState<WizardData>(initialData);
  const [, setLocation] = useLocation();
  const [draftRestored, setDraftRestored] = useState(false);
  const [customSectionsValid, setCustomSectionsValid] = useState(true);
  const [isLoadingEdit, setIsLoadingEdit] = useState(!!isEditMode);
  const [isNavigating, setIsNavigating] = useState(false);
  const { toast } = useToast();

  const totalPages = 8;
  const progress = ((currentPage + 1) / totalPages) * 100;

  // Compute page completion status
  const pageCompletion = useMemo<Record<number, PageStatus>>(() => {
    const completion: Record<number, PageStatus> = {};
    
    // Page 0: Basic Info - Has assistantName AND at least 1 traveller
    completion[0] = (wizardData.assistantName?.trim() && wizardData.travellers.length > 0)
      ? "complete" : "pending";
    
    // Page 1: Outbound Travel - Has flight number OR transfer company
    completion[1] = (wizardData.outboundTravel?.flightNumber?.trim() || 
                     wizardData.outboundTravel?.transferToAirportCompany?.trim() ||
                     wizardData.outboundTravel?.transferToAccomCompany?.trim())
      ? "complete" : "pending";
    
    // Page 2: Accommodation - Has at least 1 accommodation
    completion[2] = wizardData.accommodations.length > 0 ? "complete" : "pending";
    
    // Page 3: Activities - Has items OR marked as skipped
    completion[3] = (wizardData.activities.length > 0 || wizardData.activitiesSkipped)
      ? "complete" : "pending";
    
    // Page 4: Dining - Has items OR marked as skipped
    completion[4] = (wizardData.dining.length > 0 || wizardData.diningSkipped)
      ? "complete" : "pending";
    
    // Page 5: Additional Travel - Has items OR marked as skipped
    completion[5] = (wizardData.additionalTravel.length > 0 || wizardData.additionalTravelSkipped)
      ? "complete" : "pending";
    
    // Page 6: Return Travel - Has flight number OR transfer company
    completion[6] = (wizardData.returnTravel?.flightNumber?.trim() ||
                     wizardData.returnTravel?.transferToAirportCompany?.trim() ||
                     wizardData.returnTravel?.transferHomeCompany?.trim())
      ? "complete" : "pending";
    
    // Page 7: Helpful Info - Has any field OR marked as skipped
    const hasHelpfulInfo = Object.values(wizardData.helpfulInformation || {}).some(v => v?.trim());
    completion[7] = (hasHelpfulInfo || wizardData.helpfulInfoSkipped)
      ? "complete" : "pending";
    
    // Mark current page as "current"
    completion[currentPage] = "current";
    
    return completion;
  }, [wizardData, currentPage]);

  // Convert wizard data to FullItinerary format for PDF preview
  const previewData = useMemo<FullItinerary>(() => {
    const now = new Date();
    return {
      itinerary: {
        id: wizardData.itineraryId || "preview",
        title: wizardData.title || "Untitled Itinerary",
        assistantName: wizardData.assistantName || "",
        assistantEmail: wizardData.assistantEmail || "",
        customUrlSlug: wizardData.customUrlSlug || "preview",
        status: "draft",
        userId: null,
        createdAt: now,
        updatedAt: now,
        isTemplate: 0,
        templateName: null,
        templateDescription: null,
        outboundTravelVisible: 1,
        accommodationsVisible: 1,
        activitiesVisible: 1,
        diningVisible: 1,
        barsVisible: 1,
        additionalTravelVisible: 1,
        returnTravelVisible: 1,
        helpfulInfoVisible: 1,
      },
      travelDetails: {
        id: "preview-td",
        itineraryId: wizardData.itineraryId || "preview",
        dates: wizardData.dates || "",
        location: wizardData.location || "",
        weather: wizardData.weather || "",
        weatherUrl: wizardData.weatherUrl || "",
      },
      travellers: wizardData.travellers.map((t, i) => ({
        id: `preview-t-${i}`,
        itineraryId: wizardData.itineraryId || "preview",
        name: t.name,
        type: t.type,
        ageAtTravel: t.ageAtTravel || null,
        displayOrder: i,
      })),
      outboundTravel: wizardData.outboundTravel ? {
        id: "preview-ot",
        itineraryId: wizardData.itineraryId || "preview",
        ...wizardData.outboundTravel,
      } : null,
      accommodations: wizardData.accommodations.map((a, i) => ({
        id: `preview-a-${i}`,
        itineraryId: wizardData.itineraryId || "preview",
        name: a.name,
        address: a.address || "",
        googleMapsLink: a.googleMapsLink || "",
        checkInDetails: a.checkInDetails || "",
        bookingReference: a.bookingReference || null,
        contactInfo: a.contactInfo || null,
        images: a.images || [],
        websiteUrl: a.websiteUrl || "",
        notes: a.notes || null,
        displayOrder: i,
        visible: 1,
      })),
      activities: wizardData.activities.map((a, i) => ({
        id: `preview-act-${i}`,
        itineraryId: wizardData.itineraryId || "preview",
        name: a.name,
        description: a.description || "",
        price: a.price || "",
        address: a.address || null,
        googleMapsLink: a.googleMapsLink || null,
        contactDetails: a.contactDetails || null,
        images: a.images || [],
        websiteUrl: a.websiteUrl || "",
        notes: a.notes || null,
        displayOrder: i,
        visible: 1,
      })),
      dining: wizardData.dining.map((d, i) => ({
        id: `preview-d-${i}`,
        itineraryId: wizardData.itineraryId || "preview",
        name: d.name,
        cuisineType: d.cuisineType || "",
        priceRange: d.priceRange || "",
        images: d.images || [],
        contactDetails: d.contactDetails || "",
        address: d.address || "",
        googleMapsLink: d.googleMapsLink || "",
        websiteUrl: d.websiteUrl || "",
        notes: d.notes || "",
        displayOrder: i,
        visible: 1,
      })),
      bars: wizardData.bars.map((b, i) => ({
        id: `preview-b-${i}`,
        itineraryId: wizardData.itineraryId || "preview",
        name: b.name,
        barType: b.barType || "",
        priceRange: b.priceRange || "",
        images: b.images || [],
        contactDetails: b.contactDetails || "",
        address: b.address || "",
        googleMapsLink: b.googleMapsLink || "",
        websiteUrl: b.websiteUrl || "",
        notes: b.notes || "",
        displayOrder: i,
        visible: 1,
      })),
      additionalTravel: wizardData.additionalTravel.map((t, i) => ({
        id: `preview-at-${i}`,
        itineraryId: wizardData.itineraryId || "preview",
        travelType: t.travelType,
        vehicleDetails: t.vehicleDetails || null,
        vehicleRegistration: t.vehicleRegistration || null,
        carContactDetails: t.carContactDetails || null,
        carBookingDetails: t.carBookingDetails || null,
        flightNumber: t.flightNumber || null,
        flightDate: t.flightDate || null,
        flightDepartureAirport: t.flightDepartureAirport || null,
        flightArrivalAirport: t.flightArrivalAirport || null,
        flightDepartureTime: t.flightDepartureTime || null,
        flightArrivalTime: t.flightArrivalTime || null,
        flightPassengersSeats: t.flightPassengersSeats || null,
        flightThingsToRemember: t.flightThingsToRemember || null,
        flightIsMultiLeg: t.flightIsMultiLeg || 0,
        flightLegs: t.flightLegs || [],
        ferryDepartingFrom: t.ferryDepartingFrom || null,
        ferryDestination: t.ferryDestination || null,
        ferryDate: t.ferryDate || null,
        ferryPrice: t.ferryPrice || null,
        ferryContactDetails: t.ferryContactDetails || null,
        ferryAdditionalNotes: t.ferryAdditionalNotes || null,
        ferryBookingReference: t.ferryBookingReference || null,
        trainDepartingFrom: t.trainDepartingFrom || null,
        trainDestination: t.trainDestination || null,
        trainDate: t.trainDate || null,
        trainPrice: t.trainPrice || null,
        trainContactDetails: t.trainContactDetails || null,
        trainAdditionalNotes: t.trainAdditionalNotes || null,
        trainBookingReference: t.trainBookingReference || null,
        displayOrder: i,
        visible: 1,
      })),
      returnTravel: wizardData.returnTravel ? {
        id: "preview-rt",
        itineraryId: wizardData.itineraryId || "preview",
        ...wizardData.returnTravel,
      } : null,
      helpfulInformation: wizardData.helpfulInformation ? {
        id: "preview-hi",
        itineraryId: wizardData.itineraryId || "preview",
        localEmergency: wizardData.helpfulInformation.localEmergency || "",
        nearestEmbassy: wizardData.helpfulInformation.nearestEmbassy || "",
        travelInsurance: wizardData.helpfulInformation.travelInsurance || "",
        airlineCustomerService: wizardData.helpfulInformation.airlineCustomerService || "",
        localMedicalClinic: wizardData.helpfulInformation.localMedicalClinic || "",
        transportContacts: wizardData.helpfulInformation.transportContacts || "",
      } : null,
      customSectionItems: [],
    };
  }, [wizardData]);

  // Pre-process images for PDF (convert external URLs to data URIs)
  const { processedItinerary: processedPreviewData, isLoading: isProcessingImages } = useImagePreprocessor(previewData);

  // Determine if sidebar should be shown (only after Page 1 is complete or in edit mode)
  const showSidebar = isEditMode || pageCompletion[0] === "complete";

  // Fetch existing itinerary when in edit mode
  useEffect(() => {
    if (isEditMode && editId) {
      const fetchItinerary = async () => {
        try {
          setIsLoadingEdit(true);
          console.log("Fetching itinerary for edit:", editId);
          const response = await fetch(`/api/itineraries/${editId}`);
          console.log("Response status:", response.status, response.statusText);
          
          if (!response.ok) {
            throw new Error(`Failed to fetch itinerary: ${response.status} ${response.statusText}`);
          }
          
          const data: FullItinerary = await response.json();
          console.log("Fetched itinerary data:", data);
          
          // Transform FullItinerary to WizardData format using helper functions
          const transformedData: WizardData = {
            itineraryId: data.itinerary.id,
            title: data.itinerary.title,
            assistantName: data.itinerary.assistantName,
            assistantEmail: data.itinerary.assistantEmail,
            customUrlSlug: data.itinerary.customUrlSlug,
            dates: data.travelDetails?.dates || "",
            location: data.travelDetails?.location || "",
            weather: data.travelDetails?.weather || "",
            weatherUrl: data.travelDetails?.weatherUrl || "",
            travellers: data.travellers.map(t => ({
              name: t.name,
              type: t.type as "adult" | "child",
              ageAtTravel: t.ageAtTravel || null,
              displayOrder: t.displayOrder,
            })),
            outboundTravel: mapOutboundFromDb(data.outboundTravel),
            accommodations: data.accommodations.map(mapAccommodationFromDb),
            activities: data.activities.map(mapActivityFromDb),
            dining: data.dining.map(mapDiningFromDb),
            bars: (data.bars || []).map(mapBarFromDb),
            additionalTravel: data.additionalTravel.map(mapAdditionalTravelFromDb),
            returnTravel: mapReturnFromDb(data.returnTravel),
            helpfulInformation: data.helpfulInformation ? {
              localEmergency: data.helpfulInformation.localEmergency || "",
              nearestEmbassy: data.helpfulInformation.nearestEmbassy || "",
              travelInsurance: data.helpfulInformation.travelInsurance || "",
              airlineCustomerService: data.helpfulInformation.airlineCustomerService || "",
              localMedicalClinic: data.helpfulInformation.localMedicalClinic || "",
              transportContacts: data.helpfulInformation.transportContacts || "",
            } : initialData.helpfulInformation,
            customSections: data.customSectionItems?.map(item => ({
              customSectionId: item.customSectionId || "",
              sectionTitle: item.sectionTitle || "",
              fieldValues: item.values.reduce((acc: Record<string, string>, fv) => {
                acc[fv.customFieldId || ""] = fv.value || "";
                return acc;
              }, {} as Record<string, string>),
            })) || [],
          };
          
          console.log("Transformed wizard data:", transformedData);
          setWizardData(transformedData);
          setDraftRestored(true); // Mark as restored to prevent draft loading
          setIsLoadingEdit(false);
          console.log("Edit mode data loaded successfully");
        } catch (error) {
          console.error("Error loading itinerary:", error);
          console.error("Error details:", error instanceof Error ? error.message : String(error));
          console.error("Error stack:", error instanceof Error ? error.stack : "No stack trace");
          setIsLoadingEdit(false);
          toast({
            title: "Error",
            description: error instanceof Error ? error.message : "Failed to load itinerary for editing.",
            variant: "destructive",
          });
          setLocation("/");
        }
      };
      
      fetchItinerary();
    }
  }, [isEditMode, editId, toast, setLocation]);

  // Restore draft on mount (only when NOT in edit mode)
  useEffect(() => {
    if (!isEditMode) {
      const savedDraft = localStorage.getItem(DRAFT_KEY);
      if (savedDraft && !draftRestored) {
        try {
          const parsedDraft = JSON.parse(savedDraft);
          setWizardData(parsedDraft);
          setDraftRestored(true);
          toast({
            title: "Draft restored",
            description: "Your previous work has been restored. Continue where you left off.",
          });
        } catch (error) {
          console.error("Error restoring draft:", error);
          localStorage.removeItem(DRAFT_KEY);
        }
      }
    }
  }, [draftRestored, toast, isEditMode]);

  // Auto-save to localStorage with debouncing
  useEffect(() => {
    if (!draftRestored && wizardData === initialData) {
      // Don't auto-save initial state before draft restoration
      return;
    }

    const timeoutId = setTimeout(() => {
      localStorage.setItem(DRAFT_KEY, JSON.stringify(wizardData));
    }, AUTO_SAVE_DELAY);

    return () => clearTimeout(timeoutId);
  }, [wizardData, draftRestored]);

  // Auto-save without toast or redirect
  const persistDraft = async () => {
    // Only save if page 0 is complete
    if (pageCompletion[0] !== "complete" && pageCompletion[0] !== "current") {
      return;
    }

    try {
      await saveItinerary("draft");
    } catch (error) {
      console.error("Auto-save failed:", error);
      throw error;
    }
  };

  // Handle navigation between pages with auto-save
  const handlePageNavigation = async (targetPage: number) => {
    if (targetPage === currentPage || isNavigating) return;

    setIsNavigating(true);
    try {
      // Auto-save current page if page 0 is complete
      if (pageCompletion[0] === "complete" || pageCompletion[0] === "current") {
        await persistDraft();
      }
      setCurrentPage(targetPage);
      window.scrollTo(0, 0);
    } catch (error) {
      toast({
        title: "Save failed",
        description: "Could not save your progress. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsNavigating(false);
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages - 1) {
      handlePageNavigation(currentPage + 1);
    }
  };

  const handlePrevious = () => {
    if (currentPage > 0) {
      handlePageNavigation(currentPage - 1);
    }
  };

  const saveItinerary = async (status: "draft" | "published") => {
    const itineraryPayload = {
      title: wizardData.title,
      assistantName: wizardData.assistantName,
      assistantEmail: wizardData.assistantEmail,
      customUrlSlug: wizardData.customUrlSlug || undefined,
      status,
    };

    let itineraryId: string;
    let slug: string;

    if (isEditMode && editId) {
      // Update existing itinerary
      console.log("Updating itinerary:", itineraryPayload);
      
      const itineraryResponse = await fetch(`/api/itineraries/${editId}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(itineraryPayload),
      });

      if (!itineraryResponse.ok) {
        const errorData = await itineraryResponse.json();
        console.error("Error response:", errorData);
        throw new Error("Failed to update itinerary");
      }

      const updatedItinerary = await itineraryResponse.json();
      itineraryId = updatedItinerary.id;
      slug = updatedItinerary.customUrlSlug;
      
      console.log("Updated itinerary:", updatedItinerary);
      
      // Delete all existing related data before recreating
      // This is simpler than trying to update each record individually
      console.log("Deleting all existing related data for itinerary:", itineraryId);
      const deleteResponse = await fetch(`/api/itinerary/${itineraryId}/delete-all-data`, {
        method: "DELETE",
      });
      
      if (!deleteResponse.ok) {
        const errorData = await deleteResponse.json();
        console.error("Error deleting existing data:", errorData);
        throw new Error("Failed to delete existing itinerary data");
      }
      
      const deleteResult = await deleteResponse.json();
      console.log("Deleted all existing related data:", deleteResult);
    } else {
      // Create new itinerary
      console.log("Creating itinerary:", itineraryPayload);

      const itineraryResponse = await fetch("/api/itineraries", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(itineraryPayload),
      });

      if (!itineraryResponse.ok) {
        const errorData = await itineraryResponse.json();
        console.error("Error response:", errorData);
        throw new Error("Failed to create itinerary");
      }

      const createdItinerary = await itineraryResponse.json();
      itineraryId = createdItinerary.id;
      slug = createdItinerary.customUrlSlug;

      console.log("Created itinerary:", createdItinerary);
      
      // Redirect to edit mode to prevent creating duplicates on subsequent saves
      setLocation(`/edit/${itineraryId}`, { replace: true });
    }

    // Step 2: Create travel details
    if (wizardData.dates || wizardData.location || wizardData.weather || wizardData.weatherUrl) {
      await fetch(`/api/itinerary/${itineraryId}/travel-details`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          dates: wizardData.dates,
          location: wizardData.location,
          weather: wizardData.weather,
          weatherUrl: wizardData.weatherUrl,
        }),
      });
    }

    // Step 3: Create travellers
    console.log(`Saving ${wizardData.travellers.length} travellers:`, wizardData.travellers);
    for (let i = 0; i < wizardData.travellers.length; i++) {
      const traveller = wizardData.travellers[i];
      
      // Validate traveller data
      if (traveller.name) {
        // If type is child, age is required
        if (traveller.type === "child" && (!traveller.ageAtTravel || traveller.ageAtTravel < 1)) {
          console.warn(`Skipping child traveller "${traveller.name}" - age is required for children`);
          continue;
        }
        
        const travellerResponse = await fetch(`/api/itinerary/${itineraryId}/travellers`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            name: traveller.name,
            type: traveller.type,
            ageAtTravel: traveller.type === "adult" ? null : traveller.ageAtTravel,
            displayOrder: i,
          }),
        });
        
        if (!travellerResponse.ok) {
          const errorData = await travellerResponse.json();
          console.error(`Error saving traveller ${i}:`, errorData);
        } else {
          const savedTraveller = await travellerResponse.json();
          console.log(`Saved traveller ${i}:`, savedTraveller);
        }
      }
    }

    // Step 4: Create outbound travel
    const hasOutboundData = Object.values(wizardData.outboundTravel).some(val => val !== "");
    if (hasOutboundData) {
      await fetch(`/api/itinerary/${itineraryId}/outbound-travel`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(wizardData.outboundTravel),
      });
    }

    // Step 5: Create accommodations
    for (let i = 0; i < wizardData.accommodations.length; i++) {
      const accommodation = wizardData.accommodations[i];
      if (accommodation.name) {
        await fetch(`/api/itinerary/${itineraryId}/accommodation`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...accommodation,
            displayOrder: i,
          }),
        });
      }
    }

    // Step 6: Create activities
    for (let i = 0; i < wizardData.activities.length; i++) {
      const activity = wizardData.activities[i];
      if (activity.name) {
        await fetch(`/api/itinerary/${itineraryId}/activities`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...activity,
            displayOrder: i,
          }),
        });
      }
    }

    // Step 7: Create dining
    for (let i = 0; i < wizardData.dining.length; i++) {
      const restaurant = wizardData.dining[i];
      if (restaurant.name) {
        await fetch(`/api/itinerary/${itineraryId}/dining`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...restaurant,
            displayOrder: i,
          }),
        });
      }
    }

    // Step 7b: Create bars
    for (let i = 0; i < wizardData.bars.length; i++) {
      const bar = wizardData.bars[i];
      if (bar.name) {
        await fetch(`/api/itinerary/${itineraryId}/bars`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...bar,
            displayOrder: i,
          }),
        });
      }
    }

    // Step 8: Create additional travel
    for (let i = 0; i < wizardData.additionalTravel.length; i++) {
      const travel = wizardData.additionalTravel[i];
      if (travel.travelType) {
        await fetch(`/api/itinerary/${itineraryId}/additional-travel`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            ...travel,
            displayOrder: i,
          }),
        });
      }
    }

    // Step 9: Create return travel
    const hasReturnData = Object.values(wizardData.returnTravel).some(val => val !== "");
    if (hasReturnData) {
      await fetch(`/api/itinerary/${itineraryId}/return-travel`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(wizardData.returnTravel),
      });
    }

    // Step 10: Create helpful information
    const hasHelpfulInfo = Object.values(wizardData.helpfulInformation).some(val => val !== "");
    if (hasHelpfulInfo) {
      await fetch(`/api/itinerary/${itineraryId}/helpful-info`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(wizardData.helpfulInformation),
      });
    }

    // Step 11: Create custom sections
    for (let i = 0; i < wizardData.customSections.length; i++) {
      const customSection = wizardData.customSections[i];
      if (customSection.customSectionId) {
        await fetch(`/api/itineraries/${itineraryId}/custom-sections`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            customSectionId: customSection.customSectionId,
            sectionTitle: customSection.sectionTitle,
            fieldValues: customSection.fieldValues,
            displayOrder: i,
          }),
        });
      }
    }

    // Clear draft from localStorage
    localStorage.removeItem('itinerary-draft');

    // Invalidate itineraries cache so Dashboard shows the new/updated itinerary
    queryClient.invalidateQueries({ queryKey: ["/api/itineraries"] });

    return { slug, itineraryId };
  };

  const handleSaveDraft = async () => {
    // Basic validation - require at least a title
    if (!wizardData?.title?.trim()) {
      toast({
        title: "Title required",
        description: "Please enter an itinerary title before saving.",
        variant: "destructive",
      });
      setCurrentPage(0);
      return;
    }

    // Validate travellers - children must have ages
    const childrenWithoutAge = wizardData.travellers.filter(
      t => t.name && t.type === "child" && (!t.ageAtTravel || t.ageAtTravel < 1)
    );
    if (childrenWithoutAge.length > 0) {
      toast({
        title: "Child traveller age required",
        description: `Please enter age for all child travellers. ${childrenWithoutAge.length} child(ren) missing age.`,
        variant: "destructive",
      });
      setCurrentPage(0);
      return;
    }

    toast({
      title: "Saving draft...",
      description: "Please wait while we save your draft.",
    });

    try {
      await saveItinerary("draft");

      toast({
        title: "Draft saved",
        description: "Your itinerary draft has been saved.",
      });

      setLocation("/");
    } catch (error) {
      console.error("Error saving draft:", error);
      toast({
        title: "Error",
        description: "Failed to save draft. Please try again.",
        variant: "destructive",
      });
    }
  };

  const handleFinish = async () => {
    // Basic validation
    if (!wizardData?.title?.trim()) {
      toast({
        title: "Title required",
        description: "Please enter an itinerary title before finishing.",
        variant: "destructive",
      });
      setCurrentPage(0);
      return;
    }

    if (!wizardData?.assistantName?.trim() || !wizardData?.assistantEmail?.trim()) {
      toast({
        title: "Assistant details required",
        description: "Please fill in assistant name and email.",
        variant: "destructive",
      });
      setCurrentPage(0);
      return;
    }

    // Validate travellers - children must have ages
    const childrenWithoutAge = wizardData.travellers.filter(
      t => t.name && t.type === "child" && (!t.ageAtTravel || t.ageAtTravel < 1)
    );
    if (childrenWithoutAge.length > 0) {
      toast({
        title: "Child traveller age required",
        description: `Please enter age for all child travellers. ${childrenWithoutAge.length} child(ren) missing age.`,
        variant: "destructive",
      });
      setCurrentPage(0);
      return;
    }

    // Validate custom sections required fields
    if (!customSectionsValid) {
      toast({
        title: "Required fields missing",
        description: "Please fill in all required fields in custom sections.",
        variant: "destructive",
      });
      setCurrentPage(8); // Navigate to custom sections page
      return;
    }

    toast({
      title: "Creating itinerary...",
      description: "Please wait while we save your itinerary.",
    });

    try {
      const { itineraryId } = await saveItinerary("draft");

      toast({
        title: "Success!",
        description: "Your itinerary has been saved. Review and arrange sections before publishing.",
      });

      // Navigate to the preview page
      setLocation(`/preview/${itineraryId}`);
    } catch (error) {
      console.error("Error creating itinerary:", error);
      toast({
        title: "Error",
        description: "Failed to create itinerary. Please try again.",
        variant: "destructive",
      });
    }
  };

  const updateData = (updates: Partial<WizardData>) => {
    setWizardData({ ...wizardData, ...updates });
  };

  const renderPage = () => {
    switch (currentPage) {
      case 0:
        return <Page1BasicInfo data={wizardData} updateData={updateData} />;
      case 1:
        return <Page2OutboundTravel data={wizardData} updateData={updateData} />;
      case 2:
        return <Page3Accommodation data={wizardData} updateData={updateData} />;
      case 3:
        return <Page4Activities data={wizardData} updateData={updateData} />;
      case 4:
        return <Page5Dining data={wizardData} updateData={updateData} />;
      case 5:
        return <Page6AdditionalTravel data={wizardData} updateData={updateData} />;
      case 6:
        return <Page7ReturnTravel data={wizardData} updateData={updateData} />;
      case 7:
        return <Page8HelpfulInfo data={wizardData} updateData={updateData} />;
      default:
        return null;
    }
  };

  // Show loading screen when fetching edit data
  if (isLoadingEdit) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center space-y-4">
          <Loader2 className="w-12 h-12 animate-spin mx-auto text-primary" data-testid="loader-edit" />
          <p className="text-lg text-muted-foreground">Loading itinerary...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 md:px-6 py-4">
          <div className="flex items-center gap-4">
            <Link href="/">
              <img 
                src={logoUrl} 
                alt="BlckBx" 
                className="h-10 w-auto cursor-pointer hover-elevate active-elevate-2 rounded p-1"
                data-testid="img-logo"
              />
            </Link>
            <div className="flex-1">
              <h1 className="text-xl font-serif font-bold text-card-foreground">
                {isEditMode ? "Edit Itinerary" : "Create Itinerary"}
              </h1>
              <p className="text-sm text-muted-foreground">
                Page {currentPage + 1} of {totalPages}: {PAGE_TITLES[currentPage]}
              </p>
            </div>
          </div>
          
          {!showSidebar && (
            <div className="mt-4">
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </div>
      </header>

      <div className={showSidebar ? "flex" : ""}>
        {showSidebar && (
          <WizardNavigation
            currentPage={currentPage}
            pageCompletion={pageCompletion}
            onNavigate={handlePageNavigation}
            isNavigating={isNavigating}
          />
        )}

        <main className={`flex-1 px-4 md:px-6 py-8 ${showSidebar ? "max-w-5xl mx-auto" : "max-w-4xl mx-auto"}`}>
        <Card>
          <CardHeader>
            <CardTitle className="text-2xl">{PAGE_TITLES[currentPage]}</CardTitle>
            <CardDescription>
              {currentPage === 0 && "Start with the basic details of your itinerary"}
              {currentPage === 1 && "Add outbound travel details including transfers and flights"}
              {currentPage === 2 && "Add accommodation details with maps and images"}
              {currentPage === 3 && "Suggest activities for your travellers"}
              {currentPage === 4 && "Recommend restaurants and dining experiences"}
              {currentPage === 5 && "Add any additional travel like ferries or trains (optional)"}
              {currentPage === 6 && "Add return travel details"}
              {currentPage === 7 && "Include helpful contact information"}
              {currentPage === 8 && "Add custom sections from your templates (optional)"}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {renderPage()}
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex items-center justify-between mt-8 gap-4">
          <Button
            variant="outline"
            onClick={handlePrevious}
            disabled={currentPage === 0}
            data-testid="button-previous"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Previous
          </Button>

          <Button
            variant="outline"
            onClick={handleSaveDraft}
            data-testid="button-save-draft"
          >
            <Save className="w-4 h-4 mr-2" />
            Save as Draft
          </Button>

          {processedPreviewData && !isProcessingImages ? (
            <PDFDownloadLink
              document={<ItineraryPDFTemplate data={processedPreviewData} />}
              fileName={`${wizardData.customUrlSlug || wizardData.title || 'preview'}_BlckBx_Preview.pdf`}
            >
              {({ loading }) => (
                <Button 
                  variant="outline"
                  disabled={loading}
                  data-testid="button-preview-pdf"
                >
                  <FileText className="w-4 h-4 mr-2" />
                  {loading ? "Generating..." : "Preview PDF"}
                </Button>
              )}
            </PDFDownloadLink>
          ) : (
            <Button 
              variant="outline"
              disabled
              data-testid="button-preview-pdf"
            >
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Processing Images...
            </Button>
          )}

          {currentPage < totalPages - 1 ? (
            <Button
              onClick={handleNext}
              data-testid="button-next"
            >
              Next
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          ) : (
            <Button
              onClick={handleFinish}
              data-testid="button-finish"
            >
              Finish & View
            </Button>
          )}
        </div>
        </main>
      </div>
    </div>
  );
}
