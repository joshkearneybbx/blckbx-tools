import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import type { WizardData } from "@/pages/CreateItinerary";

type Props = {
  data: WizardData;
  updateData: (updates: Partial<WizardData>) => void;
};

export default function Page8HelpfulInfo({ data, updateData }: Props) {
  const updateInfo = (field: string, value: string) => {
    updateData({
      helpfulInformation: {
        ...data.helpfulInformation,
        [field]: value,
      },
    });
  };

  return (
    <div className="space-y-6">
      <p className="text-sm text-muted-foreground">
        Add helpful contact information and emergency details. All fields are optional.
      </p>

      <div className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="localEmergency">Local Emergency Number</Label>
          <Input
            id="localEmergency"
            value={data.helpfulInformation.localEmergency}
            onChange={(e) => updateInfo("localEmergency", e.target.value)}
            placeholder="e.g., 112"
            data-testid="input-local-emergency"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="nearestEmbassy">Nearest British Embassy/Consulate</Label>
          <Textarea
            id="nearestEmbassy"
            value={data.helpfulInformation.nearestEmbassy}
            onChange={(e) => updateInfo("nearestEmbassy", e.target.value)}
            placeholder="Include address and contact details"
            data-testid="textarea-nearest-embassy"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="travelInsurance">Travel Insurance Contact</Label>
          <Textarea
            id="travelInsurance"
            value={data.helpfulInformation.travelInsurance}
            onChange={(e) => updateInfo("travelInsurance", e.target.value)}
            placeholder="Insurance company name and emergency contact number"
            data-testid="textarea-travel-insurance"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="airlineCustomerService">Airline/Travel Provider Customer Service</Label>
          <Input
            id="airlineCustomerService"
            value={data.helpfulInformation.airlineCustomerService}
            onChange={(e) => updateInfo("airlineCustomerService", e.target.value)}
            placeholder="e.g., +44 123 456 7890"
            data-testid="input-airline-service"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="localMedicalClinic">Local Medical Clinic/Hospital</Label>
          <Textarea
            id="localMedicalClinic"
            value={data.helpfulInformation.localMedicalClinic}
            onChange={(e) => updateInfo("localMedicalClinic", e.target.value)}
            placeholder="Nearest medical facility with address and contact"
            data-testid="textarea-medical-clinic"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="transportContacts">Local Transport Contacts</Label>
          <Textarea
            id="transportContacts"
            value={data.helpfulInformation.transportContacts}
            onChange={(e) => updateInfo("transportContacts", e.target.value)}
            placeholder="Taxi companies, car rental, etc."
            data-testid="textarea-transport-contacts"
          />
        </div>
      </div>
    </div>
  );
}
