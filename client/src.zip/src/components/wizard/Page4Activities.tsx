import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Plus, X } from "lucide-react";
import type { WizardData } from "@/pages/CreateItinerary";

type Props = {
  data: WizardData;
  updateData: (updates: Partial<WizardData>) => void;
};

export default function Page4Activities({ data, updateData }: Props) {
  const addActivity = () => {
    const newActivity = {
      name: "",
      description: "",
      price: "",
      images: [],
      contactDetails: "",
      address: "",
      googleMapsLink: "",
      websiteUrl: "",
      notes: "",
      displayOrder: data.activities.length,
    };
    updateData({ activities: [...data.activities, newActivity] });
  };

  const removeActivity = (index: number) => {
    const newActivities = data.activities.filter((_, i) => i !== index);
    updateData({ activities: newActivities });
  };

  const updateActivity = (index: number, field: string, value: string | string[]) => {
    const newActivities = [...data.activities];
    newActivities[index] = { ...newActivities[index], [field]: value };
    updateData({ activities: newActivities });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Suggest activities and experiences for your clients (optional)
        </p>
        <Button
          type="button"
          onClick={addActivity}
          data-testid="button-add-activity"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Activity
        </Button>
      </div>

      {data.activities.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed rounded-lg">
          <p className="text-muted-foreground">No activities added yet</p>
          <p className="text-sm text-muted-foreground mt-2">Click "Add Activity" to suggest experiences</p>
        </div>
      ) : (
        <div className="space-y-6">
          {data.activities.map((activity, index) => (
            <div
              key={index}
              className="p-6 border rounded-lg space-y-4 relative"
              data-testid={`activity-item-${index}`}
            >
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">Activity {index + 1}</h4>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeActivity(index)}
                  data-testid={`button-remove-activity-${index}`}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-name-${index}`}>Activity Name</Label>
                <Input
                  id={`activity-name-${index}`}
                  value={activity.name}
                  onChange={(e) => updateActivity(index, "name", e.target.value)}
                  placeholder="e.g., Old Town Walking Tour"
                  data-testid={`input-activity-name-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-description-${index}`}>Description</Label>
                <Textarea
                  id={`activity-description-${index}`}
                  value={activity.description}
                  onChange={(e) => updateActivity(index, "description", e.target.value)}
                  placeholder="Describe the activity..."
                  rows={4}
                  data-testid={`textarea-activity-description-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-price-${index}`}>Price</Label>
                <Input
                  id={`activity-price-${index}`}
                  value={activity.price}
                  onChange={(e) => updateActivity(index, "price", e.target.value)}
                  placeholder="e.g., €50 per person"
                  data-testid={`input-activity-price-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-images-${index}`}>Images (URLs, comma-separated)</Label>
                <Input
                  id={`activity-images-${index}`}
                  value={activity.images.join(", ")}
                  onChange={(e) => {
                    const images = e.target.value.split(",").map(url => url.trim()).filter(Boolean);
                    updateActivity(index, "images", images);
                  }}
                  placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg"
                  data-testid={`input-activity-images-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-contact-${index}`}>Contact Details (Optional)</Label>
                <Input
                  id={`activity-contact-${index}`}
                  value={activity.contactDetails || ""}
                  onChange={(e) => updateActivity(index, "contactDetails", e.target.value)}
                  placeholder="Phone, email, or contact details"
                  data-testid={`input-activity-contact-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-address-${index}`}>Address (Optional)</Label>
                <Input
                  id={`activity-address-${index}`}
                  value={activity.address || ""}
                  onChange={(e) => updateActivity(index, "address", e.target.value)}
                  placeholder="e.g., 123 Main Street, City"
                  data-testid={`input-activity-address-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-maps-${index}`}>Google Maps Link (Optional)</Label>
                <Input
                  id={`activity-maps-${index}`}
                  type="url"
                  value={activity.googleMapsLink || ""}
                  onChange={(e) => updateActivity(index, "googleMapsLink", e.target.value)}
                  placeholder="https://maps.google.com/..."
                  data-testid={`input-activity-maps-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-website-${index}`}>Website/Booking Link (Optional)</Label>
                <Input
                  id={`activity-website-${index}`}
                  type="url"
                  value={activity.websiteUrl || ""}
                  onChange={(e) => updateActivity(index, "websiteUrl", e.target.value)}
                  placeholder="https://..."
                  data-testid={`input-activity-website-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`activity-notes-${index}`}>Notes (Optional)</Label>
                <Textarea
                  id={`activity-notes-${index}`}
                  value={activity.notes || ""}
                  onChange={(e) => updateActivity(index, "notes", e.target.value)}
                  placeholder="e.g., Tickets only at door, arrive 30 mins early, bring ID..."
                  rows={3}
                  data-testid={`textarea-activity-notes-${index}`}
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
