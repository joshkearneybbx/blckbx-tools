import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Plus, X } from "lucide-react";
import type { WizardData } from "@/pages/CreateItinerary";

type Props = {
  data: WizardData;
  updateData: (updates: Partial<WizardData>) => void;
};

export default function Page3Accommodation({ data, updateData }: Props) {
  const addAccommodation = () => {
    const newAccommodation = {
      name: "",
      address: "",
      googleMapsLink: "",
      checkInDetails: "",
      images: [],
      websiteUrl: "",
      bookingReference: "",
      contactInfo: "",
      notes: "",
      displayOrder: data.accommodations.length,
    };
    updateData({ accommodations: [...data.accommodations, newAccommodation] });
  };

  const removeAccommodation = (index: number) => {
    const newAccommodations = data.accommodations.filter((_, i) => i !== index);
    updateData({ accommodations: newAccommodations });
  };

  const updateAccommodation = (index: number, field: string, value: string) => {
    const newAccommodations = [...data.accommodations];
    newAccommodations[index] = { ...newAccommodations[index], [field]: value };
    updateData({ accommodations: newAccommodations });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <p className="text-sm text-muted-foreground">
          Add accommodation details for your itinerary. Include maps and images to help your clients.
        </p>
        <Button
          type="button"
          onClick={addAccommodation}
          data-testid="button-add-accommodation"
        >
          <Plus className="w-4 h-4 mr-2" />
          Add Accommodation
        </Button>
      </div>

      {data.accommodations.length === 0 ? (
        <div className="text-center py-12 border-2 border-dashed rounded-lg">
          <p className="text-muted-foreground">No accommodations added yet</p>
          <p className="text-sm text-muted-foreground mt-2">Click "Add Accommodation" to get started</p>
        </div>
      ) : (
        <div className="space-y-6">
          {data.accommodations.map((accommodation, index) => (
            <div
              key={index}
              className="p-6 border rounded-lg space-y-4 relative"
              data-testid={`accommodation-item-${index}`}
            >
              <div className="flex items-center justify-between">
                <h4 className="font-semibold">Accommodation {index + 1}</h4>
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  onClick={() => removeAccommodation(index)}
                  data-testid={`button-remove-accommodation-${index}`}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-name-${index}`}>Name</Label>
                <Input
                  id={`accommodation-name-${index}`}
                  value={accommodation.name}
                  onChange={(e) => updateAccommodation(index, "name", e.target.value)}
                  placeholder="e.g., Grand Hotel Riga"
                  data-testid={`input-accommodation-name-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-address-${index}`}>Address</Label>
                <Textarea
                  id={`accommodation-address-${index}`}
                  value={accommodation.address}
                  onChange={(e) => updateAccommodation(index, "address", e.target.value)}
                  placeholder="Full address"
                  data-testid={`textarea-accommodation-address-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-maps-${index}`}>Google Maps Link</Label>
                <Input
                  id={`accommodation-maps-${index}`}
                  value={accommodation.googleMapsLink}
                  onChange={(e) => updateAccommodation(index, "googleMapsLink", e.target.value)}
                  placeholder="Paste Google Maps link here"
                  data-testid={`input-accommodation-maps-${index}`}
                />
                {accommodation.googleMapsLink && (
                  <p className="text-xs text-muted-foreground">
                    Map preview will be generated when saved
                  </p>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-checkin-${index}`}>Check-in Details</Label>
                <Textarea
                  id={`accommodation-checkin-${index}`}
                  value={accommodation.checkInDetails}
                  onChange={(e) => updateAccommodation(index, "checkInDetails", e.target.value)}
                  placeholder="Check-in time, instructions, etc."
                  data-testid={`textarea-accommodation-checkin-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-images-${index}`}>Images (URLs, comma-separated)</Label>
                <Input
                  id={`accommodation-images-${index}`}
                  value={accommodation.images.join(", ")}
                  onChange={(e) => {
                    const images = e.target.value.split(",").map(url => url.trim()).filter(Boolean);
                    updateAccommodation(index, "images", images as any);
                  }}
                  placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg"
                  data-testid={`input-accommodation-images-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-website-${index}`}>Website URL (Optional)</Label>
                <Input
                  id={`accommodation-website-${index}`}
                  type="url"
                  value={accommodation.websiteUrl}
                  onChange={(e) => updateAccommodation(index, "websiteUrl", e.target.value)}
                  placeholder="https://..."
                  data-testid={`input-accommodation-website-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-booking-${index}`}>Booking Reference (Optional)</Label>
                <Input
                  id={`accommodation-booking-${index}`}
                  value={accommodation.bookingReference}
                  onChange={(e) => updateAccommodation(index, "bookingReference", e.target.value)}
                  placeholder="Booking confirmation number"
                  data-testid={`input-accommodation-booking-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-contact-${index}`}>Contact Information (Optional)</Label>
                <Input
                  id={`accommodation-contact-${index}`}
                  value={accommodation.contactInfo}
                  onChange={(e) => updateAccommodation(index, "contactInfo", e.target.value)}
                  placeholder="Phone, email, or contact details"
                  data-testid={`input-accommodation-contact-${index}`}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor={`accommodation-notes-${index}`}>Notes (Optional)</Label>
                <Textarea
                  id={`accommodation-notes-${index}`}
                  value={accommodation.notes || ""}
                  onChange={(e) => updateAccommodation(index, "notes", e.target.value)}
                  placeholder="e.g., Check-in after 3pm, late checkout available, breakfast included..."
                  rows={3}
                  data-testid={`textarea-accommodation-notes-${index}`}
                />
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
