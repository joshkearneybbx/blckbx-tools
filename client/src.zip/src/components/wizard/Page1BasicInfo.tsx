import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, X } from "lucide-react";
import type { WizardData } from "@/pages/CreateItinerary";

type Props = {
  data: WizardData;
  updateData: (updates: Partial<WizardData>) => void;
};

export default function Page1BasicInfo({ data, updateData }: Props) {
  const addTraveller = () => {
    const currentTravellers = data.travellers || [];
    const newTraveller = {
      name: "",
      type: "adult" as const,
      ageAtTravel: null,
      displayOrder: currentTravellers.length,
    };
    updateData({ travellers: [...currentTravellers, newTraveller] });
  };

  const removeTraveller = (index: number) => {
    const currentTravellers = data.travellers || [];
    const newTravellers = currentTravellers.filter((_, i) => i !== index);
    updateData({ travellers: newTravellers });
  };

  const updateTraveller = (index: number, field: string, value: string | number | null) => {
    const currentTravellers = data.travellers || [];
    const newTravellers = [...currentTravellers];
    newTravellers[index] = { ...newTravellers[index], [field]: value };
    
    // If changing type to adult, clear the age field
    if (field === "type" && value === "adult") {
      newTravellers[index].ageAtTravel = null;
    }
    
    updateData({ travellers: newTravellers });
  };

  const generateSlugPreview = (title: string) => {
    return title
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  };

  const slugPreview = generateSlugPreview(data.title || '');

  return (
    <div className="space-y-8">
      {/* Travel Details */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold border-b pb-2">Travel Details</h3>
        
        <div className="space-y-2">
          <Label htmlFor="title">Itinerary Title *</Label>
          <Input
            id="title"
            value={data.title}
            onChange={(e) => updateData({ title: e.target.value })}
            placeholder="e.g., Latvia Christmas 2025"
            data-testid="input-title"
          />
          {slugPreview && (
            <p className="text-sm text-muted-foreground">
              URL: <span className="font-mono">/itinerary/{slugPreview}</span>
            </p>
          )}
        </div>

        <div className="space-y-2">
          <Label htmlFor="dates">Dates</Label>
          <Input
            id="dates"
            value={data.dates}
            onChange={(e) => updateData({ dates: e.target.value })}
            placeholder="e.g., 25-28 December 2025"
            data-testid="input-dates"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="location">Location</Label>
          <Input
            id="location"
            value={data.location}
            onChange={(e) => updateData({ location: e.target.value })}
            placeholder="e.g., Riga, Latvia"
            data-testid="input-location"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="weather">Weather</Label>
          <Input
            id="weather"
            value={data.weather}
            onChange={(e) => updateData({ weather: e.target.value })}
            placeholder="e.g., Cold, -5°C to 2°C, snow expected"
            data-testid="input-weather"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="weatherUrl">Weather Forecast Link (Optional)</Label>
          <Input
            id="weatherUrl"
            type="url"
            value={data.weatherUrl}
            onChange={(e) => updateData({ weatherUrl: e.target.value })}
            placeholder="https://weather.com/..."
            data-testid="input-weather-url"
          />
          <p className="text-xs text-muted-foreground">
            Paste link to weather forecast (e.g., Weather.com, AccuWeather)
          </p>
        </div>
      </div>

      {/* Assistant Details */}
      <div className="space-y-4">
        <h3 className="text-lg font-semibold border-b pb-2">Assistant Information</h3>
        
        <div className="space-y-2">
          <Label htmlFor="assistantName">Name *</Label>
          <Input
            id="assistantName"
            value={data.assistantName}
            onChange={(e) => updateData({ assistantName: e.target.value })}
            data-testid="input-assistant-name"
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="assistantEmail">Email *</Label>
          <Input
            id="assistantEmail"
            type="email"
            value={data.assistantEmail}
            onChange={(e) => updateData({ assistantEmail: e.target.value })}
            data-testid="input-assistant-email"
          />
        </div>
      </div>

      {/* Traveller Details */}
      <div className="space-y-4">
        <div className="flex items-center justify-between border-b pb-2">
          <h3 className="text-lg font-semibold">Travellers</h3>
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={addTraveller}
            data-testid="button-add-traveller"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Traveller
          </Button>
        </div>

        {!data.travellers || data.travellers.length === 0 ? (
          <p className="text-sm text-muted-foreground text-center py-8">
            No travellers added yet. Click "Add Traveller" to add traveller details.
          </p>
        ) : (
          <div className="space-y-4">
            {data.travellers.map((traveller, index) => (
              <div
                key={index}
                className="p-4 border rounded-lg space-y-3 relative"
                data-testid={`traveller-item-${index}`}
              >
                <Button
                  type="button"
                  variant="ghost"
                  size="icon"
                  className="absolute top-2 right-2"
                  onClick={() => removeTraveller(index)}
                  data-testid={`button-remove-traveller-${index}`}
                >
                  <X className="w-4 h-4" />
                </Button>

                <div className="space-y-2 pr-10">
                  <Label htmlFor={`traveller-name-${index}`}>Name</Label>
                  <Input
                    id={`traveller-name-${index}`}
                    value={traveller.name}
                    onChange={(e) => updateTraveller(index, "name", e.target.value)}
                    placeholder="Traveller name"
                    data-testid={`input-traveller-name-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`traveller-type-${index}`}>Type</Label>
                  <Select
                    value={traveller.type}
                    onValueChange={(value) => updateTraveller(index, "type", value)}
                  >
                    <SelectTrigger id={`traveller-type-${index}`} data-testid={`select-traveller-type-${index}`}>
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="adult">Adult</SelectItem>
                      <SelectItem value="child">Child</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {traveller.type === "child" && (
                  <div className="space-y-2">
                    <Label htmlFor={`traveller-age-${index}`}>Age at Travel *</Label>
                    <Input
                      id={`traveller-age-${index}`}
                      type="number"
                      value={traveller.ageAtTravel ?? ""}
                      onChange={(e) => updateTraveller(index, "ageAtTravel", e.target.value ? parseInt(e.target.value) : null)}
                      placeholder="e.g., 8"
                      data-testid={`input-traveller-age-${index}`}
                    />
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
