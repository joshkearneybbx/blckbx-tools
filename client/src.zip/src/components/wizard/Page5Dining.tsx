import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Plus, X } from "lucide-react";
import type { WizardData } from "@/pages/CreateItinerary";

type Props = {
  data: WizardData;
  updateData: (updates: Partial<WizardData>) => void;
};

export default function Page5Dining({ data, updateData }: Props) {
  const addDining = () => {
    const newDining = {
      name: "",
      cuisineType: "",
      priceRange: "",
      images: [],
      contactDetails: "",
      address: "",
      googleMapsLink: "",
      websiteUrl: "",
      notes: "",
      displayOrder: data.dining.length,
    };
    updateData({ dining: [...data.dining, newDining] });
  };

  const removeDining = (index: number) => {
    const newDining = data.dining.filter((_, i) => i !== index);
    updateData({ dining: newDining });
  };

  const updateDining = (index: number, field: string, value: string | string[]) => {
    const newDining = [...data.dining];
    newDining[index] = { ...newDining[index], [field]: value };
    updateData({ dining: newDining });
  };

  const addBar = () => {
    const newBar = {
      name: "",
      barType: "",
      priceRange: "",
      images: [],
      contactDetails: "",
      address: "",
      googleMapsLink: "",
      websiteUrl: "",
      notes: "",
      displayOrder: data.bars.length,
    };
    updateData({ bars: [...data.bars, newBar] });
  };

  const removeBar = (index: number) => {
    const newBars = data.bars.filter((_, i) => i !== index);
    updateData({ bars: newBars });
  };

  const updateBar = (index: number, field: string, value: string | string[]) => {
    const newBars = [...data.bars];
    newBars[index] = { ...newBars[index], [field]: value };
    updateData({ bars: newBars });
  };

  return (
    <div className="space-y-10">
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold">Restaurants</h3>
            <p className="text-sm text-muted-foreground">
              Recommend restaurants and dining experiences (optional)
            </p>
          </div>
          <Button
            type="button"
            onClick={addDining}
            data-testid="button-add-dining"
          >
            <Plus className="w-4 h-4 mr-2" />
            Add Restaurant
          </Button>
        </div>

        {data.dining.length === 0 ? (
          <div className="text-center py-12 border-2 border-dashed rounded-lg">
            <p className="text-muted-foreground">No restaurants added yet</p>
            <p className="text-sm text-muted-foreground mt-2">Click "Add Restaurant" to recommend dining</p>
          </div>
        ) : (
          <div className="space-y-6">
            {data.dining.map((restaurant, index) => (
              <div
                key={index}
                className="p-6 border rounded-lg space-y-4 relative"
                data-testid={`dining-item-${index}`}
              >
                <div className="flex items-center justify-between">
                  <h4 className="font-semibold">Restaurant {index + 1}</h4>
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    onClick={() => removeDining(index)}
                    data-testid={`button-remove-dining-${index}`}
                  >
                    <X className="w-4 h-4" />
                  </Button>
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-name-${index}`}>Restaurant Name</Label>
                  <Input
                    id={`dining-name-${index}`}
                    value={restaurant.name}
                    onChange={(e) => updateDining(index, "name", e.target.value)}
                    placeholder="e.g., Restaurant 3"
                    data-testid={`input-dining-name-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-cuisineType-${index}`}>Cuisine Type</Label>
                  <Input
                    id={`dining-cuisineType-${index}`}
                    value={restaurant.cuisineType}
                    onChange={(e) => updateDining(index, "cuisineType", e.target.value)}
                    placeholder="e.g., Modern Latvian"
                    data-testid={`input-dining-cuisineType-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-priceRange-${index}`}>Price Range</Label>
                  <Input
                    id={`dining-priceRange-${index}`}
                    value={restaurant.priceRange}
                    onChange={(e) => updateDining(index, "priceRange", e.target.value)}
                    placeholder="e.g., €€€ or $50-100 per person"
                    data-testid={`input-dining-priceRange-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-images-${index}`}>Images (URLs, comma-separated)</Label>
                  <Input
                    id={`dining-images-${index}`}
                    value={restaurant.images.join(", ")}
                    onChange={(e) => {
                      const images = e.target.value.split(",").map(url => url.trim()).filter(Boolean);
                      updateDining(index, "images", images);
                    }}
                    placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg"
                    data-testid={`input-dining-images-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-contactDetails-${index}`}>Contact Details (Optional)</Label>
                  <Input
                    id={`dining-contactDetails-${index}`}
                    value={restaurant.contactDetails}
                    onChange={(e) => updateDining(index, "contactDetails", e.target.value)}
                    placeholder="Phone, email, or contact details"
                    data-testid={`input-dining-contactDetails-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-address-${index}`}>Address (Optional)</Label>
                  <Input
                    id={`dining-address-${index}`}
                    value={restaurant.address}
                    onChange={(e) => updateDining(index, "address", e.target.value)}
                    placeholder="Restaurant address"
                    data-testid={`input-dining-address-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-googleMapsLink-${index}`}>Google Maps Link (Optional)</Label>
                  <Input
                    id={`dining-googleMapsLink-${index}`}
                    type="url"
                    value={restaurant.googleMapsLink}
                    onChange={(e) => updateDining(index, "googleMapsLink", e.target.value)}
                    placeholder="https://maps.google.com/..."
                    data-testid={`input-dining-googleMapsLink-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-website-${index}`}>Website/Booking Link (Optional)</Label>
                  <Input
                    id={`dining-website-${index}`}
                    type="url"
                    value={restaurant.websiteUrl}
                    onChange={(e) => updateDining(index, "websiteUrl", e.target.value)}
                    placeholder="https://..."
                    data-testid={`input-dining-website-${index}`}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor={`dining-notes-${index}`}>Notes (Optional)</Label>
                  <Textarea
                    id={`dining-notes-${index}`}
                    value={restaurant.notes || ""}
                    onChange={(e) => updateDining(index, "notes", e.target.value)}
                    placeholder="e.g., Reservation required, dress code smart casual, ask for window seat..."
                    rows={3}
                    data-testid={`textarea-dining-notes-${index}`}
                  />
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      <div className="border-t pt-10">
        <div className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-semibold">Bars and Pubs</h3>
              <p className="text-sm text-muted-foreground">
                Recommend bars, pubs, and nightlife spots (optional)
              </p>
            </div>
            <Button
              type="button"
              onClick={addBar}
              data-testid="button-add-bar"
            >
              <Plus className="w-4 h-4 mr-2" />
              Add Bar/Pub
            </Button>
          </div>

          {data.bars.length === 0 ? (
            <div className="text-center py-12 border-2 border-dashed rounded-lg">
              <p className="text-muted-foreground">No bars or pubs added yet</p>
              <p className="text-sm text-muted-foreground mt-2">Click "Add Bar/Pub" to recommend nightlife spots</p>
            </div>
          ) : (
            <div className="space-y-6">
              {data.bars.map((bar, index) => (
                <div
                  key={index}
                  className="p-6 border rounded-lg space-y-4 relative"
                  data-testid={`bar-item-${index}`}
                >
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold">Bar/Pub {index + 1}</h4>
                    <Button
                      type="button"
                      variant="ghost"
                      size="icon"
                      onClick={() => removeBar(index)}
                      data-testid={`button-remove-bar-${index}`}
                    >
                      <X className="w-4 h-4" />
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-name-${index}`}>Bar/Pub Name</Label>
                    <Input
                      id={`bar-name-${index}`}
                      value={bar.name}
                      onChange={(e) => updateBar(index, "name", e.target.value)}
                      placeholder="e.g., The Blue Bar"
                      data-testid={`input-bar-name-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-barType-${index}`}>Bar Type</Label>
                    <Input
                      id={`bar-barType-${index}`}
                      value={bar.barType}
                      onChange={(e) => updateBar(index, "barType", e.target.value)}
                      placeholder="e.g., Cocktail Bar, Sports Pub, Wine Bar"
                      data-testid={`input-bar-barType-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-priceRange-${index}`}>Price Range</Label>
                    <Input
                      id={`bar-priceRange-${index}`}
                      value={bar.priceRange}
                      onChange={(e) => updateBar(index, "priceRange", e.target.value)}
                      placeholder="e.g., €€ or $15-30 per drink"
                      data-testid={`input-bar-priceRange-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-images-${index}`}>Images (URLs, comma-separated)</Label>
                    <Input
                      id={`bar-images-${index}`}
                      value={bar.images.join(", ")}
                      onChange={(e) => {
                        const images = e.target.value.split(",").map(url => url.trim()).filter(Boolean);
                        updateBar(index, "images", images);
                      }}
                      placeholder="https://example.com/image1.jpg, https://example.com/image2.jpg"
                      data-testid={`input-bar-images-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-contactDetails-${index}`}>Contact Details (Optional)</Label>
                    <Input
                      id={`bar-contactDetails-${index}`}
                      value={bar.contactDetails}
                      onChange={(e) => updateBar(index, "contactDetails", e.target.value)}
                      placeholder="Phone, email, or contact details"
                      data-testid={`input-bar-contactDetails-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-address-${index}`}>Address (Optional)</Label>
                    <Input
                      id={`bar-address-${index}`}
                      value={bar.address}
                      onChange={(e) => updateBar(index, "address", e.target.value)}
                      placeholder="Bar/Pub address"
                      data-testid={`input-bar-address-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-googleMapsLink-${index}`}>Google Maps Link (Optional)</Label>
                    <Input
                      id={`bar-googleMapsLink-${index}`}
                      type="url"
                      value={bar.googleMapsLink}
                      onChange={(e) => updateBar(index, "googleMapsLink", e.target.value)}
                      placeholder="https://maps.google.com/..."
                      data-testid={`input-bar-googleMapsLink-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-website-${index}`}>Website/Booking Link (Optional)</Label>
                    <Input
                      id={`bar-website-${index}`}
                      type="url"
                      value={bar.websiteUrl}
                      onChange={(e) => updateBar(index, "websiteUrl", e.target.value)}
                      placeholder="https://..."
                      data-testid={`input-bar-website-${index}`}
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor={`bar-notes-${index}`}>Notes (Optional)</Label>
                    <Textarea
                      id={`bar-notes-${index}`}
                      value={bar.notes || ""}
                      onChange={(e) => updateBar(index, "notes", e.target.value)}
                      placeholder="e.g., Live music on weekends, happy hour 5-7pm..."
                      rows={3}
                      data-testid={`textarea-bar-notes-${index}`}
                    />
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
