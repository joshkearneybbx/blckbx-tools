import {
  Document,
  Page,
  Text,
  View,
  Image,
  Link,
  StyleSheet,
} from "@react-pdf/renderer";
import type { FullItinerary } from "@shared/schema";
import logoUrl from "@assets/BlckBx PNG on Blck_1763042542782.png";

// Styles for the new sidebar layout
const styles = StyleSheet.create({
  page: {
    flexDirection: "row",
    backgroundColor: "#FAF9F8",
    fontFamily: "Helvetica",
  },

  // Base Black #1C1D1F sidebar - fixed on every page
  sidebar: {
    width: 120,
    backgroundColor: "#1C1D1F",
    padding: 20,
    color: "#FFFFFF",
    flexDirection: "column",
  },

  sidebarLogo: {
    width: 80,
    height: "auto",
    marginBottom: 40,
  },

  sidebarTripTitle: {
    fontSize: 11,
    fontWeight: "bold",
    color: "#FFFFFF",
    lineHeight: 1.3,
    marginBottom: 20,
    maxWidth: 80,
  },

  sidebarSpacer: {
    flex: 1,
  },

  sidebarAssistantSection: {
    marginBottom: 60,
  },

  sidebarAssistantHeading: {
    fontSize: 10,
    fontWeight: "bold",
    color: "#FFFFFF",
    marginBottom: 8,
  },

  sidebarAssistantName: {
    fontSize: 11,
    color: "#FFFFFF",
    marginBottom: 4,
  },

  sidebarAssistantEmail: {
    fontSize: 6,
    color: "#FFFFFF",
    textDecoration: "underline",
    maxWidth: 80,
    lineHeight: 1.2,
  },

  sidebarPageNumber: {
    fontSize: 10,
    color: "rgba(255, 255, 255, 0.7)",
    textAlign: "center",
    paddingBottom: 15,
  },

  // Main content area
  mainContent: {
    flex: 1,
    paddingTop: 40,
    paddingBottom: 40,
    paddingRight: 40,
    paddingLeft: 30,
    minHeight: 40,
  },

  // ✅ NEW: Wrapper for content sections to ensure top padding on page breaks
  contentWrapper: {
    paddingTop: 0, // Will be overridden when needed
  },

  // Page header (trip info)
  pageHeader: {
    marginBottom: 30,
  },

  pageTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#1C1D1F",
    marginBottom: 8,
  },

  pageSubtitle: {
    fontSize: 14,
    color: "#666666",
    marginBottom: 4,
  },

  // Section styling
  sectionTitle: {
    fontSize: 28,
    fontWeight: "bold",
    color: "#1C1D1F",
    marginTop: 0,
    marginBottom: 20,
    borderBottom: "2 solid #e0e0e0",
    paddingBottom: 10,
  },

  // Item cards - #F5F3F0 for PDF
  itemCard: {
    backgroundColor: "#F5F3F0",
    padding: 20,
    marginTop: 30,     // Add top margin to create space on new pages
    marginBottom: 20,
    borderRadius: 8,
  },

  firstItemCard: {
    backgroundColor: "#F5F3F0",
    padding: 20,
    marginTop: 0,      // No top margin for first card (section title provides spacing)
    marginBottom: 20,
    borderRadius: 8,
  },

  itemHeading: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#1C1D1F",
    marginBottom: 12,
  },

  itemText: {
    fontSize: 11,
    color: "#374151",
    marginBottom: 6,
    lineHeight: 1.6,
  },

  // ✅ FIXED: Field group wrapper to force block-level stacking
  fieldGroup: {
    marginBottom: 10,
  },

  itemLabel: {
    fontSize: 10,
    fontWeight: "bold",
    color: "#666666",
    marginBottom: 3,
    textTransform: "uppercase",
  },

  itemValue: {
    fontSize: 11,
    color: "#374151",
    lineHeight: 1.5,
  },

  itemLink: {
    fontSize: 11,
    color: "#6B1488",
    textDecoration: "underline",
    marginBottom: 6,
    marginTop: 4,
  },

  // Container for links to stack vertically
  linksContainer: {
    flexDirection: "column",
    marginTop: 8,
    marginBottom: 8,
  },

  linkRow: {
    marginBottom: 4,
  },

  flightTrackerLink: {
    color: "#0066CC",
    textDecoration: "none",
    fontSize: 11,
    marginTop: 12,
    paddingVertical: 6,
    paddingHorizontal: 10,
    backgroundColor: "#F0F8FF",
    borderRadius: 4,
  },

  // ✅ FIXED: Image styling - removed objectFit which causes issues
  itemImage: {
    width: "100%",
    height: 180,
    marginTop: 12,
    marginBottom: 8,
    borderRadius: 8,
  },

  imageUrlText: {
    fontSize: 9,
    color: "#2563eb",
    textDecoration: "underline",
    marginBottom: 12,
  },

  // Traveller cards - #F5F3F0 for PDF
  travellerCard: {
    backgroundColor: "#F5F3F0",
    padding: 12,
    marginBottom: 12,
    borderRadius: 4,
  },

  travellerName: {
    fontSize: 12,
    fontWeight: "bold",
    color: "#1C1D1F",
    marginBottom: 4,
  },

  // Transfer sections - full size when has content
  transferSectionFull: {
    marginTop: 20,
    marginBottom: 20,
    padding: 16,
    backgroundColor: "#F5F3F0",
    borderRadius: 6,
    borderLeft: "3 solid #1C1D1F",
  },

  // Transfer sections - compact when empty
  transferSectionCompact: {
    marginTop: 12,
    marginBottom: 12,
    padding: 10,
    backgroundColor: "#F9FAFB",
    borderRadius: 4,
    borderLeft: "2 solid #D1D5DB",
  },

  transferLabel: {
    fontSize: 12,
    fontWeight: "bold",
    color: "#374151",
    marginBottom: 6,
  },

  transferText: {
    fontSize: 10,
    color: "#374151",
    lineHeight: 1.4,
  },

  transferTextEmpty: {
    fontSize: 10,
    color: "#9CA3AF",
    fontStyle: "italic",
  },

  travellerType: {
    fontSize: 10,
    color: "#666666",
  },

  // Flight Card styles
  flightCard: {
    marginVertical: 10,
    borderRadius: 8,
    border: "1 solid #E5E7EB",
    overflow: "hidden",
  },
  flightCardHeader: {
    backgroundColor: "#1C1D1F",
    padding: 12,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  flightCardTitle: {
    color: "#FFFFFF",
    fontSize: 14,
    fontWeight: "bold",
  },
  flightCardBadge: {
    backgroundColor: "#374151",
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 12,
  },
  flightCardBadgeText: {
    color: "#FFFFFF",
    fontSize: 9,
  },
  flightCardRoute: {
    padding: 20,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    backgroundColor: "#F5F3F0",
  },
  flightCardAirportSection: {
    flex: 1,
    alignItems: "center",
  },
  flightCardAirportCode: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#1F2937",
  },
  flightCardTime: {
    fontSize: 13,
    fontWeight: "bold",
    color: "#111827",
    marginTop: 4,
  },
  flightCardAirportName: {
    fontSize: 9,
    color: "#6B7280",
    marginTop: 2,
    textAlign: "center",
  },
  flightCardPath: {
    flex: 1,
    alignItems: "center",
    paddingHorizontal: 10,
  },
  flightCardPathLabel: {
    fontSize: 8,
    color: "#9CA3AF",
    marginBottom: 4,
  },
  flightCardPathLine: {
    flexDirection: "row",
    alignItems: "center",
    width: "100%",
  },
  flightCardPathDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    backgroundColor: "#1C1D1F",
  },
  flightCardPathLineSegment: {
    flex: 1,
    height: 2,
    backgroundColor: "#1C1D1F",
  },
  flightCardPlaneIcon: {
    fontSize: 10,
    marginHorizontal: 4,
  },
  flightCardLayover: {
    paddingVertical: 8,
    paddingHorizontal: 12,
    backgroundColor: "#F9FAFB",
    borderTop: "1 dashed #D1D5DB",
    borderBottom: "1 dashed #D1D5DB",
    alignItems: "center",
  },
  flightCardLayoverText: {
    fontSize: 9,
    color: "#D97706",
    fontWeight: "bold",
  },
  flightCardDetails: {
    backgroundColor: "#F9FAFB",
    padding: 16,
    borderTop: "1 solid #E5E7EB",
  },
  flightCardDetailsRow: {
    flexDirection: "row",
    gap: 24,
    marginBottom: 8,
    flexWrap: "wrap",
  },
  flightCardDetailItem: {
    flexDirection: "row",
    alignItems: "center",
    gap: 4,
  },
  flightCardDetailLabel: {
    fontSize: 10,
    color: "#6B7280",
    marginRight: 4,
  },
  flightCardDetailText: {
    fontSize: 10,
    color: "#374151",
  },
  flightCardNotes: {
    marginTop: 8,
    padding: 10,
    backgroundColor: "#F79A66",
    borderRadius: 6,
  },
  flightCardNotesTitle: {
    fontSize: 8,
    fontWeight: "bold",
    color: "#1C1D1F",
    marginBottom: 4,
  },
  flightCardNotesText: {
    fontSize: 10,
    color: "#1C1D1F",
  },
  flightCardTrackButton: {
    backgroundColor: "#6B1488",
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    alignSelf: "flex-start",
    marginTop: 8,
  },
  flightCardTrackButtonText: {
    color: "#FFFFFF",
    fontSize: 10,
    fontWeight: "bold",
  },
});

// Flight leg interface for multi-leg flights
interface FlightLeg {
  departureAirport: string;
  departureTime: string;
  arrivalAirport: string;
  arrivalTime: string;
  flightNumber?: string;
  layoverDuration?: string;
}

// FlightCardPDF component for visual flight display
const FlightCardPDF = ({ 
  flightNumber, 
  date, 
  departureAirport, 
  departureTime, 
  arrivalAirport, 
  arrivalTime, 
  passengers, 
  notes,
  isMultiLeg = false,
  legs = [],
  getFlightTrackerUrl,
}: {
  flightNumber: string;
  date?: string | null;
  departureAirport?: string | null;
  departureTime?: string | null;
  arrivalAirport?: string | null;
  arrivalTime?: string | null;
  passengers?: string | null;
  notes?: string | null;
  isMultiLeg?: boolean;
  legs?: FlightLeg[];
  getFlightTrackerUrl: (fn: string) => string;
}) => {
  const cleanFlightNumber = flightNumber?.replace(/\s/g, '').toUpperCase() || '';

  const getAirportCode = (airport: string | null | undefined) => {
    if (!airport) return '---';
    if (/^[A-Z]{3}$/i.test(airport.trim())) return airport.trim().toUpperCase();
    return airport.substring(0, 3).toUpperCase();
  };

  const depCode = getAirportCode(departureAirport);
  const arrCode = getAirportCode(arrivalAirport);

  return (
    <View style={styles.flightCard} wrap={false}>
      {/* Header */}
      <View style={styles.flightCardHeader}>
        <Text style={styles.flightCardTitle}>{cleanFlightNumber}</Text>
        <View style={styles.flightCardBadge}>
          <Text style={styles.flightCardBadgeText}>
            {isMultiLeg && legs.length > 0 ? `${legs.length} stops` : 'Direct'}
          </Text>
        </View>
      </View>

      {/* Single Leg */}
      {!isMultiLeg && (
        <View style={styles.flightCardRoute}>
          <View style={styles.flightCardAirportSection}>
            <Text style={styles.flightCardAirportCode}>{depCode}</Text>
            <Text style={styles.flightCardTime}>{departureTime || '--:--'}</Text>
            <Text style={styles.flightCardAirportName}>{departureAirport || ''}</Text>
          </View>

          <View style={styles.flightCardPath}>
            <Text style={styles.flightCardPathLabel}>Direct</Text>
            <View style={styles.flightCardPathLine}>
              <View style={styles.flightCardPathDot} />
              <View style={styles.flightCardPathLineSegment} />
              <View style={styles.flightCardPathLineSegment} />
              <View style={styles.flightCardPathDot} />
            </View>
            <Text style={styles.flightCardPathLabel}>Non-stop</Text>
          </View>

          <View style={styles.flightCardAirportSection}>
            <Text style={styles.flightCardAirportCode}>{arrCode}</Text>
            <Text style={styles.flightCardTime}>{arrivalTime || '--:--'}</Text>
            <Text style={styles.flightCardAirportName}>{arrivalAirport || ''}</Text>
          </View>
        </View>
      )}

      {/* Multi-Leg */}
      {isMultiLeg && legs.length > 0 && (
        <View>
          {legs.map((leg, index) => (
            <View key={index}>
              <View style={styles.flightCardRoute}>
                <View style={styles.flightCardAirportSection}>
                  <Text style={styles.flightCardAirportCode}>{getAirportCode(leg.departureAirport)}</Text>
                  <Text style={styles.flightCardTime}>{leg.departureTime}</Text>
                  <Text style={styles.flightCardAirportName}>{leg.departureAirport}</Text>
                </View>

                <View style={styles.flightCardPath}>
                  {leg.flightNumber && (
                    <Text style={styles.flightCardPathLabel}>{leg.flightNumber}</Text>
                  )}
                  <View style={styles.flightCardPathLine}>
                    <View style={styles.flightCardPathDot} />
                    <View style={styles.flightCardPathLineSegment} />
                    <View style={styles.flightCardPathLineSegment} />
                    <View style={styles.flightCardPathDot} />
                  </View>
                </View>

                <View style={styles.flightCardAirportSection}>
                  <Text style={styles.flightCardAirportCode}>{getAirportCode(leg.arrivalAirport)}</Text>
                  <Text style={styles.flightCardTime}>{leg.arrivalTime}</Text>
                  <Text style={styles.flightCardAirportName}>{leg.arrivalAirport}</Text>
                </View>
              </View>

              {/* Layover indicator */}
              {index < legs.length - 1 && (
                <View style={styles.flightCardLayover}>
                  <Text style={styles.flightCardLayoverText}>
                    {leg.layoverDuration || 'Connection'} in {getAirportCode(leg.arrivalAirport)}
                  </Text>
                </View>
              )}
            </View>
          ))}
        </View>
      )}

      {/* Details */}
      <View style={styles.flightCardDetails}>
        <View style={styles.flightCardDetailsRow}>
          {date && (
            <View style={styles.flightCardDetailItem}>
              <Text style={styles.flightCardDetailLabel}>Date:</Text>
              <Text style={styles.flightCardDetailText}>{date}</Text>
            </View>
          )}
          {passengers && (
            <View style={styles.flightCardDetailItem}>
              <Text style={styles.flightCardDetailLabel}>Passengers:</Text>
              <Text style={styles.flightCardDetailText}>{passengers}</Text>
            </View>
          )}
        </View>

        {notes && (
          <View style={styles.flightCardNotes}>
            <Text style={styles.flightCardNotesTitle}>THINGS TO REMEMBER</Text>
            <Text style={styles.flightCardNotesText}>{notes}</Text>
          </View>
        )}

        <Link src={getFlightTrackerUrl(flightNumber)} style={styles.flightCardTrackButton}>
          <Text style={styles.flightCardTrackButtonText}>Track Flight {cleanFlightNumber}</Text>
        </Link>
      </View>
    </View>
  );
};

interface ItineraryPDFTemplateProps {
  data: FullItinerary;
}

// Images are now pre-processed as data URIs by useImagePreprocessor hook
// No URL fixing needed - data URIs bypass @react-pdf/renderer URL validation

export function ItineraryPDFTemplate({ data }: ItineraryPDFTemplateProps) {
  const {
    itinerary,
    travelDetails,
    travellers,
    accommodations: allAccommodations,
    activities: allActivities,
    dining: allDining,
    bars: allBars,
    outboundTravel,
    additionalTravel: allAdditionalTravel,
    returnTravel,
    helpfulInformation,
  } = data;

  // Filter out hidden items (visible === 0)
  const accommodations = allAccommodations?.filter(item => item.visible !== 0) || [];
  const activities = allActivities?.filter(item => item.visible !== 0) || [];
  const dining = allDining?.filter(item => item.visible !== 0) || [];
  const bars = allBars?.filter(item => item.visible !== 0) || [];
  const additionalTravel = allAdditionalTravel?.filter(item => item.visible !== 0) || [];

  // Helper function to check if returnTravel has any meaningful data
  const hasReturnTravelData = (travel: typeof returnTravel): boolean => {
    if (!travel) return false;
    return !!(
      travel.flightNumber?.trim() ||
      travel.flightDate?.trim() ||
      travel.departureAirport?.trim() ||
      travel.arrivalAirport?.trim() ||
      travel.departureTime?.trim() ||
      travel.arrivalTime?.trim() ||
      travel.passengersSeats?.trim() ||
      travel.thingsToRemember?.trim() ||
      travel.transferToAirportTaxiBooked === 1 ||
      travel.transferToAirportCompany?.trim() ||
      travel.transferToAirportContact?.trim() ||
      travel.transferToAirportCollectionTime?.trim() ||
      travel.transferToAirportPickupLocation?.trim() ||
      travel.transferToAirportPaymentStatus?.trim() ||
      travel.transferHomeTaxiBooked === 1 ||
      travel.transferHomeCompany?.trim() ||
      travel.transferHomeContact?.trim() ||
      travel.transferHomeCollectionTime?.trim() ||
      travel.transferHomePickupLocation?.trim() ||
      travel.transferHomePaymentStatus?.trim()
    );
  };

  // Helper function to check if helpfulInformation has any meaningful data
  const hasHelpfulInfoData = (info: typeof helpfulInformation): boolean => {
    if (!info) return false;
    return !!(
      info.localEmergency?.trim() ||
      info.nearestEmbassy?.trim() ||
      info.travelInsurance?.trim() ||
      info.airlineCustomerService?.trim() ||
      info.localMedicalClinic?.trim() ||
      info.transportContacts?.trim()
    );
  };

  // Helper function to generate FlightRadar24 tracking URL
  const getFlightTrackerUrl = (flightNumber: string): string => {
    const clean = flightNumber.replace(/\s/g, '').toLowerCase();
    return `https://www.flightradar24.com/data/flights/${clean}`;
  };

  // ✅ FIXED: Enhanced helper function with better null/array checking
  const hasAdditionalTravelData = (travel: any): boolean => {
    if (!travel || typeof travel !== "object") return false;

    // Check type-specific fields
    if (travel.travelType === "car") {
      return !!(
        travel.vehicleDetails?.trim() ||
        travel.vehicleRegistration?.trim() ||
        travel.carContactDetails?.trim() ||
        travel.carBookingDetails?.trim()
      );
    }

    if (travel.travelType === "flight") {
      return !!(
        travel.flightNumber?.trim() ||
        travel.flightDate?.trim() ||
        travel.flightDepartureAirport?.trim() ||
        travel.flightArrivalAirport?.trim() ||
        travel.flightDepartureTime?.trim() ||
        travel.flightArrivalTime?.trim() ||
        travel.flightPassengersSeats?.trim() ||
        travel.flightThingsToRemember?.trim()
      );
    }

    if (travel.travelType === "ferry") {
      return !!(
        travel.ferryDepartingFrom?.trim() ||
        travel.ferryDestination?.trim() ||
        travel.ferryDate?.trim() ||
        travel.ferryPrice?.trim() ||
        travel.ferryContactDetails?.trim() ||
        travel.ferryAdditionalNotes?.trim() ||
        travel.ferryBookingReference?.trim()
      );
    }

    if (travel.travelType === "train") {
      return !!(
        travel.trainDepartingFrom?.trim() ||
        travel.trainDestination?.trim() ||
        travel.trainDate?.trim() ||
        travel.trainPrice?.trim() ||
        travel.trainContactDetails?.trim() ||
        travel.trainAdditionalNotes?.trim() ||
        travel.trainBookingReference?.trim()
      );
    }

    return false;
  };

  // Sidebar component - used on every page
  const Sidebar = () => (
    <View style={styles.sidebar} fixed>
      <Image src={logoUrl} style={styles.sidebarLogo} />

      <Text style={styles.sidebarTripTitle}>{itinerary.title}</Text>

      <View style={styles.sidebarSpacer} />

      <View style={styles.sidebarAssistantSection}>
        <Text style={styles.sidebarAssistantHeading}>Your Assistant</Text>
        <Text style={styles.sidebarAssistantName}>
          {itinerary.assistantName || "BlckBx Team"}
        </Text>
        {itinerary.assistantEmail && (
          <Link
            src={`mailto:${itinerary.assistantEmail}`}
            style={styles.sidebarAssistantEmail}
          >
            {itinerary.assistantEmail}
          </Link>
        )}
      </View>

      <Text
        style={styles.sidebarPageNumber}
        render={({ pageNumber, totalPages }) =>
          `Page ${pageNumber} of ${totalPages}`
        }
        fixed
      />
    </View>
  );

  return (
    <Document
      title={`${itinerary.title} - Travel Itinerary`}
      subject={`Personalized travel itinerary for ${itinerary.title}`}
      author="BlckBx"
      keywords="travel, itinerary, vacation, holiday, planning"
      creator="BlckBx Travel Planning"
      producer="BlckBx"
    >
      {/* Cover / Overview Page */}
      <Page size="A4" style={styles.page}>
        <Sidebar />

        <View style={styles.mainContent}>
          {/* Travel Information Section */}
          {travelDetails && (
            <View>
              <Text style={styles.sectionTitle}>Travel Information</Text>
              <View style={styles.itemCard}>
                {travelDetails.dates && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Dates</Text>
                    <Text style={styles.itemValue}>{travelDetails.dates}</Text>
                  </View>
                )}
                {travelDetails.location && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Location</Text>
                    <Text style={styles.itemValue}>
                      {travelDetails.location}
                    </Text>
                  </View>
                )}
                {/* Weather - show if weather text exists OR if weatherUrl exists */}
                {(travelDetails.weather || travelDetails.weatherUrl) && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Weather</Text>
                    {travelDetails.weather && (
                      <Text style={styles.itemValue}>
                        {travelDetails.weather}
                      </Text>
                    )}
                    {travelDetails.weatherUrl && (
                      <Link
                        src={travelDetails.weatherUrl}
                        style={styles.itemLink}
                      >
                        View Detailed Forecast
                      </Link>
                    )}
                  </View>
                )}
              </View>
            </View>
          )}

          {/* Travellers Section - Dynamic sizing based on count */}
          {travellers.length > 0 && (() => {
            const count = travellers.length;
            const getFontSize = () => {
              if (count <= 4) return { name: 12, type: 10 };
              if (count <= 8) return { name: 11, type: 9 };
              if (count <= 12) return { name: 10, type: 8 };
              return { name: 9, type: 7 };
            };
            const getSpacing = () => {
              if (count <= 4) return { padding: 12, marginBottom: 12 };
              if (count <= 8) return { padding: 10, marginBottom: 10 };
              if (count <= 12) return { padding: 8, marginBottom: 8 };
              return { padding: 6, marginBottom: 6 };
            };
            const fontSize = getFontSize();
            const spacing = getSpacing();

            return (
              <View wrap={false}>
                <Text style={styles.sectionTitle}>Travellers</Text>
                <View style={{ flexDirection: count > 6 ? "row" : "column", flexWrap: "wrap" }}>
                  {travellers.map((traveller) => (
                    <View 
                      key={traveller.id} 
                      style={{
                        ...styles.travellerCard,
                        padding: spacing.padding,
                        marginBottom: spacing.marginBottom,
                        ...(count > 6 ? { width: "48%", marginRight: "2%" } : {}),
                      }}
                    >
                      <Text style={{
                        ...styles.travellerName,
                        fontSize: fontSize.name,
                        marginBottom: count > 8 ? 2 : 4,
                      }}>
                        {traveller.name}
                      </Text>
                      <Text style={{
                        ...styles.travellerType,
                        fontSize: fontSize.type,
                      }}>
                        {traveller.type === "adult" ? "Adult" : "Child"}
                        {traveller.ageAtTravel
                          ? ` (Age: ${traveller.ageAtTravel})`
                          : ""}
                      </Text>
                    </View>
                  ))}
                </View>
              </View>
            );
          })()}
        </View>
      </Page>

      {/* Outbound Travel */}
      {outboundTravel && itinerary.outboundTravelVisible !== 0 ? (
        <Page size="A4" style={styles.page}>
          <Sidebar />

          <View style={styles.mainContent}>
            <Text style={styles.sectionTitle}>Outbound Travel</Text>

            {/* Transfer to Airport - Always show, compact when empty */}
            <View 
              style={outboundTravel.transferToAirportTaxiBooked === 1 || (outboundTravel.transferToAirportTaxis && (outboundTravel.transferToAirportTaxis as any[]).length > 0) || (outboundTravel.transferToAirportTrains && (outboundTravel.transferToAirportTrains as any[]).length > 0)
                ? styles.transferSectionFull 
                : styles.transferSectionCompact
              } 
              wrap={false}
            >
              <Text style={styles.transferLabel}>Transfer to Airport</Text>
              {/* Multiple Taxis */}
              {outboundTravel.transferToAirportTaxis && (outboundTravel.transferToAirportTaxis as any[]).length > 0 ? (
                <>
                  {(outboundTravel.transferToAirportTaxis as any[]).map((taxi: any, index: number) => (
                    <View key={taxi.id || index} style={{ marginBottom: 8, paddingLeft: 8, borderLeft: '1 solid #E8E5E0' }}>
                      <Text style={styles.transferText}>Taxi {index + 1}</Text>
                      {taxi.company && <Text style={styles.transferText}>Company: {taxi.company}</Text>}
                      {taxi.contact && <Text style={styles.transferText}>Contact: {taxi.contact}</Text>}
                      {taxi.collectionTime && <Text style={styles.transferText}>Collection: {taxi.collectionTime}</Text>}
                      {taxi.pickupLocation && <Text style={styles.transferText}>Pickup: {taxi.pickupLocation}</Text>}
                      {taxi.paymentStatus && <Text style={styles.transferText}>Payment: {taxi.paymentStatus}</Text>}
                    </View>
                  ))}
                </>
              ) : outboundTravel.transferToAirportTrains && (outboundTravel.transferToAirportTrains as any[]).length > 0 ? (
                <>
                  {(outboundTravel.transferToAirportTrains as any[]).map((train: any, index: number) => (
                    <View key={train.id || index} style={{ marginBottom: 8, paddingLeft: 8, borderLeft: '1 solid #E8E5E0' }}>
                      <Text style={styles.transferText}>Train {index + 1}</Text>
                      {train.departingStation && <Text style={styles.transferText}>From: {train.departingStation}</Text>}
                      {train.arrivalStation && <Text style={styles.transferText}>To: {train.arrivalStation}</Text>}
                      {train.departureTime && <Text style={styles.transferText}>Departure: {train.departureTime}</Text>}
                      {train.provider && <Text style={styles.transferText}>Provider: {train.provider}</Text>}
                      {train.bookingRef && <Text style={styles.transferText}>Booking: {train.bookingRef}</Text>}
                      {train.paymentStatus && <Text style={styles.transferText}>Payment: {train.paymentStatus}</Text>}
                    </View>
                  ))}
                </>
              ) : outboundTravel.transferToAirportTaxiBooked === 1 ? (
                <>
                  {outboundTravel.transferToAirportCompany && (
                    <Text style={styles.transferText}>
                      Company: {outboundTravel.transferToAirportCompany}
                    </Text>
                  )}
                  {outboundTravel.transferToAirportContact && (
                    <Text style={styles.transferText}>
                      Contact: {outboundTravel.transferToAirportContact}
                    </Text>
                  )}
                  {outboundTravel.transferToAirportCollectionTime && (
                    <Text style={styles.transferText}>
                      Collection: {outboundTravel.transferToAirportCollectionTime}
                    </Text>
                  )}
                  {outboundTravel.transferToAirportPickupLocation && (
                    <Text style={styles.transferText}>
                      Pickup: {outboundTravel.transferToAirportPickupLocation}
                    </Text>
                  )}
                  {outboundTravel.transferToAirportPaymentStatus && (
                    <Text style={styles.transferText}>
                      Payment: {outboundTravel.transferToAirportPaymentStatus}
                    </Text>
                  )}
                </>
              ) : (
                <Text style={styles.transferTextEmpty}>—</Text>
              )}
            </View>

            {/* Flight */}
            {outboundTravel.flightNumber && (
              <FlightCardPDF
                flightNumber={outboundTravel.flightNumber}
                date={outboundTravel.flightDate}
                departureAirport={outboundTravel.departureAirport}
                departureTime={outboundTravel.departureTime}
                arrivalAirport={outboundTravel.arrivalAirport}
                arrivalTime={outboundTravel.arrivalTime}
                passengers={outboundTravel.passengersSeats}
                notes={outboundTravel.thingsToRemember}
                getFlightTrackerUrl={getFlightTrackerUrl}
              />
            )}

            {/* Transfer to Accommodation - Always show, compact when empty */}
            <View 
              style={outboundTravel.transferToAccomTaxiBooked === 1 || (outboundTravel.transferToAccomTaxis && (outboundTravel.transferToAccomTaxis as any[]).length > 0) || (outboundTravel.transferToAccomTrains && (outboundTravel.transferToAccomTrains as any[]).length > 0)
                ? styles.transferSectionFull 
                : styles.transferSectionCompact
              } 
              wrap={false}
            >
              <Text style={styles.transferLabel}>Transfer to Accommodation</Text>
              {/* Multiple Taxis */}
              {outboundTravel.transferToAccomTaxis && (outboundTravel.transferToAccomTaxis as any[]).length > 0 ? (
                <>
                  {(outboundTravel.transferToAccomTaxis as any[]).map((taxi: any, index: number) => (
                    <View key={taxi.id || index} style={{ marginBottom: 8, paddingLeft: 8, borderLeft: '1 solid #E8E5E0' }}>
                      <Text style={styles.transferText}>Taxi {index + 1}</Text>
                      {taxi.company && <Text style={styles.transferText}>Company: {taxi.company}</Text>}
                      {taxi.contact && <Text style={styles.transferText}>Contact: {taxi.contact}</Text>}
                      {taxi.collectionTime && <Text style={styles.transferText}>Collection: {taxi.collectionTime}</Text>}
                      {taxi.pickupLocation && <Text style={styles.transferText}>Pickup: {taxi.pickupLocation}</Text>}
                      {taxi.paymentStatus && <Text style={styles.transferText}>Payment: {taxi.paymentStatus}</Text>}
                    </View>
                  ))}
                </>
              ) : outboundTravel.transferToAccomTrains && (outboundTravel.transferToAccomTrains as any[]).length > 0 ? (
                <>
                  {(outboundTravel.transferToAccomTrains as any[]).map((train: any, index: number) => (
                    <View key={train.id || index} style={{ marginBottom: 8, paddingLeft: 8, borderLeft: '1 solid #E8E5E0' }}>
                      <Text style={styles.transferText}>Train {index + 1}</Text>
                      {train.departingStation && <Text style={styles.transferText}>From: {train.departingStation}</Text>}
                      {train.arrivalStation && <Text style={styles.transferText}>To: {train.arrivalStation}</Text>}
                      {train.departureTime && <Text style={styles.transferText}>Departure: {train.departureTime}</Text>}
                      {train.provider && <Text style={styles.transferText}>Provider: {train.provider}</Text>}
                      {train.bookingRef && <Text style={styles.transferText}>Booking: {train.bookingRef}</Text>}
                      {train.paymentStatus && <Text style={styles.transferText}>Payment: {train.paymentStatus}</Text>}
                    </View>
                  ))}
                </>
              ) : outboundTravel.transferToAccomTaxiBooked === 1 ? (
                <>
                  {outboundTravel.transferToAccomCompany && (
                    <Text style={styles.transferText}>
                      Company: {outboundTravel.transferToAccomCompany}
                    </Text>
                  )}
                  {outboundTravel.transferToAccomContact && (
                    <Text style={styles.transferText}>
                      Contact: {outboundTravel.transferToAccomContact}
                    </Text>
                  )}
                  {outboundTravel.transferToAccomCollectionTime && (
                    <Text style={styles.transferText}>
                      Collection: {outboundTravel.transferToAccomCollectionTime}
                    </Text>
                  )}
                  {outboundTravel.transferToAccomPickupLocation && (
                    <Text style={styles.transferText}>
                      Pickup: {outboundTravel.transferToAccomPickupLocation}
                    </Text>
                  )}
                  {outboundTravel.transferToAccomPaymentStatus && (
                    <Text style={styles.transferText}>
                      Payment: {outboundTravel.transferToAccomPaymentStatus}
                    </Text>
                  )}
                </>
              ) : (
                <Text style={styles.transferTextEmpty}>—</Text>
              )}
            </View>
          </View>
        </Page>
      ) : null}

      {/* Accommodations */}
      {accommodations.length > 0 ? (
        <Page size="A4" style={styles.page}>
          <Sidebar />

          <View style={styles.mainContent}>
            <Text style={styles.sectionTitle}>Accommodation</Text>

            {accommodations.map((accommodation, index) => (
              <View key={accommodation.id} style={index === 0 ? styles.firstItemCard : styles.itemCard} wrap={false}>
                <Text style={styles.itemHeading}>{accommodation.name}</Text>

                {accommodation.address && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Address</Text>
                    <Text style={styles.itemValue}>
                      {accommodation.address}
                    </Text>
                  </View>
                )}

                {accommodation.checkInDetails && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Check-in Details</Text>
                    <Text style={styles.itemValue}>
                      {accommodation.checkInDetails}
                    </Text>
                  </View>
                )}

                {accommodation.bookingReference && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Booking Reference</Text>
                    <Text style={styles.itemValue}>
                      {accommodation.bookingReference}
                    </Text>
                  </View>
                )}

                {accommodation.contactInfo && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Contact Info</Text>
                    <Text style={styles.itemValue}>
                      {accommodation.contactInfo}
                    </Text>
                  </View>
                )}

                {/* Links stacked vertically */}
                {(accommodation.googleMapsLink || accommodation.websiteUrl) && (
                  <View style={styles.linksContainer}>
                    {accommodation.googleMapsLink && (
                      <View style={styles.linkRow}>
                        <Link
                          src={accommodation.googleMapsLink}
                          style={styles.itemLink}
                        >
                          View on Google Maps
                        </Link>
                      </View>
                    )}
                    {accommodation.websiteUrl && (
                      <View style={styles.linkRow}>
                        <Link src={accommodation.websiteUrl} style={styles.itemLink}>
                          View Website
                        </Link>
                      </View>
                    )}
                  </View>
                )}

                {accommodation.notes && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Notes</Text>
                    <Text style={styles.itemValue}>{accommodation.notes}</Text>
                  </View>
                )}

                {/* Display images */}
                {accommodation.images &&
                  accommodation.images.length > 0 &&
                  accommodation.images.map((imageUrl, idx) => (
                    <View key={idx}>
                      <Image src={imageUrl} style={styles.itemImage} />
                    </View>
                  ))}
              </View>
            ))}
          </View>
        </Page>
      ) : null}

      {/* Activities */}
      {activities.length > 0 ? (
        <Page size="A4" style={styles.page}>
          <Sidebar />

          <View style={styles.mainContent}>
            <Text style={styles.sectionTitle}>Activities & Experiences</Text>

            {activities.map((activity, index) => (
              <View key={activity.id} style={index === 0 ? styles.firstItemCard : styles.itemCard} wrap={false}>
                <Text style={styles.itemHeading}>{activity.name}</Text>

                {activity.description && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Description</Text>
                    <Text style={styles.itemValue}>{activity.description}</Text>
                  </View>
                )}

                {activity.price && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Price</Text>
                    <Text style={styles.itemValue}>{activity.price}</Text>
                  </View>
                )}

                {activity.contactDetails && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Contact</Text>
                    <Text style={styles.itemValue}>
                      {activity.contactDetails}
                    </Text>
                  </View>
                )}

                {activity.address && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Address</Text>
                    <Text style={styles.itemValue}>{activity.address}</Text>
                  </View>
                )}

                {/* Links stacked vertically */}
                {(activity.googleMapsLink || activity.websiteUrl) && (
                  <View style={styles.linksContainer}>
                    {activity.googleMapsLink && (
                      <View style={styles.linkRow}>
                        <Link src={activity.googleMapsLink} style={styles.itemLink}>
                          View on Google Maps
                        </Link>
                      </View>
                    )}
                    {activity.websiteUrl && (
                      <View style={styles.linkRow}>
                        <Link src={activity.websiteUrl} style={styles.itemLink}>
                          View Website
                        </Link>
                      </View>
                    )}
                  </View>
                )}

                {activity.notes && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Notes</Text>
                    <Text style={styles.itemValue}>{activity.notes}</Text>
                  </View>
                )}

                {/* Display images */}
                {activity.images &&
                  activity.images.length > 0 &&
                  activity.images.map((imageUrl, idx) => (
                    <View key={idx}>
                      <Image src={imageUrl} style={styles.itemImage} />
                    </View>
                  ))}
              </View>
            ))}
          </View>
        </Page>
      ) : null}

      {/* Dining */}
      {dining.length > 0 ? (
        <Page size="A4" style={styles.page}>
          <Sidebar />

          <View style={styles.mainContent}>
            <Text style={styles.sectionTitle}>Dining Recommendations</Text>

            {dining.map((restaurant, index) => (
              <View key={restaurant.id} style={index === 0 ? styles.firstItemCard : styles.itemCard} wrap={false}>
                <Text style={styles.itemHeading}>{restaurant.name}</Text>

                {restaurant.description && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Description</Text>
                    <Text style={styles.itemValue}>{restaurant.description}</Text>
                  </View>
                )}

                {restaurant.cuisineType && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Cuisine</Text>
                    <Text style={styles.itemValue}>
                      {restaurant.cuisineType}
                    </Text>
                  </View>
                )}

                {restaurant.priceRange && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Price Range</Text>
                    <Text style={styles.itemValue}>
                      {restaurant.priceRange}
                    </Text>
                  </View>
                )}

                {restaurant.contactDetails && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Contact</Text>
                    <Text style={styles.itemValue}>
                      {restaurant.contactDetails}
                    </Text>
                  </View>
                )}

                {restaurant.address && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Address</Text>
                    <Text style={styles.itemValue}>{restaurant.address}</Text>
                  </View>
                )}

                {/* Links stacked vertically */}
                {(restaurant.googleMapsLink || restaurant.websiteUrl) && (
                  <View style={styles.linksContainer}>
                    {restaurant.googleMapsLink && (
                      <View style={styles.linkRow}>
                        <Link src={restaurant.googleMapsLink} style={styles.itemLink}>
                          View on Google Maps
                        </Link>
                      </View>
                    )}
                    {restaurant.websiteUrl && (
                      <View style={styles.linkRow}>
                        <Link src={restaurant.websiteUrl} style={styles.itemLink}>
                          View Website
                        </Link>
                      </View>
                    )}
                  </View>
                )}

                {restaurant.notes && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Notes</Text>
                    <Text style={styles.itemValue}>{restaurant.notes}</Text>
                  </View>
                )}

                {/* Display images */}
                {restaurant.images &&
                  restaurant.images.length > 0 &&
                  restaurant.images.map((imageUrl, idx) => (
                    <View key={idx}>
                      <Image src={imageUrl} style={styles.itemImage} />
                    </View>
                  ))}
              </View>
            ))}
          </View>
        </Page>
      ) : null}

      {/* Bars and Pubs */}
      {bars.length > 0 ? (
        <Page size="A4" style={styles.page}>
          <Sidebar />

          <View style={styles.mainContent}>
            <Text style={styles.sectionTitle}>Bars and Pubs</Text>

            {bars.map((bar, index) => (
              <View key={bar.id} style={index === 0 ? styles.firstItemCard : styles.itemCard} wrap={false}>
                <Text style={styles.itemHeading}>{bar.name}</Text>

                {bar.description && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Description</Text>
                    <Text style={styles.itemValue}>{bar.description}</Text>
                  </View>
                )}

                {bar.barType && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Bar Type</Text>
                    <Text style={styles.itemValue}>
                      {bar.barType}
                    </Text>
                  </View>
                )}

                {bar.priceRange && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Price Range</Text>
                    <Text style={styles.itemValue}>
                      {bar.priceRange}
                    </Text>
                  </View>
                )}

                {bar.contactDetails && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Contact</Text>
                    <Text style={styles.itemValue}>
                      {bar.contactDetails}
                    </Text>
                  </View>
                )}

                {bar.address && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Address</Text>
                    <Text style={styles.itemValue}>{bar.address}</Text>
                  </View>
                )}

                {/* Links stacked vertically */}
                {(bar.googleMapsLink || bar.websiteUrl) && (
                  <View style={styles.linksContainer}>
                    {bar.googleMapsLink && (
                      <View style={styles.linkRow}>
                        <Link src={bar.googleMapsLink} style={styles.itemLink}>
                          View on Google Maps
                        </Link>
                      </View>
                    )}
                    {bar.websiteUrl && (
                      <View style={styles.linkRow}>
                        <Link src={bar.websiteUrl} style={styles.itemLink}>
                          View Website
                        </Link>
                      </View>
                    )}
                  </View>
                )}

                {bar.notes && (
                  <View style={styles.fieldGroup}>
                    <Text style={styles.itemLabel}>Notes</Text>
                    <Text style={styles.itemValue}>{bar.notes}</Text>
                  </View>
                )}

                {/* Display images */}
                {bar.images &&
                  bar.images.length > 0 &&
                  bar.images.map((imageUrl, idx) => (
                    <View key={idx}>
                      <Image src={imageUrl} style={styles.itemImage} />
                    </View>
                  ))}
              </View>
            ))}
          </View>
        </Page>
      ) : null}

      {/* Additional Travel - Enhanced with FlightCardPDF for flights */}
      {(() => {
        // Ensure additionalTravel is an array and filter for meaningful items
        const meaningfulTravelItems =
          additionalTravel && Array.isArray(additionalTravel)
            ? additionalTravel
                .filter(item => item?.travelType && item.travelType.trim() !== '' && hasAdditionalTravelData(item))
                .sort((a, b) => (a.displayOrder || 0) - (b.displayOrder || 0))
            : [];

        // Only render the page if there are meaningful items
        if (meaningfulTravelItems.length === 0) {
          return null;
        }

        return (
          <Page size="A4" style={styles.page}>
            <Sidebar />

            <View style={styles.mainContent}>
              <Text style={styles.sectionTitle}>Additional Travel</Text>

              {meaningfulTravelItems.map((travel, index) => (
                <View key={travel.id}>
                  {/* Use FlightCardPDF for flight type - includes multi-leg support */}
                  {travel.travelType === "flight" && travel.flightNumber ? (
                    <FlightCardPDF
                      flightNumber={travel.flightNumber}
                      date={travel.flightDate}
                      departureAirport={travel.flightDepartureAirport}
                      departureTime={travel.flightDepartureTime}
                      arrivalAirport={travel.flightArrivalAirport}
                      arrivalTime={travel.flightArrivalTime}
                      passengers={travel.flightPassengersSeats}
                      notes={travel.flightThingsToRemember}
                      isMultiLeg={travel.flightIsMultiLeg === 1}
                      legs={travel.flightLegs || []}
                      getFlightTrackerUrl={getFlightTrackerUrl}
                    />
                  ) : (
                    <View style={index === 0 ? styles.firstItemCard : styles.itemCard} wrap={false}>
                      <Text style={styles.itemHeading}>
                        {travel.travelType 
                          ? travel.travelType.charAt(0).toUpperCase() + travel.travelType.slice(1) 
                          : ''}
                      </Text>

                      {/* Car fields */}
                      {travel.travelType === "car" && (
                        <>
                          {travel.vehicleDetails && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Vehicle</Text>
                              <Text style={styles.itemValue}>
                                {travel.vehicleDetails}
                              </Text>
                            </View>
                          )}
                          {travel.vehicleRegistration && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Registration</Text>
                              <Text style={styles.itemValue}>
                                {travel.vehicleRegistration}
                              </Text>
                            </View>
                          )}
                          {travel.carContactDetails && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Contact</Text>
                              <Text style={styles.itemValue}>
                                {travel.carContactDetails}
                              </Text>
                            </View>
                          )}
                          {travel.carBookingDetails && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Booking Details</Text>
                              <Text style={styles.itemValue}>
                                {travel.carBookingDetails}
                              </Text>
                            </View>
                          )}
                        </>
                      )}

                      {/* Ferry fields */}
                      {travel.travelType === "ferry" && (
                        <>
                          {travel.ferryDepartingFrom && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>From</Text>
                              <Text style={styles.itemValue}>
                                {travel.ferryDepartingFrom}
                              </Text>
                            </View>
                          )}
                          {travel.ferryDestination && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>To</Text>
                              <Text style={styles.itemValue}>
                                {travel.ferryDestination}
                              </Text>
                            </View>
                          )}
                          {travel.ferryDate && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Date</Text>
                              <Text style={styles.itemValue}>
                                {travel.ferryDate}
                              </Text>
                            </View>
                          )}
                          {travel.ferryPrice && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Price</Text>
                              <Text style={styles.itemValue}>
                                {travel.ferryPrice}
                              </Text>
                            </View>
                          )}
                          {travel.ferryContactDetails && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Contact</Text>
                              <Text style={styles.itemValue}>
                                {travel.ferryContactDetails}
                              </Text>
                            </View>
                          )}
                          {travel.ferryBookingReference && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Booking Ref</Text>
                              <Text style={styles.itemValue}>
                                {travel.ferryBookingReference}
                              </Text>
                            </View>
                          )}
                          {travel.ferryAdditionalNotes && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Additional Notes</Text>
                              <Text style={styles.itemValue}>
                                {travel.ferryAdditionalNotes}
                              </Text>
                            </View>
                          )}
                        </>
                      )}

                      {/* Train fields */}
                      {travel.travelType === "train" && (
                        <>
                          {travel.trainDepartingFrom && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>From</Text>
                              <Text style={styles.itemValue}>
                                {travel.trainDepartingFrom}
                              </Text>
                            </View>
                          )}
                          {travel.trainDestination && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>To</Text>
                              <Text style={styles.itemValue}>
                                {travel.trainDestination}
                              </Text>
                            </View>
                          )}
                          {travel.trainDate && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Date</Text>
                              <Text style={styles.itemValue}>
                                {travel.trainDate}
                              </Text>
                            </View>
                          )}
                          {travel.trainPrice && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Price</Text>
                              <Text style={styles.itemValue}>
                                {travel.trainPrice}
                              </Text>
                            </View>
                          )}
                          {travel.trainContactDetails && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Contact</Text>
                              <Text style={styles.itemValue}>
                                {travel.trainContactDetails}
                              </Text>
                            </View>
                          )}
                          {travel.trainBookingReference && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Booking Ref</Text>
                              <Text style={styles.itemValue}>
                                {travel.trainBookingReference}
                              </Text>
                            </View>
                          )}
                          {travel.trainAdditionalNotes && (
                            <View style={styles.fieldGroup}>
                              <Text style={styles.itemLabel}>Additional Notes</Text>
                              <Text style={styles.itemValue}>
                                {travel.trainAdditionalNotes}
                              </Text>
                            </View>
                          )}
                        </>
                      )}
                    </View>
                  )}
                </View>
              ))}
            </View>
          </Page>
        );
      })()}

      {/* Return Travel */}
      {returnTravel && hasReturnTravelData(returnTravel) && itinerary.returnTravelVisible !== 0 ? (
        <Page size="A4" style={styles.page}>
          <Sidebar />

          <View style={styles.mainContent}>
            <Text style={styles.sectionTitle}>Return Travel</Text>

            {/* Return Flight */}
            {returnTravel.flightNumber && (
              <FlightCardPDF
                flightNumber={returnTravel.flightNumber}
                date={returnTravel.flightDate}
                departureAirport={returnTravel.departureAirport}
                departureTime={returnTravel.departureTime}
                arrivalAirport={returnTravel.arrivalAirport}
                arrivalTime={returnTravel.arrivalTime}
                passengers={returnTravel.passengersSeats}
                notes={returnTravel.thingsToRemember}
                getFlightTrackerUrl={getFlightTrackerUrl}
              />
            )}

            {/* Transfer to Airport - Always show, compact when empty */}
            <View 
              style={returnTravel.transferToAirportTaxiBooked === 1 || (returnTravel.transferToAirportTaxis && (returnTravel.transferToAirportTaxis as any[]).length > 0) || (returnTravel.transferToAirportTrains && (returnTravel.transferToAirportTrains as any[]).length > 0)
                ? styles.transferSectionFull 
                : styles.transferSectionCompact
              } 
              wrap={false}
            >
              <Text style={styles.transferLabel}>Transfer to Airport</Text>
              {/* Multiple Taxis */}
              {returnTravel.transferToAirportTaxis && (returnTravel.transferToAirportTaxis as any[]).length > 0 ? (
                <>
                  {(returnTravel.transferToAirportTaxis as any[]).map((taxi: any, index: number) => (
                    <View key={taxi.id || index} style={{ marginBottom: 8, paddingLeft: 8, borderLeft: '1 solid #E8E5E0' }}>
                      <Text style={styles.transferText}>Taxi {index + 1}</Text>
                      {taxi.company && <Text style={styles.transferText}>Company: {taxi.company}</Text>}
                      {taxi.contact && <Text style={styles.transferText}>Contact: {taxi.contact}</Text>}
                      {taxi.collectionTime && <Text style={styles.transferText}>Collection: {taxi.collectionTime}</Text>}
                      {taxi.pickupLocation && <Text style={styles.transferText}>Pickup: {taxi.pickupLocation}</Text>}
                      {taxi.paymentStatus && <Text style={styles.transferText}>Payment: {taxi.paymentStatus}</Text>}
                    </View>
                  ))}
                </>
              ) : returnTravel.transferToAirportTrains && (returnTravel.transferToAirportTrains as any[]).length > 0 ? (
                <>
                  {(returnTravel.transferToAirportTrains as any[]).map((train: any, index: number) => (
                    <View key={train.id || index} style={{ marginBottom: 8, paddingLeft: 8, borderLeft: '1 solid #E8E5E0' }}>
                      <Text style={styles.transferText}>Train {index + 1}</Text>
                      {train.departingStation && <Text style={styles.transferText}>From: {train.departingStation}</Text>}
                      {train.arrivalStation && <Text style={styles.transferText}>To: {train.arrivalStation}</Text>}
                      {train.departureTime && <Text style={styles.transferText}>Departure: {train.departureTime}</Text>}
                      {train.provider && <Text style={styles.transferText}>Provider: {train.provider}</Text>}
                      {train.bookingRef && <Text style={styles.transferText}>Booking: {train.bookingRef}</Text>}
                      {train.paymentStatus && <Text style={styles.transferText}>Payment: {train.paymentStatus}</Text>}
                    </View>
                  ))}
                </>
              ) : returnTravel.transferToAirportTaxiBooked === 1 ? (
                <>
                  {returnTravel.transferToAirportCompany && (
                    <Text style={styles.transferText}>
                      Company: {returnTravel.transferToAirportCompany}
                    </Text>
                  )}
                  {returnTravel.transferToAirportContact && (
                    <Text style={styles.transferText}>
                      Contact: {returnTravel.transferToAirportContact}
                    </Text>
                  )}
                  {returnTravel.transferToAirportCollectionTime && (
                    <Text style={styles.transferText}>
                      Collection: {returnTravel.transferToAirportCollectionTime}
                    </Text>
                  )}
                  {returnTravel.transferToAirportPickupLocation && (
                    <Text style={styles.transferText}>
                      Pickup: {returnTravel.transferToAirportPickupLocation}
                    </Text>
                  )}
                  {returnTravel.transferToAirportPaymentStatus && (
                    <Text style={styles.transferText}>
                      Payment: {returnTravel.transferToAirportPaymentStatus}
                    </Text>
                  )}
                </>
              ) : (
                <Text style={styles.transferTextEmpty}>—</Text>
              )}
            </View>

            {/* Transfer Home - Always show, compact when empty */}
            <View 
              style={returnTravel.transferHomeTaxiBooked === 1 || (returnTravel.transferHomeTaxis && (returnTravel.transferHomeTaxis as any[]).length > 0) || (returnTravel.transferHomeTrains && (returnTravel.transferHomeTrains as any[]).length > 0)
                ? styles.transferSectionFull 
                : styles.transferSectionCompact
              } 
              wrap={false}
            >
              <Text style={styles.transferLabel}>Transfer Home</Text>
              {/* Multiple Taxis */}
              {returnTravel.transferHomeTaxis && (returnTravel.transferHomeTaxis as any[]).length > 0 ? (
                <>
                  {(returnTravel.transferHomeTaxis as any[]).map((taxi: any, index: number) => (
                    <View key={taxi.id || index} style={{ marginBottom: 8, paddingLeft: 8, borderLeft: '1 solid #E8E5E0' }}>
                      <Text style={styles.transferText}>Taxi {index + 1}</Text>
                      {taxi.company && <Text style={styles.transferText}>Company: {taxi.company}</Text>}
                      {taxi.contact && <Text style={styles.transferText}>Contact: {taxi.contact}</Text>}
                      {taxi.collectionTime && <Text style={styles.transferText}>Collection: {taxi.collectionTime}</Text>}
                      {taxi.pickupLocation && <Text style={styles.transferText}>Pickup: {taxi.pickupLocation}</Text>}
                      {taxi.paymentStatus && <Text style={styles.transferText}>Payment: {taxi.paymentStatus}</Text>}
                    </View>
                  ))}
                </>
              ) : returnTravel.transferHomeTrains && (returnTravel.transferHomeTrains as any[]).length > 0 ? (
                <>
                  {(returnTravel.transferHomeTrains as any[]).map((train: any, index: number) => (
                    <View key={train.id || index} style={{ marginBottom: 8, paddingLeft: 8, borderLeft: '1 solid #E8E5E0' }}>
                      <Text style={styles.transferText}>Train {index + 1}</Text>
                      {train.departingStation && <Text style={styles.transferText}>From: {train.departingStation}</Text>}
                      {train.arrivalStation && <Text style={styles.transferText}>To: {train.arrivalStation}</Text>}
                      {train.departureTime && <Text style={styles.transferText}>Departure: {train.departureTime}</Text>}
                      {train.provider && <Text style={styles.transferText}>Provider: {train.provider}</Text>}
                      {train.bookingRef && <Text style={styles.transferText}>Booking: {train.bookingRef}</Text>}
                      {train.paymentStatus && <Text style={styles.transferText}>Payment: {train.paymentStatus}</Text>}
                    </View>
                  ))}
                </>
              ) : returnTravel.transferHomeTaxiBooked === 1 ? (
                <>
                  {returnTravel.transferHomeCompany && (
                    <Text style={styles.transferText}>
                      Company: {returnTravel.transferHomeCompany}
                    </Text>
                  )}
                  {returnTravel.transferHomeContact && (
                    <Text style={styles.transferText}>
                      Contact: {returnTravel.transferHomeContact}
                    </Text>
                  )}
                  {returnTravel.transferHomeCollectionTime && (
                    <Text style={styles.transferText}>
                      Collection: {returnTravel.transferHomeCollectionTime}
                    </Text>
                  )}
                  {returnTravel.transferHomePickupLocation && (
                    <Text style={styles.transferText}>
                      Pickup: {returnTravel.transferHomePickupLocation}
                    </Text>
                  )}
                  {returnTravel.transferHomePaymentStatus && (
                    <Text style={styles.transferText}>
                      Payment: {returnTravel.transferHomePaymentStatus}
                    </Text>
                  )}
                </>
              ) : (
                <Text style={styles.transferTextEmpty}>—</Text>
              )}
            </View>
          </View>
        </Page>
      ) : null}

      {/* Helpful Information */}
      {helpfulInformation && hasHelpfulInfoData(helpfulInformation) && itinerary.helpfulInfoVisible !== 0 ? (
        <Page size="A4" style={styles.page}>
          <Sidebar />

          <View style={styles.mainContent}>
            <Text style={styles.sectionTitle}>Helpful Information</Text>

            <View style={styles.itemCard}>
              {helpfulInformation.localEmergency && (
                <View style={styles.fieldGroup}>
                  <Text style={styles.itemLabel}>Local Emergency Services</Text>
                  <Text style={styles.itemValue}>
                    {helpfulInformation.localEmergency}
                  </Text>
                </View>
              )}

              {helpfulInformation.nearestEmbassy && (
                <View style={styles.fieldGroup}>
                  <Text style={styles.itemLabel}>Nearest Embassy</Text>
                  <Text style={styles.itemValue}>
                    {helpfulInformation.nearestEmbassy}
                  </Text>
                </View>
              )}

              {helpfulInformation.travelInsurance && (
                <View style={styles.fieldGroup}>
                  <Text style={styles.itemLabel}>Travel Insurance</Text>
                  <Text style={styles.itemValue}>
                    {helpfulInformation.travelInsurance}
                  </Text>
                </View>
              )}

              {helpfulInformation.airlineCustomerService && (
                <View style={styles.fieldGroup}>
                  <Text style={styles.itemLabel}>Airline Customer Service</Text>
                  <Text style={styles.itemValue}>
                    {helpfulInformation.airlineCustomerService}
                  </Text>
                </View>
              )}

              {helpfulInformation.localMedicalClinic && (
                <View style={styles.fieldGroup}>
                  <Text style={styles.itemLabel}>Local Medical Clinic</Text>
                  <Text style={styles.itemValue}>
                    {helpfulInformation.localMedicalClinic}
                  </Text>
                </View>
              )}

              {helpfulInformation.transportContacts && (
                <View style={styles.fieldGroup}>
                  <Text style={styles.itemLabel}>Transport Contacts</Text>
                  <Text style={styles.itemValue}>
                    {helpfulInformation.transportContacts}
                  </Text>
                </View>
              )}
            </View>
          </View>
        </Page>
      ) : null}
    </Document>
  );
}