import { Link } from "wouter";
import logoUrl from "@assets/blckbx-logo.png";

export function Header() {
  return (
    <header className="border-b border-border bg-card">
      <div className="max-w-7xl mx-auto px-4 md:px-6 py-4">
        <Link href="/">
          <div className="flex items-center gap-3 cursor-pointer hover-elevate active-elevate-2 rounded-md p-2 -ml-2 w-fit transition-all" data-testid="link-home">
            <img 
              src={logoUrl} 
              alt="BlckBx" 
              className="h-12 w-auto"
              data-testid="img-logo"
            />
            <div className="flex flex-col">
              <span className="text-xs text-muted-foreground">www.blckbx.co.uk</span>
            </div>
          </div>
        </Link>
      </div>
    </header>
  );
}
