import { ExternalLink, Plane, Calendar, Users, AlertCircle, ArrowRightLeft } from "lucide-react";
import { Button } from "@/components/ui/button";

interface FlightLeg {
  departureAirport: string;
  departureTime: string;
  arrivalAirport: string;
  arrivalTime: string;
  flightNumber?: string;
  layoverDuration?: string;
}

interface FlightCardProps {
  flightNumber: string;
  date: string;
  departureAirport: string;
  departureTime: string;
  arrivalAirport: string;
  arrivalTime: string;
  passengers?: string;
  notes?: string;
  duration?: string;
  isMultiLeg?: boolean;
  legs?: FlightLeg[];
}

export function FlightCard({
  flightNumber,
  date,
  departureAirport,
  departureTime,
  arrivalAirport,
  arrivalTime,
  passengers,
  notes,
  duration,
  isMultiLeg = false,
  legs = []
}: FlightCardProps) {
  const cleanFlightNumber = flightNumber.replace(/\s/g, '').toUpperCase();
  const flightTrackerUrl = `https://www.flightradar24.com/data/flights/${cleanFlightNumber.toLowerCase()}`;

  const getAirportCode = (airport: string) => {
    if (!airport) return '---';
    if (/^[A-Z]{3}$/i.test(airport.trim())) return airport.trim().toUpperCase();
    return airport.substring(0, 3).toUpperCase();
  };

  const depCode = getAirportCode(departureAirport);
  const arrCode = getAirportCode(arrivalAirport);

  return (
    <div className="flight-card bg-card rounded-xl shadow-lg overflow-hidden my-4" data-testid="flight-card">
      {/* Header - Base Black #1C1D1F with Direct/Stops badge */}
      <div className="flight-card-header bg-[#1C1D1F] text-white px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <Plane className="w-6 h-6" />
          <span className="font-bold text-lg">{cleanFlightNumber}</span>
        </div>
        {isMultiLeg && legs.length > 0 ? (
          <div className="flex items-center gap-2 bg-[#3a3b3d] px-3 py-1 rounded-full text-sm">
            <span>{legs.length} stops</span>
          </div>
        ) : (
          <div className="flex items-center gap-2 bg-[#3a3b3d] px-3 py-1 rounded-full text-sm">
            <span>Direct</span>
          </div>
        )}
      </div>
      {/* Single Leg Flight */}
      {!isMultiLeg && (
        <div className="flight-route px-6 py-6 bg-[#F5F3F0]">
          <div className="flex items-center justify-between">
            <div className="text-center flex-1">
              <div className="text-3xl font-bold text-foreground">{depCode}</div>
              <div className="text-xl font-semibold text-foreground mt-1">{departureTime}</div>
              <div className="text-sm text-muted-foreground mt-1 max-w-[120px] mx-auto truncate">{departureAirport}</div>
            </div>

            <div className="flex-1 flex flex-col items-center px-4">
              <div className="text-xs text-muted-foreground mb-2">{duration || 'Direct'}</div>
              <div className="w-full flex items-center">
                <div className="w-3 h-3 rounded-full bg-[#1C1D1F] dark:bg-white"></div>
                <div className="flex-1 h-0.5 bg-[#1C1D1F] dark:bg-white relative">
                  <Plane className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-[#1C1D1F] dark:text-white w-4 h-4" />
                </div>
                <div className="w-3 h-3 rounded-full bg-[#1C1D1F] dark:bg-white"></div>
              </div>
              <div className="text-xs text-muted-foreground mt-2">Non-stop</div>
            </div>

            <div className="text-center flex-1">
              <div className="text-3xl font-bold text-foreground">{arrCode}</div>
              <div className="text-xl font-semibold text-foreground mt-1">{arrivalTime}</div>
              <div className="text-sm text-muted-foreground mt-1 max-w-[120px] mx-auto truncate">{arrivalAirport}</div>
            </div>
          </div>
        </div>
      )}
      {/* Multi-Leg Flight */}
      {isMultiLeg && legs.length > 0 && (
        <div className="flight-route-multi px-6 py-4 bg-card">
          {legs.map((leg, index) => (
            <div key={index}>
              {/* Leg */}
              <div className="flex items-center justify-between py-4">
                <div className="text-center flex-1">
                  <div className="text-2xl font-bold text-foreground">{getAirportCode(leg.departureAirport)}</div>
                  <div className="text-lg font-semibold text-foreground mt-1">{leg.departureTime}</div>
                  <div className="text-xs text-muted-foreground mt-1 max-w-[100px] mx-auto truncate">{leg.departureAirport}</div>
                </div>

                <div className="flex-1 flex flex-col items-center px-2">
                  {leg.flightNumber && (
                    <div className="text-xs text-muted-foreground mb-1">{leg.flightNumber}</div>
                  )}
                  <div className="w-full flex items-center">
                    <div className="w-2 h-2 rounded-full bg-[#1C1D1F] dark:bg-white"></div>
                    <div className="flex-1 h-0.5 bg-[#1C1D1F] dark:bg-white relative">
                      <Plane className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-[#1C1D1F] dark:text-white w-3 h-3" />
                    </div>
                    <div className="w-2 h-2 rounded-full bg-[#1C1D1F] dark:bg-white"></div>
                  </div>
                </div>

                <div className="text-center flex-1">
                  <div className="text-2xl font-bold text-foreground">{getAirportCode(leg.arrivalAirport)}</div>
                  <div className="text-lg font-semibold text-foreground mt-1">{leg.arrivalTime}</div>
                  <div className="text-xs text-muted-foreground mt-1 max-w-[100px] mx-auto truncate">{leg.arrivalAirport}</div>
                </div>
              </div>

              {/* Layover indicator (if not last leg) */}
              {index < legs.length - 1 && (
                <div className="flex items-center justify-center py-3 border-y border-dashed border-muted bg-muted/50">
                  <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400">
                    <ArrowRightLeft className="w-4 h-4" />
                    <span className="text-sm font-medium">
                      {leg.layoverDuration || 'Connection'} in {getAirportCode(leg.arrivalAirport)}
                    </span>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
      {/* Details Section */}
      <div className="flight-details px-6 py-4 border-t bg-[#F5F3F0]">
        <div className="flex flex-wrap gap-4 text-sm">
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4 text-muted-foreground" />
            <span className="text-foreground">{date}</span>
          </div>
          {passengers && (
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-muted-foreground" />
              <span className="text-foreground">{passengers}</span>
            </div>
          )}
        </div>

        {notes && (
          <div className="mt-3 p-3 rounded-lg bg-[#FFBB95]">
            <div className="flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-[#1C1D1F] mt-0.5" />
              <div>
                <div className="text-xs font-semibold text-[#1C1D1F] uppercase">Things to Remember</div>
                <div className="text-sm text-[#1C1D1F] mt-1 whitespace-pre-wrap">{notes}</div>
              </div>
            </div>
          </div>
        )}
      </div>
      {/* Footer */}
      <div className="flight-footer px-6 py-4 border-t flex items-center bg-[#F5F3F0]">
        <Button variant="default" size="sm" className="gap-2 bg-[#6B1488] hover:bg-[#5a1173] text-white" asChild>
          <a
            href={flightTrackerUrl}
            target="_blank"
            rel="noopener noreferrer"
            data-testid={`link-track-flight-${cleanFlightNumber}`}
          >
            <Plane className="w-4 h-4" />
            Track Flight {cleanFlightNumber}
            <ExternalLink className="w-3 h-3" />
          </a>
        </Button>
        <span className="text-xs text-muted-foreground ml-3">Opens FlightRadar24 in a new tab</span>
      </div>
    </div>
  );
}

export type { FlightLeg, FlightCardProps };
