import heroImage from "@assets/generated_images/Algarve_coastline_golden_hour_498fcb3c.png";

export const heroImageUrl = heroImage;
